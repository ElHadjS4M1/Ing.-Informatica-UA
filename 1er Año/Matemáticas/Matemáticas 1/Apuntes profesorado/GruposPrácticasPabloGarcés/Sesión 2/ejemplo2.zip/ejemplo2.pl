%HECHOS

salario(pepe,2000).
salario(ana, 1000).
salario(luis, 1500).
salario(eva, 2500).

gastos(pepe, 1500).
gastos(ana, 1000).
gastos(luis, 2000).
gastos(eva, 500).

%REGLAS

neto(X, N) :- salario(X, S),  gastos(X, G),  N is S - G.

clasifica(X):- neto(X , N), N < 0, maplist(write, [X, ' es un/a manirroto/a \n']).
clasifica(X):- neto(X , N), N is  0, maplist(write, [X, ' se queda como está \n']).
clasifica(X):- neto(X , N), N < 1000, maplist(write, [X, ' es ahorrador/a \n']).
clasifica(X):- maplist(write, [X, ' te estás forrando... \n']).





