:-use_module('pl-man-game/main').
:-dynamic iteracion/1.
:-dynamic zona/1.

iteracion(1).
zona(izquierda).

do(move(right)):- zona(derecha),see(normal,right,' '),see(normal,left,' ').
do(move(right)):- zona(derecha),see(normal,right,'.').
do(move(left)) :- zona(derecha),see(normal,left,'.').
do(move(up))   :- zona(derecha),see(normal,up,'.').

do(get(down)):- zona(izquierda),see(normal,down,'r').
do(get(up)):-   zona(izquierda),see(normal,up,'r').
do(get(right)):-zona(izquierda),see(normal,right,'r').
do(get(left)):- zona(izquierda),see(normal,left,'r').
do(move(down)):-zona(izquierda),see(normal,right,'#'). 
do(use(right)):-zona(izquierda),see(normal,right,'|'), retract(zona(izquierda)),assert(zona(derecha)).

do(move(down)):- zona(izquierda),iteracion(1), siguiente_a(1).
do(move(right)):-zona(izquierda),iteracion(2), siguiente_a(2).
do(move(up)):-   zona(izquierda),iteracion(3), siguiente_a(3).
do(move(right)):-zona(izquierda),iteracion(4), siguiente_a(0).

siguiente_a(X):- retractall(iteracion(_)), Y is X + 1,assert(iteracion(Y)).

