:-use_module('pl-man-game/main').
:-dynamic cantidadMuertos/1.

cantidadMuertos(0).

do(get(left)):-  see(normal, left, 'l').
do(use(right)):- cantidadMuertos(N), N < 3, incCantidadMuertos.
do(move(right)).

incCantidadMuertos:- retract(cantidadMuertos(M)), N is M+1, assert(cantidadMuertos(N)).
