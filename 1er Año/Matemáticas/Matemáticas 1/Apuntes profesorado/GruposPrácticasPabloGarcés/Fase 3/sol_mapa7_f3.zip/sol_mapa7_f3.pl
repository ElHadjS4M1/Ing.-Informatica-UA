:-use_module('pl-man-game/main').
:-dynamic estado/1.
:-dynamic objetoBuscar/1.
:-dynamic fila/1.
:-dynamic muerto/0.

estado(inicio).
fila(0).

do(move(right)):- estado(inicio), see(normal,down,'+'), see(normal, down-left,Op1), see(normal, down-right,Op2), Suma is Op1+Op2, setObjetoBuscado(Suma), setEstado(buscarObjeto).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
do(get(right)):-     estado(buscarObjeto), objetoBuscar(B), see(normal, right, B).
do(get(left)):-       estado(buscarObjeto), objetoBuscar(B), see(normal, left, B).
do(move(left)):-   estado(buscarObjeto), fila(0), not(see(normal,left,'#')).
do(move(up)):-     estado(buscarObjeto), fila(0), setFila(1).
do(move(right)):- estado(buscarObjeto), fila(1), not(see(normal,right,'#')).
do(move(up)):-     estado(buscarObjeto), fila(1), setFila(2).
do(move(left)):-   estado(buscarObjeto), fila(2), not(see(normal,left,'#')).
do(move(down)):- estado(buscarObjeto), fila(2), cambiarEstado.

do(move(down)):- estado(buscarPuerta), see(normal,left,'#'), not(see(normal,down,'#')).
do(use(down)):-    estado(buscarPuerta), see(normal,down,'+'), setEstado(pasarAbajo).
do(move(right)):-  estado(buscarPuerta).

do(drop(up))      :-   estado(pasarAbajo), havingObject. 
do(move(down)):- estado(pasarAbajo), not(see(normal,down,'#')).
do(move(right)):-  estado(pasarAbajo), not(see(normal,right,'#')).
do(move(none)):- estado(pasarAbajo), setEstado(buscarObjeto), setFila(0), setObjetoBuscado('l').

do(move(down)):- estado(comerAbajo), not(see(normal,down,'#')).
do(use(right)):-      estado(comerAbajo), not(muerto), assert(muerto).
do(move(right)):-  estado(comerAbajo), muerto.

cambiarEstado:-  havingObject(appearance('l')), setEstado(comerAbajo).
cambiarEstado:-  setEstado(buscarPuerta).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

setEstado(E):-  retract(estado(_)), assert(estado(E)), writeln(''), write('Nuevo estado:'), writeln(E).

setFila(F):- retract(fila(_)), assert(fila(F)).
setFila(F):- assert(fila(F)).

setObjetoBuscado(L):- retractall(objetoBuscar(_)), assert(objetoBuscar(L)).


