:- use_module('pl-man-game/main').

%% Predicado dinámico para controlar el estado
:- dynamic estado/1.
estado(subir).

%% Reglas para simplificar el código
hO(OBJ) 	:- havingObject(appearance(OBJ)).
s(DIR, OBJ)	:- see(normal, DIR, OBJ).
change(EST)     :- retractall(estado(_)), assert(estado(EST)).

%% Reglas para subir por la derecha
do(move(right)) :- estado(subir), s(right, ' ').
do(move(up))    :- estado(subir), s(   up, ' ').
do(move( left)) :- estado(subir), change(bajar).

%% Reglas para bajar por la izquierda
do(move( left)) :- estado(bajar), s( left, ' ').
do(move( down)) :- estado(bajar), s( down, ' ').
do(get( left))  :- estado(bajar), s( left, 'a').
do(move(right)) :- estado(bajar), change(entrar).

%% Reglas para entrar y comer los cocos
do(use(   up))  :- estado(entrar), s(   up, '-').
do(move(   up)) :- estado(entrar), s(   up, '.').
do(move( left)) :- estado(entrar), s( left, '.').
do(move(right)) :- estado(entrar), s(right, '.').
do(move( down)) :- estado(entrar), s( down, '.').
do(move(right)) :- estado(entrar).


