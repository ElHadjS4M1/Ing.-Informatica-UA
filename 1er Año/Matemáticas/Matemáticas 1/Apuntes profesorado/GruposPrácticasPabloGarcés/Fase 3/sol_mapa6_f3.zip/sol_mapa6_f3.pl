:-use_module('pl-man-game/main').
:-dynamic estado/1.
:-dynamic abiertas/1.
:-dynamic prueba/1.

estado(limpiarLeft).
abiertas(0).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

do(move(right)):- estado(cruzarFlechasR), see(normal,right-up, '#'), see(normal,right-down, '#'), verSiFin.
do(move(right)):- estado(cruzarFlechasR), not(see(normal,right-up, '|')), not(see(normal,right-down, '|')), not(see(normal,right, '|')).
do(move(none)):-  estado(cruzarFlechasR).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

do(move(left)):- estado(cruzarFlechasL), see(normal,left-up, '#'), see(normal,left-down, '#'), setEstado(abrirPuerta), setPrueba(0).
do(move(left)):- estado(cruzarFlechasL), not(see(normal,left-up, '|')), not(see(normal,left-down, '|')), not(see(normal,left, '|')).
do(move(none)):- estado(cruzarFlechasL).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

do(move(right)):- estado(buscarLLave),see(normal,right,'.').
do(move(right)):- estado(buscarLLave),see(normal,right,' ').
do(get(right)):-  estado(buscarLLave),not(see(normal,right,'.')), not(see(normal,right,'#')), not(see(normal,right,' ')), setEstado(cruzarFlechasL).
do(get(up)):- estado(buscarLLave), not(see(normal,up,'.')), not(see(normal,up,'#')), not(see(normal,up,' ')), setEstado(salirR).
do(move(up)):- estado(buscarLLave), not(see(normal,up,'#')).
do(move(down)):- estado(buscarLLave), see(normal,up,'#'), setEstado(buscarLLaveDown).

do(get(down)):- estado(buscarLLaveDown),not(see(normal,down,'.')), not(see(normal,down,'#')), not(see(normal,down,' ')), setEstado(salirR).
do(move(down)):- estado(buscarLLaveDown), not(see(normal,down,'#')).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

do(move(left)):- estado(salirR), see(normal,left,' '), setEstado(cruzarFlechasL).
do(move(down)):- estado(salirR), see(normal,down,' ').
do(move(up)):- estado(salirR).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

do(move(left)):- estado(limpiarLeft), see(normal,left,'.').
do(move(up)):- estado(limpiarLeft), see(normal,up,'.').
do(move(right)):- estado(limpiarLeft), see(normal,right,'.').
do(move(down)):- estado(limpiarLeft), see(normal,down,'.').
do(move(right)):- estado(limpiarLeft), see(normal,right-up,'#'), see(normal,right-down,'#'), see(normal,right,' '), setEstado(cruzarFlechasR).
do(move(down)):- estado(limpiarLeft), see(normal,down,' '), not(see(normal,right-up,' ')).
do(move(right)):- estado(limpiarLeft), see(normal,right,' ').
do(move(up)):- estado(limpiarLeft).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

do(move(up)):-   estado(abrirPuerta), prueba(0), see(normal,up,' ').
do(move(down)):- estado(abrirPuerta), prueba(0), see(normal,left,' '), see(normal,left-up,'#'), see(normal,left-down,'#'), setPrueba(1).
do(move(left)):- estado(abrirPuerta), prueba(0), see(normal,left,' ').
do(move(none)):- estado(abrirPuerta), prueba(0), see(normal,left,'|'), setPrueba(1).

do(use(left)):-  estado(abrirPuerta), prueba(1), see(normal,left,'|'), setPrueba(2).
do(move(down)):- estado(abrirPuerta), prueba(1).

do(move(left)):- estado(abrirPuerta), prueba(2), see(normal,left,'.').
do(move(right)):- estado(abrirPuerta), prueba(2), see(normal,left,'#'), incAbiertas, setEstado(salirL).
do(move(down)):- estado(abrirPuerta), prueba(2), see(normal,left,'|'), setPrueba(1).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

do(move(right)):- estado(salirL), see(normal,right,' '), see(normal,up-right,'#'), see(normal,down-right,'#'), setEstado(cruzarFlechasR).
do(move(right)):- estado(salirL), see(normal,right,' ').
do(move(down)):- estado(salirL), see(normal,right,'#'), see(normal,up, '#').
do(move(down)):- estado(salirL), see(normal,right,'#'), see(normal,right-down, ' ').
do(move(up)):- estado(salirL), see(normal,right,'#'), see(normal,down, '#').
do(move(up)):- estado(salirL), see(normal,right,'#'), see(normal,right-up, ' ').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

do(move(right)):- estado(limpiarRup), see(normal,right,' ').
do(move(right)):- estado(limpiarRup), see(normal,right,'.').
do(move(up)):- estado(limpiarRup), not(see(normal,up,'#')).
do(move(down)):- estado(limpiarRup), see(normal,up,'#'), setEstado(limpiarRdown). 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
do(move(down)):- estado(limpiarRdown), not(see(normal,down,'#')).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

verSiFin:- abiertas(N), N < 3, setEstado(buscarLLave).
verSiFin:- setEstado(limpiarRup).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
setEstado(E):- retract(estado(_)), assert(estado(E)), writeln(''), write('Nuevo estado:'), writeln(E).

setPrueba(N):- retract(prueba(_)), assert(prueba(N)).
setPrueba(N):- assert(prueba(N)).

incAbiertas:- retract(abiertas(M)), N is M+1, assert(abiertas(N)).


