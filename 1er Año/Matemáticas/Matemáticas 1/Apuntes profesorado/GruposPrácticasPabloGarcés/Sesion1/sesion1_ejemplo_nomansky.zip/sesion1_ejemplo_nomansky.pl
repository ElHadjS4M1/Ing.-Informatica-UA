%%%%%%%%%%%%%%
%% HECHOS
%%%%%%%%%%%%%%

estrella(sol).
estrella(p_centauri).

planeta(tierra).
planeta(marte).
planeta(phobos).
planeta(proxima_b).

orbita(tierra, sol).
orbita(marte,  sol).
orbita(fobos, marte).
orbita(proxima_b, p_centauri).

entidad(ser_vivo, dinosaurio, proxima_b).
entidad(nave,     enterprise, phobos).
entidad(jugador,  miguel,     marte).
entidad(ser_vivo, oveja,      tierra).
entidad(arma,     pistola,    tierra).
entidad(objeto,   pocion,     marte).

%%%%%%%%%%%%%%
%% REGLAS
%%%%%%%%%%%%%%

es_satelite(S) :-  orbita(S, P), planeta(P).

satelite_de(P, PE) :- orbita(P, PE).

sistema_de(E, P)  :- orbita(P, E).

vive_en_sistema(EN, ES) :- entidad(ser_vivo, EN, P), sistema_de(ES, P).

puede_coger(J, O) :- entidad(jugador, J, P),entidad(jugador, O, P).
