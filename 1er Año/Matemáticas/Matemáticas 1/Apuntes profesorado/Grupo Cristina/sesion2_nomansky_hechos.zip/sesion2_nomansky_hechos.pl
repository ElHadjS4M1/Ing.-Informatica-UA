%%%%%%%%%%%%%%
%% HECHOS
%%%%%%%%%%%%%%

%%
%% estrella(E): e es una estrella
%%
estrella(sol).
estrella(p_centauri).

%%
%% planeta(P): p es un planeta, planeta enano, 
%%             o satélite. 
%%
planeta(mercurio).
planeta(venus).
planeta(tierra).
planeta(marte).
planeta(ceres).
planeta(jupiter).
planeta(saturno).
planeta(urano).
planeta(neptuno).
planeta(pluton).
planeta(eris).
planeta(makemake).
planeta(haumea).
planeta(fobos).
planeta(deimos).
planeta(luna).
planeta(io).
planeta(europa).
planeta(ganimedes).
planeta(calisto).
planeta(metis).
planeta(adrastea).
planeta(amaltea).
planeta(tebe).
planeta(titan).
planeta(mimas).
planeta(encelado).
planeta(tetis).
planeta(dione).
planeta(rea).
planeta(hiperion).
planeta(japeto).
planeta(febe).
planeta(miranda).
planeta(ariel).
planeta(umbriel).
planeta(titania).
planeta(oberon).  
planeta(triton).
planeta(nereida).
planeta(nayade).
planeta(talasa).
planeta(despina).
planeta(galatea).
planeta(larisa).
planeta(proteo).
planeta(caronte).
planeta(hidra).
planeta(nix).
planeta(cerbero).
planeta(estigia).
planeta('hi\'iaka').
planeta('namaka').
planeta(disnomia).

planeta(proxima_b).

%%
%% orbita(A, B): A orbita alrededor de B
%%
orbita(mercurio, sol).
orbita(venus, sol).
orbita(tierra, sol).
orbita(marte, sol).
orbita(ceres, sol).
orbita(jupiter, sol).
orbita(saturno, sol).
orbita(urano, sol).
orbita(neptuno, sol).
orbita(pluton, sol).
orbita(eris, sol).
orbita(makemake, sol).
orbita(haumea, sol).
orbita(luna, tierra).
orbita(fobos,  marte).
orbita(deimos, marte).
orbita(io, jupiter).
orbita(europa, jupiter).
orbita(ganimedes, jupiter).
orbita(calisto, jupiter).
orbita(metis, jupiter).
orbita(adrastea, jupiter).
orbita(amaltea, jupiter).
orbita(tebe, jupiter).
orbita(titan, saturno).
orbita(mimas, saturno).
orbita(encelado, saturno).
orbita(tetis, saturno).
orbita(dione, saturno).
orbita(rea, saturno).
orbita(hiperion, saturno).
orbita(japeto, saturno).
orbita(febe, saturno).
orbita(miranda, urano).
orbita(ariel, urano).
orbita(umbriel, urano).
orbita(titania, urano).
orbita(oberon, urano).
orbita(triton, neptuno).
orbita(nereida, neptuno).
orbita(nayade, neptuno).
orbita(talasa, neptuno).
orbita(despina, neptuno).
orbita(galatea, neptuno).
orbita(larisa, neptuno).
orbita(proteo, neptuno).
orbita(caronte, pluton).
orbita(hidra, pluton).
orbita(nix, pluton).
orbita(cerbero, pluton).
orbita(estigia, pluton).
orbita('hi\'iaka', haumea).
orbita('namaka', haumea).
orbita(disnomia, eris).
orbita(proxima_b, p_centauri).

%%
%% entidad(T, N, P): N es el nombre de una entidad de 
%%                   tipo T que se encuentra en P.
%% Tipos: ser_vivo, nave, jugador, objeto, arma
%%
entidad(ser_vivo, dinosaurio, proxima_b).
entidad(nave,     enterprise, phobos).
entidad(jugador,  miguel,     marte).
entidad(ser_vivo, oveja,      tierra).
entidad(arma,     pistola,    tierra).
entidad(objeto,   pocion,     marte).
entidad(arma, aponium, febe).
entidad(jugador, vetamena, tetis).
entidad(ser_vivo, verficta, io).
entidad(objeto, aposulta, talasa).
entidad(arma, nawknium, metis).
entidad(jugador, pueterat, jupiter).
entidad(jugador, romparti, galatea).
entidad(jugador, deduceba, namaka).
entidad(objeto, honsissi, urano).
entidad(arma, samuel, hiperion).
entidad(ser_vivo, letusqui, cerbero).
entidad(objeto, deduceba, makemake).
entidad(objeto, vextruti, luna).
entidad(arma, dirawkne, luna).
entidad(objeto, truenecc, haumea).
entidad(objeto, taetrant, mimas).
entidad(ser_vivo, rawsecro, dione).
entidad(nave, hild, nix).
entidad(objeto, hamulumq, triton).
entidad(jugador, angelino, disnomia).
entidad(ser_vivo, additand, europa).
entidad(jugador, maria, namaka).
entidad(ser_vivo, maria, calisto).
entidad(arma, taetrant, umbriel).
entidad(arma, talerser, miranda).
entidad(objeto, deduceba, despina).
entidad(ser_vivo, verficta, proteo).
entidad(arma, metinave, mimas).
entidad(ser_vivo, gtultuer, europa).
entidad(jugador, vextruti, disnomia).
entidad(jugador, angelino, umbriel).
entidad(nave, lucia, triton).
entidad(arma, blassimo, febe).
entidad(nave, wilfredo, tetis).
entidad(objeto, utraderv, rea).
entidad(objeto, loukios, nix).
entidad(jugador, nequidit, mercurio).
entidad(objeto, rawsecro, despina).
entidad(objeto, rawsecro, galatea).
entidad(jugador, evocilic, umbriel).
entidad(ser_vivo, larbinit, adrastea).
entidad(nave, nawknium, deimos).
entidad(arma, ebratici, nix).
entidad(objeto, romparti, luna).
entidad(jugador, descue, haumea).
entidad(nave, gilitoll, pluton).
entidad(objeto, samuel, disnomia).
entidad(jugador, wilfredo, neptuno).
entidad(ser_vivo, nawknium, nereida).
entidad(objeto, utier, europa).
entidad(objeto, cusatoni, caronte).
entidad(nave, vetamena, dione).
entidad(ser_vivo, kalarcid, deimos).
entidad(arma, lucia, rea).
entidad(objeto, truenecc, cerbero).
entidad(arma, talerser, saturno).
entidad(objeto, gilitoll, venus).
entidad(ser_vivo, truenecc, mercurio).
entidad(jugador, fetatrit, nayade).
entidad(nave, cusatoni, neptuno).
entidad(arma, armanden, pluton).
entidad(arma, evocilic, ariel).
entidad(jugador, romparti, tetis).
entidad(jugador, pueterat, nayade).
entidad(ser_vivo, foctiort, adrastea).
entidad(objeto, pueterat, namaka).
entidad(nave, fetatrit, calisto).
entidad(jugador, paz, talasa).
entidad(objeto, vullatin, caronte).
entidad(jugador, nawknium, neptuno).
entidad(objeto, aposulta, proxima_b).
entidad(objeto, rawsecro, nix).
entidad(arma, gmadentu, hiperion).
entidad(nave, rawsecro, ceres).
entidad(arma, gapiture, neptuno).
entidad(jugador, loukios, proxima_b).
entidad(nave, evocilic, triton).
entidad(ser_vivo, samuel, urano).
entidad(objeto, nequidit, jupiter).
entidad(nave, armanden, ariel).
entidad(arma, foctiort, io).
entidad(ser_vivo, censiono, luna).
entidad(objeto, larbinit, tetis).
entidad(objeto, amorremi, titania).
entidad(jugador, romparti, tetis).
entidad(objeto, honsissi, nayade).
entidad(arma, angelino, eris).
entidad(objeto, asculta, ceres).
entidad(arma, honsissi, oberon).
entidad(ser_vivo, asculta, nayade).
entidad(arma, gapiture, encelado).
entidad(ser_vivo, gapiture, febe).
entidad(objeto, fillaudi, disnomia).
entidad(objeto, hild, venus).
entidad(arma, verficta, nayade).
entidad(arma, evocilic, disnomia).
entidad(arma, evocilic, saturno).
entidad(ser_vivo, utier, tebe).
entidad(objeto, romparti, febe).
entidad(ser_vivo, censiono, venus).
entidad(jugador, blassimo, triton).
entidad(arma, quiniuta, mimas).
entidad(jugador, recto, adrastea).
entidad(objeto, cusatoni, pluton).
entidad(objeto, vullatin, venus).
entidad(ser_vivo, maria, hiperion).
entidad(jugador, dirawkne, tierra).
entidad(objeto, fillaudi, tebe).
entidad(ser_vivo, asculta, dione).
entidad(arma, blassimo, 'hi\'iaka').
entidad(ser_vivo, rawsecro, mercurio).
entidad(objeto, aponium, triton).
entidad(ser_vivo, fetatrit, europa).
entidad(nave, patodigi, deimos).
entidad(nave, foctiort, 'hi\'iaka').
entidad(nave, samuel, miranda).
entidad(objeto, liveruir, amaltea).
entidad(objeto, gilitoll, titania).
entidad(arma, saterant, eris).
entidad(arma, armanden, japeto).
entidad(objeto, korinna, disnomia).
entidad(ser_vivo, blassimo, pluton).
entidad(ser_vivo, armanden, titania).
entidad(nave, utraderv, proteo).
entidad(nave, maria, haumea).
entidad(arma, evocilic, cerbero).
entidad(jugador, additand, umbriel).
entidad(arma, barpertu, saturno).
entidad(jugador, armanden, nix).
entidad(nave, gmadentu, amaltea).
entidad(jugador, nunieben, triton).
entidad(nave, descue, febe).
entidad(arma, deorwine, despina).
entidad(arma, armanden, caronte).
entidad(nave, gmadentu, amaltea).
entidad(objeto, loukios, dione).
entidad(arma, nunieben, hidra).
entidad(ser_vivo, vetamena, urano).
entidad(arma, hild, japeto).
entidad(nave, angelino, neptuno).
entidad(arma, metinave, estigia).
entidad(objeto, asculta, rea).
entidad(jugador, paz, saturno).
entidad(arma, patodigi, haumea).
entidad(objeto, wilfredo, miranda).
entidad(ser_vivo, fergincl, nix).
entidad(objeto, loukios, hiperion).
entidad(ser_vivo, utier, ganimedes).
entidad(arma, barpertu, luna).
entidad(objeto, asculta, estigia).
entidad(ser_vivo, metinave, neptuno).
entidad(nave, korinna, umbriel).
entidad(ser_vivo, recto, nereida).
entidad(ser_vivo, fuidiart, febe).
entidad(jugador, gilitoll, makemake).
entidad(jugador, nublinqu, estigia).
entidad(ser_vivo, pedro, estigia).
entidad(objeto, fillaudi, fobos).
entidad(arma, talerser, metis).
entidad(objeto, blassimo, larisa).
entidad(jugador, negulena, japeto).
entidad(arma, lucia, rea).
entidad(objeto, romparti, adrastea).
entidad(nave, hamulumq, encelado).
entidad(nave, vextruti, luna).
entidad(nave, hamulumq, fobos).
entidad(ser_vivo, equiva, despina).
entidad(arma, angelino, ariel).
entidad(objeto, dirawkne, encelado).
entidad(ser_vivo, dirawkne, estigia).
entidad(objeto, amorremi, ceres).
entidad(jugador, quiniuta, rea).
entidad(objeto, cusatoni, ariel).
entidad(objeto, nublinqu, ganimedes).
entidad(ser_vivo, utier, proteo).
entidad(objeto, zomellam, tierra).
entidad(objeto, blassimo, proxima_b).
entidad(ser_vivo, dirawkne, pluton).
entidad(jugador, patodigi, deimos).
entidad(jugador, evocilic, umbriel).
entidad(jugador, nequidit, larisa).
entidad(ser_vivo, saterant, hiperion).
entidad(ser_vivo, recto, caronte).
entidad(nave, evocilic, umbriel).
entidad(arma, equiva, metis).
entidad(nave, ebratici, oberon).
entidad(arma, cusatoni, ganimedes).
entidad(arma, kalarcid, mimas).
entidad(arma, ebratici, haumea).
entidad(ser_vivo, loukios, oberon).
entidad(ser_vivo, gapiture, ganimedes).
entidad(nave, ebratici, umbriel).
entidad(ser_vivo, romparti, pluton).
entidad(objeto, loukios, saturno).
entidad(nave, armanden, talasa).
