%%%%%%%%%%%%%%
%% HECHOS
%%%%%%%%%%%%%%

%%
%% estrella(E, R): E es una estrella de radio R
%%  (R se mide con respecto al Sol. Sol = 1r)
%%
estrella('Kepler-107', 1.411).
estrella('Kepler-1049', 0.49).
estrella('Kepler-813', 0.93).
estrella('Kepler-427', 1.35).
estrella('Kepler-1056', 1.2).
estrella('Kepler-1165', 1.18).
estrella('Kepler-1104', 1.41).
estrella('WASP-14', 1.31).
estrella('Kepler-50', 1.88).
estrella('NN Ser', 0).
estrella('Kepler-1279', 1.33).
estrella('Kepler-1599', 0.99).
estrella('Kepler-20', 0.944).
estrella('HAT-P-27', 0.87).
estrella('Kepler-181', 0.749).
estrella('HD 116029', 5.04235).
estrella('Kepler-207', 1.588).
estrella('Kepler-1156', 1).
estrella('Kepler-1512', 0.67).
estrella('Kepler-787', 0.62).
estrella('Kepler-528', 1.06).
estrella('HD 219828', 1.4682).
estrella('Kepler-480', 1.34).
estrella('Kepler-1567', 0.93).
estrella('Kepler-1390', 0.98).
estrella('Kepler-1642', 0.84).
estrella('Kepler-11', 1.065).
estrella('Kepler-871', 1.14).
estrella('Kepler-1131', 1.04).
estrella('Kepler-705', 0.51).
estrella('HD 1237', 0.858011).
estrella('WASP-21', 1.06).
estrella('Kepler-284', 0.814).
estrella('Kepler-186', 0.472).
estrella('HD 4308', 0.82259).
estrella('Kepler-239', 0.763).
estrella('Kepler-651', 0.87).
estrella('Kepler-80', 0.64).
estrella('Kepler-1217', 1.08).
estrella('Kepler-895', 0.61).
estrella('Kepler-628', 1.28).
estrella('Kepler-174', 0.622).
estrella('Kepler-440', 0.559).
estrella('Kepler-403', 1.33).
estrella('Kepler-224', 0.676).
estrella('Kepler-389', 0.792).
estrella('Kepler-674', 0.57).
estrella('Kepler-1047', 1.13).
estrella('Kepler-1247', 0.82).
estrella('Kepler-1210', 0.92).
estrella('Kepler-254', 0.91).
estrella('Kepler-236', 0.51).
estrella('WASP-25', 0.92).
estrella('Kepler-1646', 0.26).
estrella('HD 24040', 1.15444).
estrella('Kepler-359', 1.086).
estrella('Kepler-211', 0.816).
estrella('Kepler-967', 0.8).
estrella('Kepler-1574', 1.08).
estrella('Kepler-1157', 0.71).
estrella('Kepler-549', 0.84).
estrella('Kepler-1510', 1.28).
estrella('Kepler-1002', 1.57).
estrella('Kepler-294', 0.976).
estrella('Kepler-263', 0.785).
estrella('Kepler-349', 0.927).
estrella('Kepler-1563', 0.99).
estrella('Kepler-1611', 0.93).
estrella('Kepler-1284', 0.79).
estrella('HD 200964', 3.80029).
estrella('Kepler-706', 0.84).
estrella('HD 147018', 1.05268).
estrella('HD 218566', 0.590728).
estrella('HD 45364', 1.02464).
estrella('Kepler-1177', 0.97).
estrella('Kepler-1364', 1.79).
estrella('Kepler-653', 1.19).
estrella('Kepler-553', 0.85).
estrella('Kepler-361', 1.343).
estrella('Kepler-318', 1.189).
estrella('Kepler-372', 1.137).
estrella('Kepler-197', 1.12).
estrella('HD 141937', 1.06384).
estrella('Kepler-405', 0.893).
estrella('Kepler-104', 1.349).
estrella('Kepler-702', 0.86).
estrella('Kepler-26', 0.571).
estrella('Kepler-159', 0.663).
estrella('HD 156668', 0.728691).
estrella('MOA-2009-BLG-387L', 0).
estrella('Kepler-1045', 0.82).
estrella('Kepler-905', 0.86).
estrella('Kepler-763', 0.8).
estrella('Kepler-1376', 0.97).
estrella('Kepler-32', 0.53).
estrella('WASP-103', 1.436).
estrella('Kepler-990', 1.08).
estrella('Kepler-221', 0.821).
estrella('Kepler-1028', 0.87).
estrella('Kepler-256', 1.301).
estrella('GJ 649', 0).
estrella('Kepler-1333', 0.92).
estrella('Kepler-276', 1.046).
estrella('Kepler-1042', 0.72).
estrella('Kepler-264', 1.55).
estrella('HD 132406', 0).
estrella('Kepler-143', 1.359).
estrella('Kepler-1225', 1.19).
estrella('Kepler-189', 0.75).
estrella('HD 38529', 2.02418).
estrella('Kepler-62', 0.64).
estrella('Kepler-281', 0.899).
estrella('Kepler-1006', 0.74).
estrella('Kepler-196', 0.782).
estrella('Kepler-238', 1.43).
estrella('Kepler-49', 0.53).
estrella('Kepler-55', 0.58).
estrella('Kepler-791', 1.47).
estrella('WASP-19', 0.99).
estrella('Kepler-310', 0.876).
estrella('Kepler-619', 1.11).
estrella('Kepler-204', 1.238).
estrella('Kepler-374', 0.911).
estrella('Kepler-395', 0.556).
estrella('HD 126614 A', 1.10978).
estrella('Kepler-875', 1.11).
estrella('Kepler-1508', 1.22).
estrella('Kepler-1568', 1.19).
estrella('Kepler-83', 0.594).
estrella('Kepler-519', 0.8).
estrella('Kepler-192', 1.01).
estrella('Kepler-167', 0.726).
estrella('Kepler-772', 1.11).
estrella('Kepler-295', 0.898).
estrella('Kepler-337', 1.761).
estrella('HD 177830', 3.99397).
estrella('Kepler-516', 2.02).
estrella('Kepler-1562', 1.05).
estrella('Kepler-226', 0.802).
estrella('HD 38283', 1.50465).
estrella('Kepler-386', 0.767).
estrella('Kepler-922', 0.93).
estrella('HD 217786', 1.15058).
estrella('Kepler-363', 1.485).
estrella('Kepler-687', 0.73).
estrella('Kepler-1457', 1.01).
estrella('Kepler-567', 0.79).
estrella('Kepler-1453', 0.94).
estrella('Kepler-24', 1.289).
estrella('HD 32518', 24.3641).
estrella('Kepler-980', 1.06).
estrella('Kepler-472', 0.78).
estrella('Kepler-402', 1.264).
estrella('Kepler-435', 3.21).
estrella('WASP-18', 1.216).
estrella('CoRoT-6', 1.025).
estrella('Kepler-127', 1.359).
estrella('Kepler-839', 1.31).
estrella('Kepler-203', 1.114).
estrella('Kepler-1234', 0.76).
estrella('Kepler-1127', 0.95).
estrella('Kepler-732', 0.46).
estrella('HD 73267', 1.16642).
estrella('HD 147513', 0.850084).
estrella('Kepler-1528', 1.03).
estrella('Kepler-893', 0.99).
estrella('Kepler-1387', 0.77).
estrella('Kepler-1062', 0.7).
estrella('HD 72659', 1.34287).
estrella('BD +14 4559', 0.725686).
estrella('HD 1605', 3.8).
estrella('Kepler-79', 1.1).
estrella('Kepler-202', 0.667).
estrella('Kepler-709', 0.77).
estrella('HD 197037', 1.09866).
estrella('HD 70642', 1.03139).
estrella('KELT-2 A', 1.828).
estrella('Kepler-10', 1.056).
estrella('Kepler-208', 1.314).
estrella('Kepler-1365', 1.05).
estrella('Kepler-270', 1.461).
estrella('Kepler-966', 1.02).
estrella('Kepler-1010', 0.82).
estrella('Kepler-811', 1.24).
estrella('Kepler-225', 0.48).
estrella('Kepler-1305', 0.96).
estrella('Kepler-150', 0.939).
estrella('Kepler-1322', 0.87).
estrella('M 67 YBP 1194', 1.01765).
estrella('Kepler-1084', 1.28).
estrella('Kepler-616', 0.97).
estrella('Kepler-325', 1.003).
estrella('Kepler-1065', 0.93).
estrella('Kepler-1464', 1.01).
estrella('Kepler-340', 1.85).
estrella('Kepler-682', 0.89).
estrella('Kepler-507', 1.32).
estrella('HD 40307', 0.839223).
estrella('HD 142', 1.5121).
estrella('Kepler-257', 1.037).
estrella('Kepler-976', 0.83).
estrella('WASP-10', 0.698).
estrella('Kepler-982', 1.29).
estrella('GJ 328', 0).
estrella('WASP-17', 1.2).
estrella('HAT-P-17', 0.837).
estrella('Kepler-162', 0.958).
estrella('Kepler-487', 0.88).
estrella('HD 67087', 1.55).
estrella('Kepler-293', 0.957).
estrella('HD 102329', 7.27206).
estrella('Kepler-872', 1.08).
estrella('Kepler-1542', 0.99).
estrella('HD 159868', 1.84825).
estrella('K2-21', 0.6).
estrella('Kepler-424', 0.94).
estrella('Kepler-262', 0.881).
estrella('WASP-117', 1.17).
estrella('WASP-75', 1.26).
estrella('Kepler-1293', 1.28).
estrella('Kepler-222', 0.869).
estrella('Kepler-334', 1.068).
estrella('HD 114783', 0.837785).
estrella('GJ 581', 0.299).
estrella('Kepler-1638', 0.95).
estrella('Kepler-605', 0.88).
estrella('Kepler-327', 0.492).
estrella('Kepler-793', 0.97).
estrella('Kepler-1555', 1.06).
estrella('Kepler-419', 1.75).
estrella('epsilon Ret', 3.51559).
estrella('GJ 674', 0).
estrella('Kepler-511', 1.2).
estrella('Kepler-1361', 0.79).
estrella('HD 7924', 0.7821).
estrella('Kepler-57', 0.73).
estrella('HD 168443', 1.58859).
estrella('Kepler-172', 1.085).
estrella('Kepler-1350', 0.53).
estrella('WASP-70 A', 1.215).
estrella('Kepler-933', 0.84).
estrella('Kepler-1406', 1.12).
estrella('Kepler-1530', 0.88).
estrella('Kepler-400', 1.145).
estrella('Kepler-220', 0.666).
estrella('Kepler-1111', 1.15).
estrella('WASP-57', 0.836).
estrella('HAT-P-37', 0.877).
estrella('Kepler-198', 0.94).
estrella('Kepler-1166', 0.86).
estrella('Kepler-458', 1.03).
estrella('Kepler-1605', 0.82).
estrella('Kepler-1222', 0.8).
estrella('Kepler-1635', 0.85).
estrella('Kepler-615', 0.69).
estrella('Kepler-249', 0.482).
estrella('WASP-106', 1.393).
estrella('HD 81040', 0.918818).
estrella('HD 208527', 41.0489).
estrella('Kepler-165', 0.77).
estrella('Kepler-28', 0.7).
estrella('Kepler-118', 1.094).
estrella('Kepler-1216', 0.98).
estrella('HAT-P-32', 1.219).
estrella('GJ 163', 0).
estrella('HD 95089', 4.34001).
estrella('XO-3', 2.07898).
estrella('Kepler-1380', 0.94).
estrella('Kepler-478', 0.8).
estrella('HD 114729', 1.46377).
estrella('Kepler-122', 1.216).
estrella('Kepler-634', 1.24).
estrella('Kepler-881', 1.09).
estrella('Kepler-103', 1.44).
estrella('Kepler-997', 1.56).
estrella('Kepler-1503', 0.74).
estrella('HD 100655', 9.3).
estrella('Kepler-106', 1.04).
estrella('Kepler-113', 0.69).
estrella('Kepler-1178', 0.75).
estrella('Kepler-595', 0.83).
estrella('HD 142415', 1.11902).
estrella('Kepler-1359', 0.72).
estrella('Kepler-785', 0.71).
estrella('CoRoT-9', 0.94).
estrella('HD 114386', 0.637212).
estrella('HD 103197', 1.01561).
estrella('Kepler-698', 0.91).
estrella('Kepler-1022', 0.68).
estrella('7 CMa', 2.3).
estrella('K2-3', 0.561).
estrella('Kepler-368', 2.019).
estrella('Kepler-913', 0.61).
estrella('Kepler-1224', 1.22).
estrella('Kepler-335', 1.854).
estrella('WASP-16', 0.946).
estrella('Kepler-316', 0.52).
estrella('HD 152581', 3.809).
estrella('KIC 11442793', 1.2).
estrella('Kepler-1426', 1.02).
estrella('Kepler-993', 0.54).
estrella('Kepler-338', 1.735).
estrella('Kepler-1588', 0.99).
estrella('Kepler-985', 0.85).
estrella('Kepler-974', 0.5).
estrella('Kepler-1248', 1.21).
estrella('Kepler-129', 1.641).
estrella('Kepler-1331', 0.69).
estrella('PH-1', 1.759).
estrella('Kepler-306', 0.719).
estrella('Kepler-37', 0.77).
estrella('Kepler-856', 0.93).
estrella('HD 13908', 1.67).
estrella('HD 125595', 1.03336).
estrella('Kepler-1499', 0.78).
estrella('WASP-79', 1.64).
estrella('Kepler-1470', 0.76).
estrella('Kepler-1040', 0.96).
estrella('Kepler-109', 1.32).
estrella('HIP 57274', 0.68).
estrella('Kepler-30', 0.95).
estrella('Kepler-1349', 1.28).
estrella('Kepler-877', 0.81).
estrella('Kepler-720', 0.92).
estrella('Kepler-932', 0.84).
estrella('Kepler-1628', 0.52).
estrella('Kepler-158', 0.624).
estrella('Kepler-858', 0.91).
estrella('Kepler-777', 0.56).
estrella('HD 93083', 1.14863).
estrella('Kepler-970', 0.67).
estrella('HD 31253', 1.64612).
estrella('Kepler-1579', 0.7).
estrella('Kepler-191', 0.79).
estrella('Kepler-357', 0.834).
estrella('Kepler-861', 0.78).
estrella('Kepler-1258', 0.99).
estrella('TRAPPIST-1', 0.117).
estrella('Kepler-552', 1.04).
estrella('HD 89744', 2.02329).
estrella('Kepler-1441', 1).
estrella('Kepler-1341', 0.72).
estrella('Kepler-738', 0.82).
estrella('HD 183263', 1.11717).
estrella('WASP-42', 0.85).
estrella('Kepler-1612', 0.94).
estrella('Kepler-885', 1.35).
estrella('Kepler-53', 0.958).
estrella('Kepler-48', 0.89).
estrella('Kepler-1614', 0.76).
estrella('HD 192310', 0.847025).
estrella('HD 1690', 21.1524).
estrella('HAT-P-41', 1.683).
estrella('Kepler-1493', 1.29).
estrella('Kepler-42', 0.17).
estrella('Kepler-1492', 0.72).
estrella('HD 28185', 1.00685).
estrella('HIP 97233', 5.34).
estrella('Kepler-1461', 0.74).
estrella('Kepler-846', 0.91).
estrella('HD 23127', 1.51172).
estrella('HD 154672', 1.31501).
estrella('Kepler-275', 1.383).
estrella('Kepler-52', 0.52).
estrella('Kepler-1561', 1.11).
estrella('OGLE-TR-10', 1.17).
estrella('Kepler-370', 0.9).
estrella('Kepler-601', 0.79).
estrella('gamma Leo A', 27.4346).
estrella('Kepler-1179', 0.81).
estrella('Kepler-930', 1.4).
estrella('Kepler-1073', 1).
estrella('HAT-P-2', 1.506).
estrella('HAT-P-24', 1.317).
estrella('HD 11506', 1.26275).
estrella('Kepler-758', 1.42).
estrella('tau Boo', 1.41847).
estrella('Kepler-422', 1.24).
estrella('Kepler-124', 0.636).
estrella('Kepler-1081', 0.84).
estrella('Kepler-1539', 0.8).
estrella('Kepler-1458', 0.94).
estrella('Kepler-184', 0.873).
estrella('XO-2S', 1.02).
estrella('HD 34445', 1.39357).
estrella('OGLE-2007-BLG-368L', 0).
estrella('KELT-7', 1.732).
estrella('Kepler-1321', 0.53).
estrella('Kepler-1311', 1.4).
estrella('Kepler-1260', 1.08).
estrella('HD 125612', 1.0426).
estrella('42 Dra', 22.04).
estrella('Kepler-808', 0.71).
estrella('Kepler-216', 1.26).
estrella('Kepler-292', 0.826).
estrella('HD 153950', 1.15135).
estrella('Kepler-69', 0.93).
estrella('Kepler-27', 0.59).
estrella('Kepler-1434', 2.04).
estrella('HD 16141', 2.05).
estrella('WASP-97', 1.06).
estrella('Kepler-7', 1.843).
estrella('HIP 91258', 1).
estrella('Kepler-486', 0.75).
estrella('WASP-24', 1.331).
estrella('HAT-P-29', 1.224).
estrella('Kepler-38', 1.757).
estrella('Kepler-546', 1.15).
estrella('HD 204313', 0).
estrella('PSR B1257+12', 0).
estrella('Kepler-147', 1.468).
estrella('HD 50554', 1.25271).
estrella('HD 11964', 1.76025).
estrella('Kepler-1044', 1.11).
estrella('Kepler-344', 0.976).
estrella('HD 13189', 32.3233).
estrella('HD 60532', 2.35065).
estrella('Kepler-570', 0.9).
estrella('Kepler-1151', 0.85).
estrella('HAT-P-11', 0.75).
estrella('Kepler-406', 1.07).
estrella('Kepler-171', 0.839).
estrella('Kepler-627', 1.49).
estrella('Kepler-330', 0.722).
estrella('HD 104067', 0.858425).
estrella('Kepler-1452', 2.06).
estrella('Kepler-229', 0.728).
estrella('Kepler-638', 0.93).
estrella('Kepler-144', 1.235).
estrella('Kepler-1372', 0.97).
estrella('HD 20794', 1.22683).
estrella('Kepler-94', 0.76).
estrella('Kepler-115', 1.205).
estrella('Kepler-320', 1.108).
estrella('Kepler-1478', 1.06).
estrella('HD 195019', 1.34728).
estrella('Kepler-274', 1.007).
estrella('Kepler-1627', 0.84).
estrella('GJ 832', 0).
estrella('Kepler-889', 1.25).
estrella('GJ 667 C', 0).
estrella('Kepler-592', 1.04).
estrella('CoRoT-19', 1.65).
estrella('Kepler-604', 1.03).
estrella('Kepler-557', 1.16).
estrella('Kepler-1237', 0.9).
estrella('Kepler-142', 1.269).
estrella('alpha Ari', 13.7883).
estrella('Kepler-1450', 0.68).
estrella('Kepler-148', 0.85).
estrella('Kepler-1148', 0.77).
estrella('Kepler-240', 0.739).
estrella('Kepler-545', 1.07).
estrella('61 Vir', 0.978547).
estrella('Kepler-298', 0.582).
estrella('HD 210702', 5.17).
estrella('Kepler-1299', 0.91).
estrella('Kepler-1564', 0.9).
estrella('HAT-P-4', 1.596).
estrella('Kepler-1414', 0.75).
estrella('Kepler-485', 1.09).
estrella('HAT-P-21', 1.105).
estrella('Kepler-398', 0.61).
estrella('Kepler-1180', 1.14).
estrella('Kepler-1388', 0.61).
estrella('Kepler-215', 1.027).
estrella('Kepler-579', 0.96).
estrella('Kepler-232', 0.968).
estrella('Kepler-1009', 0.57).
estrella('Kepler-346', 1.021).
estrella('Kepler-1233', 1.25).
estrella('Kepler-1416', 1.15).
estrella('alpha Cen B', 0.91).
estrella('Kepler-1183', 0.99).
estrella('mu Ara', 1.25035).
estrella('TYC 1422-614-1', 6.85).
estrella('Kepler-1109', 1.06).
estrella('Kepler-830', 1.11).
estrella('WASP-45', 0.945).
estrella('Kepler-916', 0.81).
estrella('Kepler-725', 0.84).
estrella('Kepler-428', 0.8).
estrella('Kepler-1171', 1.95).
estrella('Kepler-1093', 1.2).
estrella('HD 73526', 1.45542).
estrella('HD 108341', 0.79).
estrella('Kepler-1330', 0.94).
estrella('Kepler-382', 0.945).
estrella('Kepler-667', 0.87).
estrella('Kepler-495', 0.83).
estrella('Kepler-333', 0.534).
estrella('Kepler-17', 1.05).
estrella('14 Her', 0.912364).
estrella('HAT-P-33', 1.637).
estrella('Kepler-692', 0.86).
estrella('Kepler-1223', 0.75).
estrella('Kepler-1232', 0.89).
estrella('Kepler-805', 1.65).
estrella('Kepler-166', 0.742).
estrella('Kepler-1398', 1.18).
estrella('Kepler-1629', 1.01).
estrella('Kepler-835', 1.11).
estrella('Kepler-992', 0.74).
estrella('Kepler-1420', 0.79).
estrella('OGLE-05-169L', 0).
estrella('HIP 79431', 0).
estrella('Kepler-562', 0.9).
estrella('Kepler-1476', 0.96).
estrella('Kepler-870', 1.02).
estrella('Kepler-1155', 1.03).
estrella('HD 171238', 1.05059).
estrella('Kepler-1292', 0.93).
estrella('Kepler-1410', 0.6).
estrella('Kepler-272', 0.929).
estrella('Kepler-157', 1.044).
estrella('HIP 5158', 0.986271).
estrella('Kepler-661', 0.67).
estrella('Kepler-308', 0.941).
estrella('WASP-46', 0.917).
estrella('Kepler-800', 0.82).
estrella('Kepler-1268', 1.09).
estrella('Kepler-1034', 0.8).
estrella('Kepler-475', 0.79).
estrella('Kepler-1541', 0.81).
estrella('GJ 849', 0).
estrella('Kepler-587', 0.89).
estrella('WASP-84', 0.748).
estrella('Kepler-1190', 0.72).
estrella('Kepler-599', 0.79).
estrella('Kepler-163', 0.917).
estrella('Kepler-121', 0.701).
estrella('Kepler-123', 1.264).
estrella('Kepler-1123', 0.9).
estrella('HAT-P-1', 1.135).
estrella('Kepler-1025', 1.13).
estrella('Kepler-201', 1.229).
estrella('OGLE2-TR-L9', 1.53).
estrella('Kepler-54', 0.5).
estrella('Kepler-973', 0.78).
estrella('Kepler-355', 1.066).
estrella('Kepler-1472', 1.25).
estrella('Kepler-1135', 0.94).
estrella('Kepler-375', 0.837).
estrella('Kepler-1209', 1.38).
estrella('Kepler-1019', 0.67).
estrella('Kepler-484', 0.87).
estrella('Kepler-137', 0.802).
estrella('Kepler-85', 0.893).
estrella('Kepler-1456', 0.62).
estrella('GJ 3341', 0.439).
estrella('Kepler-1290', 0.93).
estrella('Kepler-962', 0.86).
estrella('WASP-22', 1.13).
estrella('Kepler-468', 0.87).
estrella('Kepler-640', 0.94).
estrella('Kepler-503', 1.01).
estrella('WASP-2', 0.84).
estrella('Kepler-392', 1.129).
estrella('Kepler-247', 0.768).
estrella('Kepler-1076', 0.74).
estrella('HD 164922', 0.899472).
estrella('Kepler-271', 0.88).
estrella('Kepler-190', 0.795).
estrella('tau Gru', 1.54911).
estrella('WASP-34', 0.93).
estrella('Kepler-397', 0.767).
estrella('HD 96063', 3.66196).
estrella('Kepler-490', 1.12).
estrella('Kepler-1466', 1.02).
estrella('Kepler-630', 1.04).
estrella('Kepler-423', 0.99).
estrella('HAT-P-22', 1.04).
estrella('51 Eri', 0).
estrella('Kepler-1374', 0.81).
estrella('Kepler-1041', 1.08).
estrella('WASP-28', 1.094).
estrella('CoRoT-7', 0.87).
estrella('Kepler-1418', 0.72).
estrella('HD 5608', 5.5).
estrella('Kepler-584', 1.24).
estrella('Kepler-733', 0.86).
estrella('Kepler-1200', 0.7).
estrella('Kepler-178', 1.066).
estrella('Kepler-1207', 1.06).
estrella('Kepler-1096', 0.63).
estrella('Kepler-1491', 0.99).
estrella('HATS-1', 1.038).
estrella('Kepler-1559', 0.82).
estrella('Kepler-378', 0.671).
estrella('HD 80606', 0.98).
estrella('Kepler-471', 1.8).
estrella('Kepler-1511', 1.29).
estrella('Kepler-45', 0.55).
estrella('Kepler-68', 1.243).
estrella('Kepler-1195', 0.71).
estrella('Kepler-665', 0.74).
estrella('Kepler-950', 1.02).
estrella('WASP-78', 2.2).
estrella('Kepler-108', 2.192).
estrella('HD 86264', 1.49917).
estrella('Kepler-942', 0.75).
estrella('Kepler-266', 1.028).
estrella('Kepler-1094', 1.21).
estrella('Kepler-1194', 0.92).
estrella('8 UMi', 9.9).
estrella('Kepler-1291', 0.8).
estrella('Kepler-524', 1.1).
estrella('HD 82943', 1.09738).
estrella('Kepler-205', 0.546).
estrella('Kepler-319', 0.903).
estrella('Kepler-126', 1.358).
estrella('HD 216536', 12.5).
estrella('Kepler-728', 0.93).
estrella('Kepler-384', 0.882).
estrella('Kepler-669', 1.2).
estrella('Kepler-1046', 1.04).
estrella('iota Hor', 1.21047).
estrella('Kepler-716', 0.78).
estrella('HD 37124', 0.772275).
estrella('Kepler-853', 1.55).
estrella('Kepler-690', 1.16).
estrella('Kepler-1500', 1).
estrella('Kepler-1316', 1.12).
estrella('Kepler-921', 0.91).
estrella('HD 192263', 0.7401).
estrella('Kepler-1079', 1.36).
estrella('Kepler-771', 1.05).
estrella('Kepler-212', 1.455).
estrella('Kepler-707', 0.76).
estrella('Kepler-1211', 0.94).
estrella('Kepler-321', 1.194).
estrella('Kepler-1442', 1.44).
estrella('Kepler-339', 0.802).
estrella('Kepler-407', 0.1).
estrella('Kepler-756', 0.79).
estrella('TrES-3', 0.812).
estrella('Kepler-188', 1.141).
estrella('HIP 14810', 1.31998).
estrella('Kepler-695', 0.8).
estrella('HD 90156', 0.920961).
estrella('Kepler-786', 0.74).
estrella('Kepler-259', 0.898).
estrella('Kepler-444', 0.752).
estrella('Kepler-550', 0.83).
estrella('Kepler-304', 0.687).
estrella('Kepler-218', 1.063).
estrella('Pr 211', 0.868).
estrella('Kepler-981', 0.96).
estrella('Kepler-6', 1.391).
estrella('Kepler-501', 1.04).
estrella('Kepler-244', 0.803).
estrella('24 Sex', 3.92062).
estrella('Kepler-358', 0.954).
estrella('Kepler-373', 0.845).
estrella('HATS-13', 0.887).
estrella('Kepler-466', 1.05).
estrella('Kepler-1074', 0.57).
estrella('Kepler-807', 1.06).
estrella('Kepler-299', 1.032).
estrella('Kepler-939', 0.85).
estrella('Kepler-1389', 0.74).
estrella('Kepler-140', 1.288).
estrella('Kepler-23', 1.548).
estrella('Kepler-1048', 0.7).
estrella('Kepler-89', 1.52).
estrella('WASP-95', 1.13).
estrella('Kepler-831', 0.97).
estrella('HD 68988', 1.10962).
estrella('Kepler-84', 1.43).
estrella('Kepler-637', 2.56).
estrella('HAT-P-26', 0.788).
estrella('Kepler-1252', 1.09).
estrella('Kepler-847', 0.77).
estrella('Kepler-1355', 0.83).
estrella('Kepler-296', 0.557).
estrella('HD 149143', 1.71219).
estrella('Kepler-688', 0.96).
estrella('Kepler-713', 0.99).
estrella('HD 79498', 1.12815).
estrella('Kepler-722', 1.05).
estrella('Kepler-556', 0.98).
estrella('Kepler-883', 1.09).
estrella('Kepler-1181', 1.3).
estrella('Kepler-1336', 1.3).
estrella('Kepler-897', 1.04).
estrella('Kepler-269', 0.959).
estrella('Kepler-248', 0.831).
estrella('HD 181433', 1.00831).
estrella('Kepler-1375', 1.78).
estrella('Kepler-454', 1.066).
estrella('70 Vir', 1.59775).
estrella('HD 102365', 0.828702).
estrella('BD -08 2823', 1.27853).
estrella('Kepler-1276', 1.21).
estrella('Kepler-797', 0.95).
estrella('Kepler-160', 0.884).
estrella('Kepler-1066', 0.98).
estrella('Kepler-1318', 0.7).
estrella('CoRoT-11', 1.37).
estrella('Kepler-369', 0.471).
estrella('Kepler-1415', 0.84).
estrella('Kepler-443', 0.706).
estrella('Kepler-746', 0.93).
estrella('Kepler-1348', 1.04).
estrella('GJ 436', 0.464).
estrella('Kepler-1231', 1).
estrella('Kepler-401', 1.33).
estrella('Kepler-815', 3.42).
estrella('Kepler-578', 0.83).
estrella('Kepler-364', 1.284).
estrella('Kepler-173', 0.949).
estrella('Kepler-609', 1.14).
estrella('Kepler-1606', 0.86).
estrella('Kepler-290', 0.743).
estrella('Kepler-926', 1.01).
estrella('Kepler-544', 1.22).
estrella('WASP-37', 1.003).
estrella('Kepler-223', 1.017).
estrella('HD 6718', 0.956629).
estrella('Kepler-322', 0.89).
estrella('HD 33636', 1.03374).
estrella('Kepler-477', 0.79).
estrella('Kepler-1327', 1.03).
estrella('Kepler-1128', 0.91).
estrella('HAT-P-40', 2.206).
estrella('HD 240237', 0).
estrella('Kepler-494', 1.26).
estrella('Kepler-169', 0.763).
estrella('Kepler-283', 0.566).
estrella('rho CrB', 1.10084).
estrella('Kepler-214', 1.352).
estrella('Kepler-700', 0.96).
estrella('Kepler-1549', 0.84).
estrella('Kepler-730', 1.01).
estrella('Kepler-1515', 1.41).
estrella('Kepler-1424', 1.07).
estrella('Kepler-314', 0.95).
estrella('Kepler-731', 1.06).
estrella('Kepler-1338', 1.05).
estrella('Kepler-233', 0.758).
estrella('Kepler-1440', 0.96).
estrella('Kepler-1513', 0.97).
estrella('Kepler-110', 1.149).
estrella('HD 11977', 8.14661).
estrella('Kepler-1192', 0.83).
estrella('Kepler-1382', 1.72).
estrella('HD 73534', 2.90137).
estrella('Kepler-689', 0.88).
estrella('Kepler-1643', 0.88).
estrella('Kepler-195', 0.775).
estrella('Kepler-498', 0.96).
estrella('Kepler-863', 0.95).
estrella('HD 164604', 0).
estrella('Kepler-1356', 0.78).
estrella('Kepler-1201', 1.24).
estrella('Kepler-1594', 1.08).
estrella('Kepler-642', 1.66).
estrella('OGLE-05-071L', 0).
estrella('OGLE235-MOA53', 0).
estrella('HD 217107', 1.5).
estrella('Kepler-1323', 1.4).
estrella('HD 74156', 1.345).
estrella('Kepler-928', 0.7).
estrella('Kepler-180', 1.063).
estrella('HD 103774', 1.43364).
estrella('Kepler-43', 1.42).
estrella('Kepler-76', 1.12).
estrella('Kepler-1154', 1.43).
estrella('Kepler-538', 0.9).
estrella('KELT-6', 1.58).
estrella('WASP-13', 1.574).
estrella('Kepler-683', 0.95).
estrella('Kepler-918', 1.14).
estrella('Kepler-569', 0.93).
estrella('HD 13931', 1.22417).
estrella('Kepler-58', 1.127).
estrella('HAT-P-18', 0.749).
estrella('Kepler-672', 0.92).
estrella('Kepler-1518', 1.88).
estrella('Kepler-971', 0.85).
estrella('HD 155358', 1.49875).
estrella('WASP-43', 0.598).
estrella('Kepler-1570', 0.89).
estrella('Kepler-39', 1.39).
estrella('Kepler-920', 0.85).
estrella('14 And', 11.38).
estrella('Kepler-1130', 0.81).
estrella('Kepler-520', 1.09).
estrella('Kepler-1191', 0.81).
estrella('Kepler-1012', 0.91).
estrella('Kepler-1145', 0.75).
estrella('Kepler-891', 1.07).
estrella('Kepler-727', 0.86).
estrella('WASP-88', 2.08).
estrella('Kepler-29', 0.96).
estrella('Kepler-792', 1.12).
estrella('Kepler-975', 0.75).
estrella('Kepler-542', 0.9).
estrella('Kepler-656', 0.82).
estrella('Kepler-770', 0.92).
estrella('Kepler-489', 0.76).
estrella('81 Cet', 15.7275).
estrella('Kepler-1204', 1.03).
estrella('Kepler-1218', 1.1).
estrella('Kepler-1043', 0.9).
estrella('Kepler-1396', 1.27).
estrella('CoRoT-3', 1.56).
estrella('Kepler-377', 1.224).
estrella('Kepler-648', 0.98).
estrella('Kepler-910', 1.5).
estrella('Kepler-1506', 0.93).
estrella('HAT-P-38', 0.923).
estrella('Kepler-1602', 1.36).
estrella('Kepler-18', 1.108).
estrella('Kepler-1077', 1.02).
estrella('Kepler-380', 1.224).
estrella('Kepler-1580', 2.15).
estrella('HD 32963', 0.988525).
estrella('Kepler-132', 1.178).
estrella('Kepler-228', 1.014).
estrella('Kepler-97', 0.98).
estrella('WASP-96', 1.05).
estrella('Kepler-1229', 0.51).
estrella('Kepler-518', 0.88).
estrella('Kepler-139', 1.3).
estrella('Kepler-952', 0.99).
estrella('Kepler-1285', 1.28).
estrella('HD 136118', 1.75082).
estrella('Kepler-182', 1.146).
estrella('Kepler-1313', 0.85).
estrella('HD 6434', 0.80278).
estrella('HD 5319', 3.85).
estrella('Kepler-1519', 0.91).
estrella('Kepler-253', 0.786).
estrella('Kepler-1586', 1.75).
estrella('Kepler-1172', 0.89).
estrella('Kepler-1501', 1.3).
estrella('HD 231701', 1.24116).
estrella('Kepler-666', 1.05).
estrella('PH-2', 1).
estrella('Kepler-1027', 0.82).
estrella('CoRoT-18', 1).
estrella('Kepler-703', 1.27).
estrella('Kepler-1505', 0.86).
estrella('HD 75898', 1.54576).
estrella('Kepler-776', 0.78).
estrella('Kepler-876', 0.77).
estrella('Kepler-1459', 0.74).
estrella('Kepler-710', 0.91).
estrella('Kepler-806', 1.16).
estrella('KOI-4427', 0.505).
estrella('Kepler-612', 0.96).
estrella('MOA-2008-BLG-310L', 0).
estrella('GJ 1214', 0.211).
estrella('Kepler-824', 1.22).
estrella('Kepler-1451', 0.99).
estrella('Kepler-268', 1.274).
estrella('Kepler-135', 1.275).
estrella('Kepler-265', 1.103).
estrella('Kepler-1296', 0.83).
estrella('Kepler-1480', 0.81).
estrella('Kepler-620', 1.22).
estrella('16 Cyg B', 1.1176).
estrella('HAT-P-25', 0.959).
estrella('Kepler-341', 1.024).
estrella('HD 213240', 1.3947).
estrella('Kepler-1577', 0.74).
estrella('Kepler-1409', 0.79).
estrella('Kepler-1352', 1.16).
estrella('Kepler-1249', 1.28).
estrella('Kepler-1269', 1.15).
estrella('HAT-P-45', 1.319).
estrella('Kepler-399', 0.68).
estrella('Kepler-925', 0.72).
estrella('Kepler-677', 0.99).
estrella('HD 33844', 5.29).
estrella('Kepler-243', 0.842).
estrella('Kepler-561', 0.94).
estrella('HD 12661', 1.06782).
estrella('Kepler-467', 1.37).
estrella('Kepler-1107', 0.82).
estrella('Kepler-9', 1.1).
estrella('Kepler-790', 0.8).
estrella('Kepler-326', 0.801).
estrella('WASP-47', 1.15).
estrella('Kepler-31', 1.22).
estrella('Kepler-82', 0.9).
estrella('Kepler-573', 1.02).
estrella('Kepler-1288', 1.29).
estrella('Kepler-1484', 0.92).
estrella('Kepler-583', 0.91).
estrella('Kepler-610', 1.13).
estrella('HD 38801', 2.24501).
estrella('Kepler-964', 0.84).
estrella('HD 132563 B', 0).
estrella('Kepler-1227', 0.95).
estrella('Kepler-351', 0.85).
estrella('Kepler-390', 0.776).
estrella('Kepler-61', 0.62).
estrella('Kepler-1486', 1.12).
estrella('Kepler-803', 1.12).
estrella('HD 207832', 0.901).
estrella('Kepler-1462', 1).
estrella('Kepler-886', 1.16).
estrella('Kepler-1468', 1.05).
estrella('Kepler-1544', 0.74).
estrella('Kepler-44', 1.52).
estrella('HD 5891', 11.8348).
estrella('Kepler-1000', 1.51).
estrella('Kepler-245', 0.795).
estrella('Kepler-884', 0.94).
estrella('Kepler-908', 1.12).
estrella('HD 173416', 14.3919).
estrella('Kepler-1379', 0.79).
estrella('Kepler-1008', 0.78).
estrella('Kepler-278', 2.935).
estrella('Kepler-1587', 1.22).
estrella('Kepler-1569', 1.4).
estrella('Kepler-1273', 0.91).
estrella('HD 76700', 1.2353).
estrella('Kepler-366', 1.048).
estrella('HD 39091', 1.14999).
estrella('Kepler-1636', 1.02).
estrella('Kepler-1068', 1.01).
estrella('Kepler-596', 1.32).
estrella('HD 7449', 0.952526).
estrella('HD 149026', 1.368).
estrella('Kepler-219', 1.491).
estrella('OGLE-2006-BLG-109L', 0).
estrella('Kepler-1240', 0.96).
estrella('Qatar-2', 0.713).
estrella('Kepler-1448', 0.93).
estrella('Kepler-1551', 1.22).
estrella('HD 216437', 1.36865).
estrella('Kepler-1052', 1.03).
estrella('HAT-P-49', 1.833).
estrella('Kepler-623', 0.86).
estrella('Kepler-1621', 1.24).
estrella('Kepler-367', 0.695).
estrella('Kepler-313', 1.536).
estrella('Kepler-1439', 0.43).
estrella('Kepler-87', 1.82).
estrella('Kepler-681', 0.76).
estrella('Kepler-564', 0.92).
estrella('HAT-P-7', 1.981).
estrella('HD 49674', 0.889525).
estrella('Kepler-342', 1.472).
estrella('Kepler-783', 0.89).
estrella('Kepler-1378', 0.67).
estrella('Kepler-828', 0.77).
estrella('WASP-38', 1.35).
estrella('WASP-69', 0.813).
estrella('Kepler-1199', 1.17).
estrella('Kepler-817', 1.03).
estrella('HD 77338', 0.88).
estrella('HD 220773', 1.35144).
estrella('Kepler-655', 1.24).
estrella('Kepler-559', 0.95).
estrella('WASP-6', 0.87).
estrella('Kepler-1337', 0.67).
estrella('Kepler-1552', 0.78).
estrella('Kepler-206', 1.185).
estrella('HD 137388', 0.97784).
estrella('HD 95086', 0).
estrella('Kepler-352', 0.781).
estrella('Kepler-329', 0.523).
estrella('Kepler-179', 0.759).
estrella('Kepler-1080', 1.16).
estrella('Kepler-176', 0.891).
estrella('WASP-104', 0.963).
estrella('WASP-83', 1.05).
estrella('Kepler-1095', 0.92).
estrella('Kepler-1170', 0.76).
estrella('Kepler-1132', 0.83).
estrella('Kepler-1265', 0.69).
estrella('Kepler-1494', 0.94).
estrella('WASP-99', 1.76).
estrella('HD 100777', 1.07881).
estrella('Kepler-818', 0.92).
estrella('HAT-P-5', 1.165).
estrella('Kepler-1381', 0.94).
estrella('Kepler-125', 0.512).
estrella('Kepler-193', 1.147).
estrella('Kepler-1078', 0.92).
estrella('Kepler-585', 0.93).
estrella('HD 222582', 1.13737).
estrella('Kepler-119', 0.839).
estrella('Kepler-558', 0.81).
estrella('Kepler-670', 0.99).
estrella('Kepler-1188', 1.06).
estrella('Kepler-434', 1.38).
estrella('Kepler-16', 0.6489).
estrella('Kepler-1122', 0.89).
estrella('Kepler-1534', 0.86).
estrella('WASP-33', 1.444).
estrella('HD 128311', 0.58322).
estrella('TrES-1', 0.807).
estrella('HD 4208', 0.876501).
estrella('Kepler-773', 1.01).
estrella('Kepler-120', 0.534).
estrella('HD 5388', 1.29538).
estrella('Kepler-1393', 0.92).
estrella('Kepler-1001', 0.88).
estrella('CoRoT-10', 0.79).
estrella('Kepler-1309', 0.8).
estrella('11 UMi', 44.65).
estrella('Kepler-286', 0.863).
estrella('WASP-62', 1.28).
estrella('Kepler-496', 0.82).
estrella('Kepler-1641', 1.19).
estrella('Kepler-1616', 1.34).
estrella('Kepler-300', 0.9).
estrella('Kepler-1582', 0.3).
estrella('HD 4732', 5.55146).
estrella('Kepler-258', 0.915).
estrella('Kepler-555', 1.04).
estrella('Kepler-1270', 3.38).
estrella('Kepler-632', 0.84).
estrella('kappa CrB', 5.06).
estrella('Kepler-25', 1.31).
estrella('HD 99492', 0.630794).
estrella('Kepler-291', 1.016).
estrella('HD 204941', 0.850124).
estrella('Kepler-664', 1.02).
estrella('Kepler-1051', 1.73).
estrella('Kepler-603', 1.01).
estrella('Kepler-332', 0.72).
estrella('HD 196050', 1.31321).
estrella('WASP-11', 0.74).
estrella('HD 111232', 0.874998).
estrella('HD 117618', 1.16537).
estrella('HD 180902', 3.85021).
estrella('Kepler-671', 0.95).
estrella('Kepler-1263', 0.8).
estrella('HIP 12961', 0).
estrella('Kepler-1357', 0.9).
estrella('HD 63454', 1.15809).
estrella('Kepler-460', 1.24).
estrella('BD +48 738', 11.7902).
estrella('Kepler-560', 0.33).
estrella('Kepler-371', 0.992).
estrella('Kepler-909', 1.23).
estrella('Kepler-724', 0.86).
estrella('NGC 2423 3', 21.2079).
estrella('Kepler-227', 1.091).
estrella('Kepler-33', 1.82).
estrella('Kepler-1280', 1.32).
estrella('Kepler-1383', 1.44).
estrella('Kepler-938', 0.89).
estrella('HD 50499', 1.18426).
estrella('CoRoT-14', 1.21).
estrella('Kepler-820', 1.36).
estrella('Kepler-521', 1.46).
estrella('Kepler-1136', 0.68).
estrella('Kepler-832', 0.9).
estrella('Kepler-155', 0.62).
estrella('Kepler-1015', 1.81).
estrella('CoRoT-4', 1.17).
estrella('HAT-P-19', 0.82).
estrella('Kepler-736', 0.81).
estrella('Kepler-784', 1.32).
estrella('Kepler-825', 1.08).
estrella('HD 154857', 1.86203).
estrella('Kepler-1037', 0.78).
estrella('Kepler-1425', 0.95).
estrella('Kepler-47', 0.964).
estrella('Kepler-133', 1.425).
estrella('Kepler-919', 1.21).
estrella('HIP 116454', 0.716).
estrella('Kepler-924', 1.23).
estrella('Kepler-988', 0.53).
estrella('Kepler-116', 1.454).
estrella('Kepler-869', 0.95).
estrella('Kepler-848', 1.2).
estrella('Kepler-764', 0.89).
estrella('Kepler-734', 0.78).
estrella('Kepler-315', 1.037).
estrella('Kepler-837', 0.81).
estrella('Kepler-639', 1.29).
estrella('Kepler-1208', 0.76).
estrella('Kepler-1238', 1.48).
estrella('Kepler-586', 0.92).
estrella('Kepler-757', 1.13).
estrella('HD 2039', 1.1465).
estrella('Kepler-170', 1.035).
estrella('Kepler-36', 1.626).
estrella('Kepler-136', 1.355).
estrella('XO-2', 0.971).
estrella('Kepler-859', 0.77).
estrella('Kepler-305', 0.794).
estrella('Kepler-393', 1.382).
estrella('Kepler-96', 1.02).
estrella('Kepler-1497', 0.95).
estrella('Kepler-1257', 0.87).
estrella('HD 187085', 1.31178).
estrella('HD 118203', 2.14975).
estrella('Kepler-833', 0.62).
estrella('Kepler-464', 1.59).
estrella('WASP-63', 1.88).
estrella('Kepler-836', 1.04).
estrella('Kepler-946', 0.93).
estrella('HD 175167', 0).
estrella('Kepler-273', 0.815).
estrella('Kepler-461', 0.91).
estrella('Kepler-1603', 1.31).
estrella('Kepler-323', 1.178).
estrella('Kepler-267', 0.555).
estrella('HAT-P-16', 1.237).
estrella('TrES-4', 1.816).
estrella('Kepler-231', 0.49).
estrella('NGC 4349 127', 42.3715).
estrella('GJ 676 A', 0).
estrella('Kepler-60', 1.5).
estrella('Kepler-1124', 0.34).
estrella('Kepler-1235', 0.9).
estrella('Kepler-151', 0.83).
estrella('Kepler-242', 0.85).
estrella('Kepler-230', 0.817).
estrella('HD 47186', 1.13117).
estrella('Kepler-463', 0.9).
estrella('Kepler-1553', 0.81).
estrella('Kepler-1003', 1.17).
estrella('Kepler-840', 1.06).
estrella('Kepler-534', 0.98).
estrella('Kepler-350', 1.534).
estrella('Kepler-900', 0.73).
estrella('Kepler-209', 0.935).
estrella('HD 142245', 4.51552).
estrella('Kepler-1251', 0.89).
estrella('Kepler-59', 0.94).
estrella('Kepler-493', 1.54).
estrella('Kepler-1054', 1.34).
estrella('Kepler-1607', 1.21).
estrella('Kepler-309', 0.721).
estrella('Kepler-1447', 0.95).
estrella('Kepler-302', 1.22).
estrella('Kepler-1489', 0.9).
estrella('HD 30177', 1.21235).
estrella('Kepler-678', 0.91).
estrella('Kepler-446', 0.24).
estrella('Kepler-4', 1.487).
estrella('Kepler-1370', 1.29).
estrella('Kepler-882', 0.87).
estrella('bet Cnc', 47.2).
estrella('HD 190647', 1.42287).
estrella('Kepler-530', 0.89).
estrella('Kepler-1522', 0.93).
estrella('Kepler-759', 1.04).
estrella('Kepler-1351', 0.67).
estrella('Kepler-529', 1.14).
estrella('Kepler-977', 0.83).
estrella('HD 97658', 0.703).
estrella('Kepler-261', 0.794).
estrella('Kepler-658', 0.6).
estrella('Kepler-175', 1.01).
estrella('Kepler-509', 1.2).
estrella('Kepler-577', 0.73).
estrella('Kepler-1153', 0.88).
estrella('Kepler-433', 2.26).
estrella('Kepler-1319', 0.54).
estrella('HD 106270', 2.66147).
estrella('Kepler-1287', 0.94).
estrella('Kepler-426', 0.92).
estrella('Kepler-379', 1.306).
estrella('WASP-20', 1.392).
estrella('HD 30856', 5.5698).
estrella('HD 24064', 38).
estrella('HD 48265', 0).
estrella('Kepler-476', 1.09).
estrella('Kepler-154', 1).
estrella('HATS-4', 0.925).
estrella('Kepler-1608', 0.72).
estrella('Kepler-527', 1.45).
estrella('CoRoT-27', 1.08).
estrella('Kepler-1115', 1.73).
estrella('Kepler-1141', 1.07).
estrella('Kepler-360', 1.058).
estrella('Kepler-969', 0.82).
estrella('Kepler-1106', 1.17).
estrella('Kepler-381', 1.568).
estrella('Kepler-168', 1.107).
estrella('Kepler-874', 1.13).
estrella('Kepler-987', 0.91).
estrella('HD 89307', 1.15051).
estrella('Kepler-1039', 0.74).
estrella('Kepler-1112', 1.54).
estrella('HD 163607', 1.69594).
estrella('Kepler-960', 0.72).
estrella('WASP-49', 0.976).
estrella('Kepler-288', 1.091).
estrella('Kepler-1314', 0.59).
estrella('Kepler-1504', 0.81).
estrella('HD 4313', 4.11574).
estrella('Kepler-1197', 0.72).
estrella('HR 8799', 1.44).
estrella('Kepler-774', 2.42).
estrella('Kepler-1173', 0.82).
estrella('HD 2638', 1.1428).
estrella('Kepler-512', 1.3).
estrella('Kepler-747', 0.78).
estrella('Kepler-827', 0.91).
estrella('Kepler-1057', 1.1).
estrella('WASP-41', 0.87).
estrella('Kepler-1622', 1.5).
estrella('HD 10180', 1.10851).
estrella('Kepler-445', 0.21).
estrella('Kepler-1088', 1.08).
estrella('HD 45350', 1.18013).
estrella('HD 69830', 0.921634).
estrella('Kepler-963', 0.87).
estrella('Kepler-21', 1.86).
estrella('Kepler-1053', 0.69).
estrella('CoRoT-28', 1.78).
estrella('Kepler-679', 0.84).
estrella('Kepler-841', 0.81).
estrella('KELT-3', 1.482).
estrella('Kepler-51', 0.91).
estrella('Kepler-1639', 1.18).
estrella('HD 148427', 3.92268).
estrella('Kepler-810', 1.04).
estrella('Kepler-1520', 0.71).
estrella('Kepler-533', 0.72).
estrella('epsilon Tau', 12.752).
estrella('Kepler-1419', 1.01).
estrella('HAT-P-46', 1.396).
estrella('HD 208487', 1.20627).
estrella('Kepler-1033', 0.92).
estrella('Kepler-1517', 1.95).
estrella('Kepler-626', 1.05).
estrella('Kepler-311', 1.188).
estrella('Kepler-117', 1.471).
estrella('epsilon Eri', 0.74).
estrella('Kepler-935', 0.73).
estrella('Kepler-1245', 0.83).
estrella('HD 20782', 1.12933).
estrella('Kepler-613', 0.96).
estrella('Kepler-1011', 0.88).
estrella('Kepler-1536', 0.67).
estrella('Kepler-726', 0.85).
estrella('Kepler-1400', 0.78).
estrella('Kepler-896', 0.81).
estrella('HD 190360', 1.07528).
estrella('Kepler-823', 0.96).
estrella('Kepler-1490', 0.87).
estrella('Kepler-760', 0.85).
estrella('Kepler-1558', 0.79).
estrella('Kepler-1618', 1.65).
estrella('HD 65216', 0.88536).
estrella('Kepler-343', 1.433).
estrella('Kepler-593', 1.1).
estrella('Kepler-1482', 0.84).
estrella('Kepler-1004', 3.39).
estrella('Kepler-356', 1.335).
estrella('Kepler-968', 0.7).
estrella('HAT-P-13', 1.56).
estrella('Kepler-448', 1.63).
estrella('GJ 3634', 0.43).
estrella('Kepler-1070', 1.32).
estrella('Kepler-1087', 0.94).
estrella('Kepler-1071', 0.81).
estrella('Kepler-1432', 1.13).
estrella('HD 130322', 0.986573).
estrella('Kepler-1422', 1.23).
estrella('Kepler-934', 0.77).
estrella('Kepler-742', 0.71).
estrella('Kepler-1050', 1.13).
estrella('Kepler-1298', 2).
estrella('Kepler-1297', 0.99).
estrella('Kepler-1613', 1.12).
estrella('Kepler-903', 0.97).
estrella('Kepler-348', 1.359).
estrella('Kepler-1543', 1.65).
estrella('Kepler-185', 0.806).
estrella('omega Ser', 12.3).
estrella('Kepler-111', 1.157).
estrella('Kepler-673', 0.84).
estrella('Kepler-965', 1.15).
estrella('Kepler-1295', 0.89).
estrella('HD 16175', 1.19707).
estrella('Kepler-235', 0.554).
estrella('Kepler-1436', 1.09).
estrella('HD 46375', 0.863012).
estrella('Kepler-114', 0.667).
estrella('Kepler-741', 1.24).
estrella('CoRoT-29', 0.9).
estrella('Kepler-868', 0.89).
estrella('Kepler-14', 2.048).
estrella('Kepler-234', 1.113).
estrella('Kepler-1308', 0.34).
estrella('Kepler-1302', 0.82).
estrella('CoRoT-13', 1.01).
estrella('HD 98219', 2.95355).
estrella('HD 12648', 9.2).
estrella('HAT-P-34', 1.197).
estrella('Kepler-654', 1.11).
estrella('Kepler-421', 0.757).
estrella('Kepler-1241', 0.8).
estrella('MOA-2010-BLG-477L', 0).
estrella('Kepler-1198', 0.9).
estrella('Kepler-1139', 0.91).
estrella('Kepler-1206', 0.75).
estrella('mu Leo', 11.4).
estrella('Kepler-431', 1.092).
estrella('Kepler-1531', 1.27).
estrella('Kepler-481', 1.09).
estrella('HD 139357', 7.76389).
estrella('HD 1461', 1.12553).
estrella('Kepler-1275', 1.36).
estrella('HAT-P-30', 1.215).
estrella('Kepler-430', 1.485).
estrella('Kepler-1360', 1.83).
estrella('Kepler-901', 0.57).
estrella('Kepler-251', 0.89).
estrella('HD 8535', 1.0437).
estrella('Kepler-1619', 1).
estrella('Kepler-1473', 1.09).
estrella('HAT-P-28', 1.103).
estrella('Kepler-474', 1.08).
estrella('HD 4203', 1.15783).
estrella('Kepler-331', 0.492).
estrella('HD 102956', 3.42909).
estrella('WTS-2', 0.761).
estrella('Kepler-362', 0.722).
estrella('Kepler-1147', 1.14).
estrella('Kepler-1083', 0.77).
estrella('Kepler-376', 1.175).
estrella('Kepler-1589', 1.25).
estrella('Fomalhaut', 1.842).
estrella('GJ 176', 0).
estrella('Kepler-873', 1.27).
estrella('HD 23079', 1.16249).
estrella('HD 178911 B', 0.894377).
estrella('WASP-58', 1.17).
estrella('Kepler-506', 1.19).
estrella('Kepler-1571', 1.39).
estrella('Kepler-543', 0.67).
estrella('Kepler-1535', 1.11).
estrella('Kepler-1030', 0.76).
estrella('Kepler-1067', 0.93).
estrella('Kepler-354', 0.674).
estrella('Kepler-1203', 0.61).
estrella('HD 162020', 0.526361).
estrella('Kepler-809', 0.98).
estrella('Kepler-1368', 1.08).
estrella('Kepler-183', 0.958).
estrella('Kepler-1392', 0.85).
estrella('MOA-bin-1L', 0).
estrella('Kepler-1556', 0.95).
estrella('Kepler-944', 0.83).
estrella('Kepler-1110', 0.7).
estrella('Kepler-210', 0.65).
estrella('Kepler-437', 0.68).
estrella('HD 168746', 0.888361).
estrella('GJ 876', 0).
estrella('Kepler-1164', 0.79).
estrella('Kepler-958', 0.86).
estrella('Kepler-712', 0.78).
estrella('Kepler-580', 0.64).
estrella('Kepler-755', 0.77).
estrella('Kepler-260', 0.862).
estrella('Kepler-255', 0.933).
estrella('Kepler-750', 1.23).
estrella('HD 215497', 1.10659).
estrella('Kepler-1221', 0.82).
estrella('Kepler-1160', 0.89).
estrella('HATS-5', 0.871).
estrella('HD 154345', 1).
estrella('Kepler-1031', 1.12).
estrella('Kepler-523', 0.86).
estrella('Kepler-1550', 1.11).
estrella('HD 7199', 1.11756).
estrella('Kepler-887', 1.29).
estrella('GJ 433', 0).
estrella('Kepler-1301', 0.81).
estrella('HD 159243', 1.12).
estrella('HAT-P-31', 1.36).
estrella('Kepler-878', 0.77).
estrella('OGLE-TR-113', 0.774).
estrella('Kepler-41', 0.966).
estrella('Kepler-798', 1.29).
estrella('Kepler-473', 1.34).
estrella('HD 285507', 0.656).
estrella('Kepler-1307', 1.08).
estrella('Kepler-1573', 1).
estrella('Kepler-590', 1.15).
estrella('Kepler-1220', 0.99).
estrella('Kepler-849', 1.64).
estrella('HD 290327', 0.997399).
estrella('Kepler-438', 0.52).
estrella('Kepler-1315', 0.75).
estrella('Kepler-1413', 0.8).
estrella('Kepler-1604', 0.76).
estrella('Kepler-1471', 0.93).
estrella('Kepler-1445', 1.26).
estrella('Kepler-1020', 0.8).
estrella('Kepler-572', 0.79).
estrella('Kepler-1598', 1.09).
estrella('Kepler-1187', 1.09).
estrella('Kepler-949', 0.86).
estrella('HD 169830', 1.80318).
estrella('Kepler-608', 1.01).
estrella('47 UMa', 1.11869).
estrella('Kepler-880', 1.74).
estrella('Kepler-1343', 0.93).
estrella('Kepler-575', 0.95).
estrella('Kepler-199', 0.967).
estrella('Kepler-917', 0.76).
estrella('Kepler-1072', 1.32).
estrella('Kepler-1212', 1.15).
estrella('Kepler-246', 0.831).
estrella('Kepler-347', 1.005).
estrella('HD 63765', 0.975102).
estrella('Kepler-217', 1.799).
estrella('HD 85390', 0.958233).
estrella('Kepler-1590', 1.16).
estrella('Kepler-1498', 0.81).
estrella('Kepler-1176', 1.02).
estrella('HAT-P-57', 1.5).
estrella('Kepler-525', 1.15).
estrella('Kepler-112', 0.841).
estrella('Kepler-1326', 1.74).
estrella('Kepler-748', 1.1).
estrella('Kepler-961', 0.9).
estrella('Kepler-241', 0.668).
estrella('Kepler-492', 0.91).
estrella('WASP-77 A', 0.955).
estrella('Kepler-164', 1.148).
estrella('Kepler-548', 0.9).
estrella('55 Cnc', 0.943).
estrella('Kepler-1254', 0.75).
estrella('HD 221287', 1.10236).
estrella('KOI-13', 1.71).
estrella('Kepler-1017', 0.87).
estrella('Kepler-1100', 1.34).
estrella('Kepler-1460', 0.67).
estrella('Kepler-1310', 0.88).
estrella('HD 192699', 3.61317).
estrella('Kepler-1371', 0.83).
estrella('Kepler-1090', 0.82).
estrella('Kepler-312', 1.467).
estrella('Kepler-1557', 1.17).
estrella('Kepler-1509', 0.99).
estrella('HD 181342', 4.76324).
estrella('WASP-8', 0.945).
estrella('HD 131496', 4.56407).
estrella('Kepler-911', 1.99).
estrella('HD 44219', 1.36324).
estrella('75 Cet', 10.5).
estrella('Kepler-40', 2.13).
estrella('Kepler-1538', 1.03).
estrella('Kepler-576', 0.97).
estrella('Kepler-479', 0.81).
estrella('Kepler-915', 1.38).
estrella('HD 220074', 54.7067).
estrella('Kepler-1185', 0.87).
estrella('Kepler-788', 1.23).
estrella('WASP-89', 0.88).
estrella('HAT-P-39', 1.625).
estrella('WASP-26', 1.34).
estrella('Kepler-751', 0.84).
estrella('WASP-71', 2.32).
estrella('HIP 2247', 1.07261).
estrella('OGLE-TR-56', 1.363).
estrella('Kepler-697', 0.88).
estrella('Kepler-826', 1.15).
estrella('Kepler-1591', 1.16).
estrella('Kepler-146', 1.208).
estrella('Kepler-1633', 1.32).
estrella('Kepler-156', 0.807).
estrella('Kepler-1353', 0.72).
estrella('Kepler-436', 0.697).
estrella('Kepler-1595', 0.8).
estrella('Kepler-1593', 0.77).
estrella('WASP-82', 2.18).
estrella('Kepler-1219', 1.94).
estrella('Kepler-737', 0.48).
estrella('Kepler-948', 0.94).
estrella('Kepler-1021', 0.86).
estrella('Kepler-866', 0.71).
estrella('BD +20 2457', 32.9639).
estrella('Kepler-497', 1.11).
estrella('Kepler-1344', 1.13).
estrella('HD 22781', 0.720445).
estrella('Kepler-1253', 1.1).
estrella('HD 120084', 10.9537).
estrella('HD 95127', 20).
estrella('MOA-2009-BLG-266L', 0).
estrella('Kepler-1578', 0.86).
estrella('Kepler-387', 1.046).
estrella('HD 20868', 1.15581).
estrella('Kepler-854', 1.27).
estrella('HAT-P-9', 1.32).
estrella('Kepler-410 A', 1.352).
estrella('Kepler-1527', 1.32).
estrella('Kepler-1024', 0.78).
estrella('Kepler-1271', 1.23).
estrella('Kepler-365', 1.048).
estrella('Kepler-1488', 1.31).
estrella('Kepler-19', 0.85).
estrella('Kepler-130', 1.127).
estrella('Kepler-598', 0.86).
estrella('Kepler-1391', 1.1).
estrella('Kepler-1516', 1.07).
estrella('HD 107148', 1.04161).
estrella('HD 1666', 1.93).
estrella('Kepler-200', 0.944).
estrella('Kepler-95', 1.41).
estrella('Kepler-1444', 1.05).
estrella('Kepler-280', 0.886).
estrella('Kepler-829', 0.97).
estrella('Kepler-812', 1.71).
estrella('HD 95872', 0.998651).
estrella('Kepler-1242', 0.74).
estrella('51 Peg', 1.02451).
estrella('WASP-60', 1.14).
estrella('Kepler-904', 1.25).
estrella('Kepler-1113', 1.17).
estrella('Kepler-99', 0.73).
estrella('Kepler-1394', 2.55).
estrella('Kepler-752', 0.83).
estrella('Kepler-996', 1.14).
estrella('Kepler-588', 1).
estrella('Kepler-1454', 0.86).
estrella('Kepler-1143', 0.77).
estrella('Kepler-153', 0.892).
estrella('Kepler-539', 0.95).
estrella('Kepler-929', 1.02).
estrella('HAT-P-54', 0.617).
estrella('HIP 67851', 5.92).
estrella('Kepler-845', 0.75).
estrella('HD 212301', 0).
estrella('Kepler-574', 0.91).
estrella('Kepler-865', 0.92).
estrella('GJ 504', 0.912273).
estrella('HAT-P-15', 1.08).
estrella('HD 209458', 1.155).
estrella('Kepler-729', 0.91).
estrella('HD 102272', 12.7057).
estrella('Kepler-898', 0.62).
estrella('HD 187123', 1.14277).
estrella('Kepler-1481', 0.75).
estrella('HD 108147', 1.29703).
estrella('Kepler-1617', 1.22).
estrella('WASP-61', 1.36).
estrella('eta Cet', 14.3).
estrella('Kepler-606', 1.22).
estrella('Kepler-686', 0.92).
estrella('Kepler-957', 0.75).
estrella('Kepler-1099', 1).
estrella('Kepler-1345', 1.55).
estrella('Kepler-1325', 0.91).
estrella('Kepler-1624', 0.47).
estrella('Kepler-1086', 0.66).
estrella('Kepler-662', 0.74).
estrella('CoRoT-17', 1.5121).
estrella('xi Aql', 10.45).
estrella('Kepler-1058', 0.69).
estrella('Kepler-892', 0.72).
estrella('HD 33564', 0).
estrella('Kepler-1243', 0.94).
estrella('Kepler-635', 1.51).
estrella('Kepler-890', 1.13).
estrella('HD 40979', 1.27973).
estrella('Kepler-959', 2.01).
estrella('Kepler-945', 0.97).
estrella('Kepler-1303', 1).
estrella('WASP-31', 1.252).
estrella('Kepler-1496', 1.27).
estrella('bet UMi', 38.3).
estrella('HD 134987', 1.16572).
estrella('Kepler-1118', 0.97).
estrella('Kepler-1286', 0.98).
estrella('Kepler-102', 0.74).
estrella('WASP-101', 1.29).
estrella('Kepler-1395', 1.23).
estrella('iota Dra', 11.99).
estrella('HD 108874', 1.12115).
estrella('Kepler-250', 0.805).
estrella('Kepler-187', 1.287).
estrella('Kepler-991', 0.61).
estrella('Kepler-563', 0.77).
estrella('Kepler-1119', 1.17).
estrella('Kepler-383', 0.672).
estrella('HD 23596', 1.96615).
estrella('Kepler-1630', 0.63).
estrella('HD 25171', 1.06877).
estrella('HD 83443', 0.942509).
estrella('Kepler-287', 1.032).
estrella('WASP-36', 0.943).
estrella('Kepler-1358', 0.79).
estrella('Kepler-213', 1.195).
estrella('Kepler-532', 0.79).
estrella('HD 43691', 1.34586).
estrella('Kepler-149', 0.953).
estrella('30 Ari B', 1.02283).
estrella('Kepler-1120', 0.74).
estrella('Kepler-1597', 1.39).
estrella('HAT-P-6', 1.46).
estrella('Kepler-35', 1.0284).
estrella('Kepler-1581', 1.23).
estrella('Kepler-551', 0.63).
estrella('Kepler-850', 1.09).
estrella('Kepler-138', 0.442).
estrella('Kepler-611', 1.01).
estrella('Kepler-951', 0.73).
estrella('4 UMa', 34.6101).
estrella('Qatar-1', 0.823).
estrella('Kepler-794', 1.38).
estrella('HD 10697', 1.54131).
estrella('Kepler-597', 0.95).
estrella('Kepler-1433', 1.19).
estrella('Kepler-194', 1.025).
estrella('Kepler-1121', 1.59).
estrella('Kepler-1575', 0.92).
estrella('Kepler-535', 1.27).
estrella('HD 113337', 1.5).
estrella('Kepler-1152', 0.53).
estrella('HD 3651', 0.934685).
estrella('Kepler-714', 1.12).
estrella('Kepler-1236', 0.82).
estrella('Kepler-442', 0.598).
estrella('Kepler-1193', 1.21).
estrella('Kepler-1262', 0.98).
estrella('HD 99706', 5.26341).
estrella('Kepler-1367', 0.6).
estrella('Kepler-491', 1.03).
estrella('HD 175541', 3.07498).
estrella('Kepler-324', 0.84).
estrella('Kepler-462', 2.04).
estrella('Kepler-568', 0.53).
estrella('Kepler-1149', 1.01).
estrella('HD 202206', 0.985786).
estrella('Kepler-1116', 0.93).
estrella('Kepler-1146', 0.7).
estrella('Kepler-940', 0.96).
estrella('Kepler-1103', 1.15).
estrella('Kepler-1117', 0.93).
estrella('Kepler-571', 0.9).
estrella('Kepler-843', 1.03).
estrella('Kepler-936', 0.89).
estrella('Kepler-1339', 0.93).
estrella('Kepler-1005', 1.06).
estrella('HD 145457', 9.54834).
estrella('Kepler-465', 1.29).
estrella('Kepler-336', 1.304).
estrella('Kepler-1584', 1.13).
estrella('Kepler-1475', 1.28).
estrella('HD 206610', 4.98482).
estrella('M 67 SAND 364', 20.1708).
estrella('Kepler-711', 0.8).
estrella('Kepler-1610', 0.87).
estrella('Kepler-838', 0.96).
estrella('Kepler-802', 0.9).
estrella('Kepler-1412', 1.27).
estrella('Kepler-864', 1).
estrella('Kepler-12', 1.483).
estrella('Kepler-1411', 0.92).
estrella('Kepler-1545', 0.8).
estrella('HAT-P-36', 1.096).
estrella('WASP-35', 1.09).
estrella('CoRoT-22', 1.136).
estrella('HD 28254', 1.56874).
estrella('HD 81688', 20.8234).
estrella('HD 210277', 0.939154).
estrella('Kepler-1514', 1.22).
estrella('WTS-1', 1.15).
estrella('Kepler-717', 0.85).
estrella('Kepler-252', 0.549).
estrella('XO-1', 0.934).
estrella('Kepler-63', 0.901).
estrella('Kepler-1423', 0.75).
estrella('Kepler-537', 0.99).
estrella('Kepler-989', 0.78).
estrella('Kepler-100', 1.49).
estrella('GJ 15 A', 0.3863).
estrella('Kepler-1523', 0.96).
estrella('Kepler-1226', 1.02).
estrella('Kepler-1623', 1).
estrella('Kepler-1525', 1.04).
estrella('Kepler-749', 0.75).
estrella('Kepler-565', 0.95).
estrella('Kepler-631', 1.33).
estrella('Kepler-1592', 1.28).
estrella('Kepler-1097', 0.79).
estrella('Kepler-131', 1.03).
estrella('Kepler-74', 1.51).
estrella('M 67 YBP 1514', 0.86358).
estrella('WASP-55', 1.06).
estrella('Kepler-1064', 0.79).
estrella('HAT-P-56', 1.428).
estrella('Kepler-1277', 0.92).
estrella('Kepler-1144', 0.96).
estrella('GJ 3293', 0.404).
estrella('Kepler-547', 0.73).
estrella('HD 33283', 1.45431).
estrella('Kepler-1312', 0.92).
estrella('Kepler-842', 0.73).
estrella('OGLE-TR-111', 0.831).
estrella('MOA-2007-BLG-400L', 0).
estrella('Kepler-704', 0.96).
estrella('Kepler-1532', 0.88).
estrella('Kepler-647', 1.07).
estrella('Kepler-765', 1.06).
estrella('Kepler-1016', 1).
estrella('HD 155233', 5.03).
estrella('WASP-3', 1.31).
estrella('HD 148156', 0.965665).
estrella('Kepler-1266', 0.76).
estrella('TrES-5', 0.866).
estrella('Kepler-1306', 0.97).
estrella('Kepler-1483', 1.4).
estrella('Kepler-645', 1.21).
estrella('HD 222155', 1.67).
estrella('Kepler-761', 0.93).
estrella('Kepler-1278', 1.16).
estrella('Kepler-391', 3.569).
estrella('Kepler-768', 0.78).
estrella('Kepler-879', 1.02).
estrella('Kepler-1428', 1.36).
estrella('Kepler-1036', 0.89).
estrella('Kepler-1129', 1).
estrella('HD 117207', 0.951872).
estrella('Kepler-1140', 0.73).
estrella('Kepler-1565', 0.73).
estrella('Kepler-1645', 1.02).
estrella('Kepler-769', 1.28).
estrella('Kepler-1239', 1.57).
estrella('HD 121504', 0.844267).
estrella('Kepler-1089', 0.49).
estrella('Kepler-499', 0.83).
estrella('Kepler-852', 1.16).
estrella('Kepler-1354', 1.24).
estrella('Kepler-1366', 0.6).
estrella('HD 156846', 1.58242).
estrella('Kepler-1548', 0.97).
estrella('HAT-P-23', 1.203).
estrella('HD 224693', 1.17028).
estrella('Kepler-1401', 1.1).
estrella('Kepler-505', 0.53).
estrella('Kepler-388', 0.586).
estrella('Kepler-862', 0.84).
estrella('Kepler-795', 0.96).
estrella('Kepler-941', 0.86).
estrella('HD 158038', 5.30151).
estrella('Kepler-1502', 1.72).
estrella('Kepler-888', 0.9).
estrella('Kepler-822', 1.08).
estrella('Kepler-1469', 0.89).
estrella('Kepler-1334', 0.91).
estrella('Kepler-508', 1.25).
estrella('Kepler-1091', 1.03).
estrella('GJ 179', 0).
estrella('Kepler-22', 0.979).
estrella('Kepler-1101', 0.91).
estrella('Kepler-1369', 0.99).
estrella('Kepler-986', 0.98).
estrella('Kepler-937', 1.22).
estrella('HD 143361', 0).
estrella('Kepler-715', 1.04).
estrella('Kepler-134', 1.176).
estrella('Kepler-644', 1.81).
estrella('Kepler-1108', 0.84).
estrella('WASP-64', 1.058).
estrella('upsilon And', 1.383).
estrella('Kepler-56', 3.14).
estrella('Kepler-1267', 1.2).
estrella('Kepler-1138', 0.92).
estrella('Kepler-237', 0.725).
estrella('HD 86081', 1.18909).
estrella('WASP-74', 1.64).
estrella('HD 109246', 1.00892).
estrella('WASP-68', 1.69).
estrella('Kepler-81', 0.595).
estrella('Kepler-1631', 0.95).
estrella('Kepler-589', 0.83).
estrella('Kepler-701', 0.84).
estrella('Kepler-1300', 1.79).
estrella('Kepler-1485', 1.12).
estrella('Kepler-1632', 1.19).
estrella('Kepler-1075', 0.54).
estrella('K2-25', 0.295).
estrella('Kepler-902', 0.93).
estrella('CoRoT-23', 1.61).
estrella('Kepler-1158', 1.95).
estrella('Kepler-821', 0.8).
estrella('Kepler-684', 0.86).
estrella('Kepler-1082', 1.14).
estrella('Kepler-1474', 1.04).
estrella('WASP-39', 0.895).
estrella('Kepler-1463', 0.95).
estrella('Kepler-1377', 0.82).
estrella('Kepler-984', 0.93).
estrella('Kepler-385', 1.126).
estrella('HD 164509', 1.05601).
estrella('HD 9446', 0.919448).
estrella('HD 18742', 5.60612).
estrella('Kepler-636', 0.8).
estrella('Kepler-745', 1.04).
estrella('Kepler-517', 0.98).
estrella('Kepler-345', 0.623).
estrella('WASP-80', 0.571).
estrella('HD 167042', 4.21565).
estrella('Kepler-1373', 1.33).
estrella('Kepler-152', 0.724).
estrella('Kepler-743', 0.85).
estrella('Kepler-983', 1.08).
estrella('Kepler-8', 1.486).
estrella('Kepler-1014', 0.84).
estrella('Kepler-646', 0.91).
estrella('Kepler-1272', 1.09).
estrella('Kepler-353', 0.504).
estrella('HD 114762', 0.859205).
estrella('Kepler-804', 1.05).
estrella('HD 45652', 1.13465).
estrella('Kepler-1244', 1.77).
estrella('Kepler-1386', 1.03).
estrella('Kepler-978', 1.09).
estrella('Kepler-1404', 0.8).
estrella('Kepler-735', 0.8).
estrella('HAT-P-14', 1.468).
estrella('Kepler-972', 1.22).
estrella('Kepler-317', 0.941).
estrella('Kepler-1572', 0.95).
estrella('Kepler-301', 0.9).
estrella('Kepler-1363', 0.72).
estrella('Kepler-668', 0.82).
estrella('Kepler-1013', 0.76).
estrella('Kepler-796', 1.09).
estrella('Kepler-1634', 0.89).
estrella('HIP 105854', 7.73738).
estrella('WASP-66', 1.75).
estrella('HD 73256', 1.21851).
estrella('Kepler-1427', 1.01).
estrella('Kepler-303', 0.485).
estrella('Kepler-1274', 2.17).
estrella('Kepler-1032', 0.71).
estrella('6 Lyn', 5.49553).
estrella('Kepler-1487', 1.63).
estrella('HD 180314', 7.38571).
estrella('HD 17092', 11.8).
estrella('Kepler-780', 1.02).
estrella('Kepler-931', 0.81).
estrella('Kepler-1246', 0.69).
estrella('Kepler-1169', 1.23).
estrella('Kepler-1105', 0.68).
estrella('Kepler-93', 0.92).
estrella('WASP-94 A', 1.36).
estrella('WASP-5', 1.026).
estrella('Kepler-78', 0.74).
estrella('CoRoT-2', 0.902).
estrella('Kepler-447', 1.05).
estrella('Kepler-522', 1.98).
estrella('Kepler-1615', 1.05).
estrella('Kepler-894', 0.85).
estrella('Kepler-1609', 1.27).
estrella('Kepler-289', 1.162).
estrella('Kepler-1524', 1.25).
estrella('Kepler-1403', 1.15).
estrella('Kepler-953', 0.99).
estrella('Kepler-1479', 0.98).
estrella('HD 33142', 4.29546).
estrella('HAT-P-20', 0.694).
estrella('Kepler-834', 0.66).
estrella('Kepler-439', 0.866).
estrella('Kepler-1060', 0.99).
estrella('Kepler-1150', 0.72).
estrella('CoRoT-5', 1.186).
estrella('Kepler-1184', 1.07).
estrella('OGLE-2011-BLG-0251', 0).
estrella('Kepler-1566', 0.81).
estrella('Kepler-161', 0.806).
estrella('Kepler-943', 0.91).
estrella('Kepler-899', 0.91).
estrella('HAT-P-35', 1.435).
estrella('HD 99109', 0.973205).
estrella('Kepler-1347', 0.79).
estrella('Kepler-649', 0.94).
estrella('Kepler-778', 0.77).
estrella('Kepler-744', 0.93).
estrella('Kepler-5', 1.793).
estrella('HD 10647', 1.18569).
estrella('Kepler-675', 0.75).
estrella('Kepler-600', 0.81).
estrella('HATS-9', 1.503).
estrella('Kepler-782', 1.01).
estrella('Kepler-1407', 1.15).
estrella('Kepler-816', 0.85).
estrella('Kepler-1205', 0.81).
estrella('Kepler-1585', 0.91).
estrella('Kepler-621', 0.68).
estrella('Kepler-412', 1.287).
estrella('WASP-12', 1.63).
estrella('HD 170469', 1.22117).
estrella('Kepler-285', 0.808).
estrella('HD 88133', 1.94267).
estrella('HD 196885', 1.29927).
estrella('HD 190228', 1.73503).
estrella('Kepler-510', 1.41).
estrella('Kepler-762', 1.08).
estrella('HD 181720', 1.2465).
estrella('Kepler-1125', 0.94).
estrella('Kepler-995', 0.8).
estrella('HD 156411', 1.85525).
estrella('Kepler-1196', 0.97).
estrella('HATS-3', 1.404).
estrella('Kepler-101', 1.666).
estrella('Kepler-536', 0.89).
estrella('Kepler-680', 1.11).
estrella('91 Aqr', 11).
estrella('Kepler-1126', 0.93).
estrella('Kepler-860', 1.06).
estrella('Kepler-676', 0.49).
estrella('Kepler-1596', 0.92).
estrella('Kepler-404', 0.884).
estrella('Kepler-279', 1.746).
estrella('HD 27894', 1.20255).
estrella('Kepler-1256', 1.36).
estrella('HD 156279', 0.958138).
estrella('Kepler-411', 0.79).
estrella('Kepler-502', 1.22).
estrella('Kepler-297', 0.915).
estrella('Kepler-1449', 1.1).
estrella('Kepler-141', 0.787).
estrella('Kepler-1399', 0.96).
estrella('HD 179079', 1.33814).
estrella('Kepler-504', 0.33).
estrella('OGLE-05-390L', 0).
estrella('WASP-4', 0.914).
estrella('Kepler-432', 4.06).
estrella('Kepler-1026', 0.75).
estrella('HD 4113', 1.07428).
estrella('Kepler-488', 1.09).
estrella('HD 330075', 1.20726).
estrella('Kepler-1029', 0.77).
estrella('Kepler-754', 1.08).
estrella('HD 104985', 7.09522).
estrella('HATS-10', 1.105).
estrella('Kepler-691', 0.5).
estrella('Kepler-1537', 0.77).
estrella('HD 87883', 0.778353).
estrella('WASP-135', 0.96).
estrella('Kepler-657', 1.01).
estrella('Kepler-1092', 1).
estrella('Kepler-1214', 0.8).
estrella('Kepler-482', 0.72).
estrella('Kepler-1495', 1.04).
estrella('WASP-94 B', 1.35).
estrella('Kepler-1174', 1.04).
estrella('Kepler-581', 1).
estrella('Kepler-693', 0.72).
estrella('Kepler-1102', 0.94).
estrella('Kepler-652', 0.88).
estrella('Kepler-420', 1.13).
estrella('HD 66428', 0.979625).
estrella('HD 52265', 1.34703).
estrella('HATS-14', 0.933).
estrella('Kepler-75', 0.88).
estrella('Kepler-554', 0.92).
estrella('Kepler-1294', 0.97).
estrella('Kepler-1282', 0.89).
estrella('Kepler-740', 0.87).
estrella('HD 16417', 1.45645).
estrella('Kepler-15', 0.992).
estrella('HD 205739', 1.46292).
estrella('Kepler-851', 0.85).
estrella('Kepler-1342', 0.9).
estrella('Kepler-781', 0.78).
estrella('Kepler-1161', 0.57).
estrella('CoRoT-16', 1.19).
estrella('HD 216770', 1.03957).
estrella('HD 136418', 3.83357).
estrella('Kepler-907', 1.38).
estrella('Kepler-1402', 0.87).
estrella('Kepler-98', 1.11).
estrella('beta Pic', 0).
estrella('Kepler-1259', 0.77).
estrella('Kepler-1142', 0.96).
estrella('HD 188015', 1.03281).
estrella('WASP-59', 0.613).
estrella('WASP-54', 1.828).
estrella('HAT-P-8', 1.58).
estrella('Kepler-1533', 1.51).
estrella('WASP-15', 1.477).
estrella('Kepler-425', 0.86).
estrella('Kepler-767', 0.94).
estrella('XO-4', 0).
estrella('WASP-48', 1.75).
estrella('Kepler-566', 0.79).
estrella('WASP-32', 1.09).
estrella('OGLE-TR-211', 1.64).
estrella('gamma Cep', 5.01).
estrella('Kepler-1182', 1.05).
estrella('Kepler-617', 0.48).
estrella('Kepler-1035', 0.97).
estrella('GJ 86', 0.748264).
estrella('Kepler-470', 1.66).
estrella('Kepler-1637', 1.02).
estrella('Kepler-1346', 1.21).
estrella('HD 8574', 1.42266).
estrella('MOA-2007-BLG-192L', 0).
estrella('HD 82886', 3.83685).
estrella('HD 179949', 1.22645).
estrella('Kepler-1167', 0.75).
estrella('HD 2952', 11.4311).
estrella('Kepler-1063', 1.14).
estrella('MOA-2009-BLG-319L', 0).
estrella('Kepler-1340', 1.42).
estrella('HD 28678', 6.33673).
estrella('WASP-56', 1.112).
estrella('Kepler-540', 1.08).
estrella('HATS-6', 0.57).
estrella('Kepler-739', 0.9).
estrella('Kepler-515', 0.83).
estrella('Kepler-947', 0.87).
estrella('Kepler-1560', 1.02).
estrella('Kepler-1230', 1.08).
estrella('Kepler-923', 1.26).
estrella('CoRoT-8', 0.77).
estrella('Kepler-723', 0.89).
estrella('Kepler-844', 0.57).
estrella('Kepler-1283', 1.25).
estrella('Kepler-1430', 0.72).
estrella('Kepler-1069', 0.98).
estrella('Kepler-1324', 0.73).
estrella('CoRoT-20', 1.02).
estrella('HD 96167', 1.98284).
estrella('HD 43197', 1.19673).
estrella('Kepler-912', 1.11).
estrella('Kepler-514', 1.44).
estrella('Kepler-998', 1.18).
estrella('Kepler-1335', 0.74).
estrella('HD 37605', 0.916831).
estrella('Kepler-1601', 1.07).
estrella('Kepler-659', 0.74).
estrella('Kepler-1332', 0.9).
estrella('Kepler-814', 1.22).
estrella('Kepler-1168', 0.82).
estrella('Kepler-955', 0.84).
estrella('Kepler-1328', 0.99).
estrella('Kepler-663', 0.82).
estrella('Kepler-624', 1.18).
estrella('Kepler-1526', 0.69).
estrella('Kepler-699', 0.78).
estrella('WASP-23', 0.765).
estrella('Kepler-594', 0.87).
estrella('11 Com', 12.0698).
estrella('HD 145377', 1.00052).
estrella('Kepler-1554', 0.81).
estrella('Kepler-650', 1.35).
estrella('Kepler-1429', 1.07).
estrella('CoRoT-25', 1.19).
estrella('omicron CrB', 10.5).
estrella('Kepler-954', 0.76).
estrella('Kepler-1408', 1.35).
estrella('Kepler-779', 0.44).
estrella('OGLE-TR-132', 1.32).
estrella('beta Gem', 8.15609).
estrella('Kepler-633', 1.15).
estrella('Kepler-1159', 1.28).
estrella('Kepler-1443', 1.27).
estrella('Pr 201', 1.12943).
estrella('Kepler-541', 2.06).
estrella('Kepler-625', 0.96).
estrella('WASP-52', 0.79).
estrella('Kepler-1186', 0.93).
estrella('Kepler-927', 0.99).
estrella('Kepler-660', 0.71).
estrella('Kepler-1385', 1.29).
estrella('HD 240210', 17.2701).
estrella('Kepler-1255', 1.12).
estrella('Kepler-906', 1.02).
estrella('Kepler-1625', 0.94).
estrella('Kepler-77', 0.99).
estrella('Kepler-719', 0.98).
estrella('HD 109749', 1.10733).
estrella('Kepler-1455', 0.6).
estrella('Kepler-775', 0.84).
estrella('Kepler-685', 1.16).
estrella('Kepler-500', 1.03).
estrella('Kepler-1162', 0.84).
estrella('Kepler-721', 0.78).
estrella('WASP-50', 0.843).
estrella('Kepler-1540', 0.69).
estrella('Kepler-607', 0.8).
estrella('Kepler-1317', 0.79).
estrella('Kepler-1507', 0.85).
estrella('Kepler-1384', 0.74).
estrella('Kepler-1007', 0.7).
estrella('Kepler-1477', 0.78).
estrella('Kepler-105', 1.16).
estrella('WASP-98', 0.7).
estrella('Kepler-1547', 1.18).
estrella('GJ 3470', 0.503).
estrella('K2-22', 0.57).
estrella('Kepler-696', 1.08).
estrella('Kepler-1133', 0.9).
estrella('Kepler-801', 0.63).
estrella('Kepler-1620', 1.23).
estrella('Kepler-1644', 0.86).
estrella('Kepler-789', 1.02).
estrella('Kepler-641', 1.13).
estrella('HD 96127', 23.2289).
estrella('HD 17156', 1.507).
estrella('Kepler-1038', 0.83).
estrella('Kepler-1137', 1.84).
estrella('Kepler-1264', 0.98).
estrella('Kepler-513', 1.06).
estrella('HAT-P-44', 0.949).
estrella('HD 16760', 0.909718).
estrella('HD 30562', 1.39121).
estrella('Kepler-46', 0.938).
estrella('Kepler-1215', 0.93).
estrella('WASP-100', 2).
estrella('Kepler-1465', 0.71).
estrella('epsilon CrB', 29.1175).
estrella('omicron UMa', 14.1).
estrella('TrES-2', 1.003).
estrella('Kepler-282', 0.904).
estrella('Kepler-614', 0.81).
estrella('Kepler-1018', 0.88).
estrella('Kepler-799', 0.93).
estrella('Kepler-857', 0.99).
estrella('Kepler-979', 0.83).
estrella('HD 11755', 27.3).
estrella('HD 102195', 0.937994).
estrella('Kepler-1320', 0.74).
estrella('Kepler-855', 1.03).
estrella('Kepler-1600', 0.82).
estrella('Kepler-1189', 1.16).
estrella('HD 75289', 1.23372).
estrella('Kepler-394', 1.132).
estrella('HD 185269', 2.59).
estrella('WASP-7', 1.236).
estrella('BD -10 3166', 0.745254).
estrella('Kepler-1431', 1.03).
estrella('Kepler-1163', 1.35).
estrella('GJ 317', 0).
estrella('Kepler-526', 1.14).
estrella('Kepler-591', 0.94).
estrella('WASP-44', 0.927).
estrella('Kepler-602', 1.13).
estrella('Kepler-1023', 0.89).
estrella('Kepler-1362', 0.74).
estrella('Kepler-708', 0.96).
estrella('CoRoT-12', 1.116).
estrella('CoRoT-1', 1.11).
estrella('Kepler-1202', 1.04).
estrella('Kepler-753', 0.65).
estrella('Kepler-1134', 0.81).
estrella('HD 75784', 3.3).
estrella('Kepler-622', 0.61).
estrella('HD 102117', 1.13334).
estrella('Kepler-1114', 0.83).
estrella('Kepler-1059', 0.72).
estrella('HD 189733', 0.756).
estrella('HD 108863', 7.27656).
estrella('Kepler-582', 0.91).
estrella('Kepler-629', 0.84).
estrella('HD 10442', 3.39124).
estrella('Kepler-1213', 1.21).
estrella('Kepler-867', 0.91).
estrella('Kepler-1438', 0.96).
estrella('HD 1502', 4.48335).
estrella('HD 142022', 1.09856).
estrella('Kepler-1061', 1.07).
estrella('Kepler-766', 1.15).
estrella('WASP-72', 1.71).
estrella('Kepler-819', 0.81).
estrella('HD 212771', 4.00571).
estrella('Kepler-441', 0.55).
estrella('Kepler-1228', 0.74).
estrella('Kepler-956', 1.15).
estrella('HD 101930', 1.19859).
estrella('Kepler-1281', 0.83).
estrella('Kepler-1640', 1.43).
estrella('Kepler-914', 1.15).
estrella('HD 131664', 1.06217).
estrella('HIP 57050', 0).
estrella('GJ 687', 0.4183).
estrella('WASP-73', 2.07).
estrella('Kepler-1467', 0.82).
estrella('Kepler-643', 2.52).
estrella('WASP-67', 0.87).
estrella('Kepler-1055', 0.94).
estrella('Kepler-1329', 0.69).
estrella('Kepler-531', 0.75).
estrella('Kepler-1261', 0.77).
estrella('Kepler-1521', 0.76).
estrella('HD 92788', 0.813756).
estrella('Kepler-694', 0.95).
estrella('CoRoT-26', 1.79).
estrella('HAT-P-12', 0.701).
estrella('Kepler-994', 0.54).
estrella('Kepler-1417', 1.02).
estrella('HD 114613', 1.91632).
estrella('Kepler-483', 1.47).
estrella('Kepler-1435', 1.32).
estrella('Kepler-1405', 1.07).
estrella('Kepler-1397', 1.12).
estrella('HATS-2', 0.898).
estrella('HD 19994', 1.40403).
estrella('WASP-29', 0.808).
estrella('OGLE-TR-182', 1.14).
estrella('Kepler-1289', 1.17).
estrella('Kepler-1576', 1.06).
estrella('HD 85512', 0.881928).
estrella('HD 106252', 1.12257).
estrella('Kepler-1304', 0.81).
estrella('Kepler-1546', 0.93).
estrella('Kepler-1250', 0.98).
estrella('18 Del', 9).
estrella('Kepler-1437', 0.9).
estrella('Kepler-618', 1.08).
estrella('Kepler-34', 1.1618).
estrella('Kepler-1085', 1.14).
estrella('HD 171028', 2.14418).
estrella('WASP-1', 1.517).
estrella('XO-5', 1.05).
estrella('HAT-P-3', 0.833).
estrella('Kepler-1175', 0.86).
estrella('Kepler-1421', 1.42).
estrella('Kepler-1626', 1.85).
estrella('Kepler-718', 1.3).
estrella('Kepler-1583', 0.91).
estrella('Kepler-1529', 0.77).
estrella('Kepler-1446', 0.75).
estrella('Kepler-1098', 0.99).

%%
%% planeta(P, M, O): P es un planeta con masa M y 
%%       periodo orbital O.
%%    - La masa se mide con respecto a la tierra (Tierra = 1m)
%%    - El periodo orbital se mide en días terrestres
%%
planeta('Kepler-107 d', 1.17984281982525, 7.958203).
planeta('Kepler-1049 b', 0.779632421298996, 3.27346074).
planeta('Kepler-813 b', 5.07543379102217, 19.12947337).
planeta('Kepler-427 b', 92.16677829868, 10.290994).
planeta('Kepler-1056 b', 8.62112153382008, 27.495606).
planeta('Kepler-1165 b', 3.68168141326, 9.478522).
planeta('Kepler-1104 b', 1.93640176490188, 5.03728015).
planeta('WASP-14 b', 2444.75239785541, 2.243752).
planeta('Kepler-50 b', 5.24127042866442, 7.8125124).
planeta('NN Ser d', 204.235542196814, 2605).
planeta('Kepler-1279 b', 4.1007224380421, 23.4774101).
planeta('Kepler-1599 b', 3.83989045545683, 122.363553).
planeta('Kepler-20 b', 8.47444922973442, 3.6961219).
planeta('HAT-P-27 b', 196.246907233657, 3.039577).
planeta('Kepler-181 b', 2.14319859008597, 3.137873).
planeta('HD 116029 b', 606.23492967149, 670).
planeta('Kepler-207 b', 3.72782836570471, 1.611865).
planeta('Kepler-1156 b', 2.46108180843812, 11.89520511).
planeta('Kepler-1512 b', 1.64858080709895, 20.35972599).
planeta('Kepler-787 b', 2.18865588077583, 0.9283105).
planeta('Kepler-528 b', 4.91941768251589, 19.78297415).
planeta('HD 219828 b', 19.7740644675049, 3.8334999).
planeta('Kepler-480 b', 7.42145967849585, 4.9195838).
planeta('Kepler-1567 b', 7.21624557936668, 153.979578).
planeta('Kepler-1390 b', 1.64858080709895, 6.48021673).
planeta('Kepler-1642 b', 9.68602920294211, 12.2057513).
planeta('Kepler-11 c', 2.89987512725906, 13.0241).
planeta('Kepler-871 b', 13.9051382786265, 22.0459018).
planeta('Kepler-1131 b', 3.7714327863343, 3.53232449).
planeta('Kepler-705 b', 4.98104229738525, 56.0560538).
planeta('HD 1237 b', 1072.56704621512, 133.71001).
planeta('WASP-21 b', 95.4313891493146, 4.322482).
planeta('Kepler-284 c', 6.68024809108833, 37.514456).
planeta('Kepler-186 c', 2.02355339919521, 7.267302).
planeta('HD 4308 b', 15.1717958472795, 15.56).
planeta('Kepler-239 b', 5.65312880106876, 11.763051).
planeta('Kepler-651 b', 5.76989457467888, 21.38521506).
planeta('Kepler-80 f', 1.93640176490188, 0.98678706).
planeta('Kepler-1217 b', 4.68264440723135, 2.03232507).
planeta('Kepler-895 b', 3.65949782317293, 2.80624233).
planeta('Kepler-628 b', 77.353034494267, 15.4580567).
planeta('Kepler-174 b', 4.59371935699697, 13.98179).
planeta('Kepler-440 b', 4.35233774279749, 101.11141).
planeta('Kepler-403 d', 3.15041303415779, 13.61159129).
planeta('Kepler-224 d', 5.55578161419674, 11.349393).
planeta('Kepler-389 c', 3.42622052913421, 14.51143).
planeta('Kepler-674 b', 3.98011108506158, 2.24338185).
planeta('Kepler-1047 c', 0.882395200937255, 3.18897601).
planeta('Kepler-1247 b', 5.65795961151752, 13.71220213).
planeta('Kepler-1210 b', 4.00394732082848, 8.07124073).
planeta('Kepler-254 c', 5.10130405224118, 12.412183).
planeta('Kepler-236 c', 4.69494390488707, 23.968127).
planeta('WASP-25 b', 183.847297387715, 3.764825).
planeta('Kepler-186 d', 2.97115818486116, 13.342996).
planeta('Kepler-1646 b', 1.93640176490188, 4.48558383).
planeta('HD 24040 b', 1278.22291024717, 3668).
planeta('Kepler-359 c', 19.3165358673712, 57.68802).
planeta('Kepler-211 c', 2.26060317481464, 6.04045).
planeta('Kepler-967 b', 5.73226510381487, 13.22713379).
planeta('Kepler-1574 b', 2.2548506965829, 6.9424334).
planeta('Kepler-1157 b', 1.24868504688482, 4.45743164).
planeta('Kepler-549 b', 6.50697454788681, 42.9495649).
planeta('Kepler-1510 b', 10.8157396517024, 84.703921).
planeta('Kepler-1002 b', 4.02791068318614, 4.33642933).
planeta('Kepler-294 c', 7.10485090421604, 6.6264).
planeta('Kepler-263 c', 6.13862525116898, 47.332773).
planeta('Kepler-349 b', 4.44698348961593, 5.929778).
planeta('Kepler-1563 b', 0.336100458807597, 3.43276598).
planeta('Kepler-1611 b', 0.432859685197366, 5.1762429).
planeta('Kepler-1284 b', 1.81766552913503, 0.66407381).
planeta('HD 200964 b', 619.338503013747, 613.8).
planeta('Kepler-706 b', 317.816476892, 41.40831347).
planeta('HD 147018 b', 676.030606161742, 44.236).
planeta('HD 218566 b', 67.6542290689538, 225.7).
planeta('HD 45364 b', 59.4790358338609, 226.93).
planeta('Kepler-1177 b', 4.46023643670233, 106.247547).
planeta('Kepler-1364 b', 5.10740612859751, 13.32196237).
planeta('Kepler-653 b', 4.56975599463931, 14.70748976).
planeta('Kepler-553 b', 22.4879629269811, 4.03046804).
planeta('Kepler-361 b', 3.3491500334879, 8.486616).
planeta('Kepler-318 c', 13.3330686202209, 11.815007).
planeta('Kepler-372 b', 2.70371879772132, 6.849692).
planeta('Kepler-197 e', 0.662053037508032, 25.209715).
planeta('HD 141937 b', 3011.37468184708, 653.21997).
planeta('Kepler-405 c', 22.7960224380325, 29.726682).
planeta('Kepler-104 d', 12.4821150033425, 51.755394).
planeta('Kepler-702 b', 168.914690220945, 10.52629406).
planeta('Kepler-26 d', 1.17984281982525, 3.543919).
planeta('Kepler-159 b', 5.8204591761524, 10.139623).
planeta('HD 156668 b', 4.15011111855111, 4.6455).
planeta('MOA-2009-BLG-387L b', 826.3228399192, 1970).
planeta('Kepler-1045 b', 7.01795987943377, 26.41045478).
planeta('Kepler-905 b', 3.06848948090934, 5.08274652).
planeta('Kepler-763 b', 1.8764266175476, 1.19655156).
planeta('Kepler-1376 b', 1.11701368050847, 5.30880656).
planeta('Kepler-32 f', 0.45641942062937, 0.74296).
planeta('WASP-103 b', 472.882314132376, 0.925542).
planeta('Kepler-990 c', 3.94928288680306, 0.53835431).
planeta('Kepler-221 e', 6.76253077695567, 18.369917).
planeta('Kepler-1028 b', 2.53240300401745, 2.51462432).
planeta('Kepler-256 c', 5.10130405224118, 3.38802).
planeta('GJ 649 b', 103.39873040852, 598.3).
planeta('Kepler-1333 b', 7.58005010046496, 109.6471842).
planeta('Kepler-276 b', 7.85604192899797, 14.12841).
planeta('Kepler-1042 b', 5.20497578700335, 10.13202575).
planeta('Kepler-264 c', 7.65959956463102, 140.101261).
planeta('HD 132406 b', 1781.34546215582, 974).
planeta('Kepler-143 b', 5.92406734761919, 16.007583).
planeta('Kepler-1225 b', 4.25057290689668, 7.01075434).
planeta('Kepler-189 c', 5.8204591761524, 20.134866).
planeta('HD 38529 c', 3896.52535163899, 2146.0503).
planeta('Kepler-62 b', 0, 5.714932).
planeta('Kepler-281 b', 7.6114185867342, 14.646008).
planeta('Kepler-1006 b', 3.65949782317293, 19.76172042).
planeta('Kepler-196 c', 5.36772960481975, 47.427737).
planeta('Kepler-238 c', 5.85475157400905, 6.155557).
planeta('Kepler-49 c', 6.43200164098799, 10.9129343).
planeta('Kepler-55 c', 5.27098626925382, 42.1516418).
planeta('Kepler-791 b', 8.81034946416158, 14.5539759).
planeta('WASP-19 b', 360.210016744624, 0.78884).
planeta('Kepler-310 d', 6.13862525116898, 92.876125).
planeta('Kepler-619 c', 3.98011108506158, 1.20846503).
planeta('Kepler-204 c', 4.19225358338699, 25.660593).
planeta('Kepler-26 b', 12.6211597119828, 12.282356).
planeta('Kepler-374 c', 1.30105802411186, 3.282807).
planeta('Kepler-395 b', 1.03012901205573, 7.054346).
planeta('HD 126614 A b', 122.583722036106, 1244).
planeta('Kepler-875 b', 8.02334052243392, 27.5073799).
planeta('Kepler-1508 b', 2.53240300401745, 20.7056504).
planeta('Kepler-1568 b', 2.32231360013276, 20.925392).
planeta('Kepler-80 e', 3.87014658405695, 4.645387).
planeta('Kepler-83 d', 4.54413998660182, 5.169796).
planeta('Kepler-519 b', 4.95011875418366, 24.3078946).
planeta('Kepler-192 d', 0.994841848626414, 6.47027579).
planeta('Kepler-167 b', 3.3491500334879, 4.393147).
planeta('Kepler-772 b', 4.25057290689668, 12.99207337).
planeta('Kepler-295 d', 2.70371879772132, 33.884054).
planeta('Kepler-337 b', 3.6681424313444, 3.292781).
planeta('HD 177830 b', 419.412870060066, 410.1).
planeta('Kepler-516 b', 35.009709644992, 24.85462415).
planeta('Kepler-1562 b', 12.2637750837177, 64.2737752).
planeta('Kepler-226 d', 1.86700335900775, 8.109044).
planeta('HD 38283 b', 107.471866376368, 363.2).
planeta('Kepler-386 b', 2.90930156396367, 12.31043).
planeta('Kepler-922 b', 3.15041303415779, 0.93846683).
planeta('HD 217786 b', 4190.98231747943, 1319).
planeta('Kepler-363 c', 3.97467642330673, 7.542427).
planeta('Kepler-687 b', 11.9946480910856, 20.50586978).
planeta('Kepler-1457 b', 4.68264440723135, 51.1110243).
planeta('Kepler-567 b', 5.40777448090814, 16.54297375).
planeta('Kepler-1453 b', 6.92140723375398, 47.1611696).
planeta('Kepler-24 d', 3.93253395847085, 4.244384).
planeta('HD 32518 b', 1063.25184527742, 157.54).
planeta('Kepler-980 b', 6.92140723375398, 11.55102504).
planeta('Kepler-472 b', 9.82904661754351, 4.17625551).
planeta('Kepler-402 c', 3.70783770930821, 6.124821).
planeta('Kepler-435 b', 266.96584058928, 8.6001536).
planeta('WASP-18 b', 3241.91875418454, 0.9414529).
planeta('CoRoT-6 b', 938.715458807287, 8.886593).
planeta('Kepler-127 c', 6.88841788345259, 29.393195).
planeta('Kepler-839 b', 6.50697454788681, 37.8144514).
planeta('Kepler-203 c', 6.13862525116898, 5.370647).
planeta('Kepler-1234 b', 7.58005010046496, 11.94014029).
planeta('Kepler-1127 b', 4.59766028131043, 5.12330347).
planeta('Kepler-732 c', 2.12372279638203, 0.89304124).
planeta('HD 73267 b', 973.335207635133, 1260).
planeta('HD 147513 b', 374.912206965648, 528.40002).
planeta('Kepler-1528 b', 3.40432297387635, 1.79111021).
planeta('Kepler-893 b', 8.68369959812012, 6.33855761).
planeta('Kepler-1387 b', 0.716224855994274, 2.27952666).
planeta('Kepler-1062 b', 4.12528965170585, 9.30412078).
planeta('HD 72659 b', 1008.7812793029, 3658).
planeta('BD +14 4559 b', 482.855395177247, 268.94).
planeta('HD 1605 b', 307.973700602655, 577.9).
planeta('Kepler-79 b', 10.9011051573956, 13.485).
planeta('Kepler-202 b', 3.84952029470666, 4.069427).
planeta('Kepler-709 b', 8.13893037507954, 16.08524954).
planeta('HD 197037 b', 256.580869390357, 1035.7).
planeta('HD 70642 b', 606.851493636661, 2068).
planeta('KELT-2 A b', 483.284447421051, 4.1137912).
planeta('Kepler-10 b', 4.5391820495623, 0.837495).
planeta('Kepler-208 e', 3.58376215672957, 16.259458).
planeta('Kepler-1365 b', 0.685994152712306, 7.69993485).
planeta('Kepler-270 c', 4.14775927662211, 25.262887).
planeta('Kepler-966 b', 17.7312354989862, 99.747622).
planeta('Kepler-1010 b', 5.62128359008418, 34.2685705).
planeta('Kepler-811 b', 7.06690361687513, 23.58447697).
planeta('Kepler-225 c', 4.30587297387588, 18.794234).
planeta('Kepler-1305 b', 4.40671614199372, 13.5630972).
planeta('Kepler-150 d', 7.4689732417912, 12.56093).
planeta('Kepler-1322 b', 3.81694410582523, 0.96286738).
planeta('Kepler-405 b', 4.9061329537818, 10.613839).
planeta('Kepler-208 b', 3.84952029470666, 4.22864).
planeta('M 67 YBP 1194 b', 110.068744809053, 6.958).
planeta('Kepler-1084 b', 1.34189744139248, 2.05333679).
planeta('Kepler-616 b', 6.00282227059303, 9.99761851).
planeta('Kepler-325 d', 7.4689732417912, 38.715185).
planeta('Kepler-1065 c', 3.79412488278439, 2.37030743).
planeta('Kepler-1464 c', 0.918772474882314, 5.32786292).
planeta('Kepler-340 c', 10.867829772265, 22.824669).
planeta('Kepler-682 b', 52.1368395847019, 12.61190667).
planeta('Kepler-507 b', 2.32231360013276, 3.56809693).
planeta('HD 40307 c', 6.72080147353975, 9.62).
planeta('HD 142 b', 414.972973877884, 350.3).
planeta('Kepler-257 b', 6.68024809108833, 2.382667).
planeta('Kepler-976 b', 15.9878849966428, 105.9564148).
planeta('WASP-10 b', 1014.2922170122, 3.0927616).
planeta('Kepler-982 b', 5.40777448090814, 15.7738221).
planeta('GJ 328 b', 730.9778968516, 4100).
planeta('WASP-17 b', 161.624615873996, 3.735433).
planeta('HAT-P-17 b', 168.492947756109, 10.338523).
planeta('Kepler-162 b', 2.08600115873972, 6.919798).
planeta('Kepler-487 c', 6.96946108506005, 38.6519976).
planeta('HD 67087 b', 984.611336235261, 352.2).
planeta('Kepler-293 c', 14.7153796048149, 54.155743).
planeta('HD 102329 b', 1423.20760884053, 778.1).
planeta('Kepler-872 b', 4.68264440723135, 2.57885507).
planeta('Kepler-1542 d', 0.574389718686912, 5.99273738).
planeta('HD 159868 b', 699.208961821476, 1178.4).
planeta('K2-21 b', 3.76803215003155, 9.32414).
planeta('Kepler-424 b', 244.790195914141, 3.3118644).
planeta('Kepler-262 c', 3.87014658405695, 21.853722).
planeta('WASP-117 b', 87.558439383746, 10.02165).
planeta('WASP-75 b', 340.06363027444, 2.484193).
planeta('Kepler-1293 b', 0.847092146684092, 5.57654784).
planeta('Kepler-222 b', 9.46988221700786, 3.936981).
planeta('Kepler-334 b', 1.38624873074276, 5.470319).
planeta('HD 114783 b', 351.203097789505, 493.7).
planeta('GJ 581 e', 1.94966424648259, 3.14945).
planeta('Kepler-1638 b', 4.38021024782092, 259.33683).
planeta('Kepler-605 b', 3.23368730743303, 3.38353807).
planeta('Kepler-327 c', 1.03012901205573, 5.212333).
planeta('Kepler-793 b', 2.75420394507561, 4.24153639).
planeta('Kepler-1555 b', 3.81694410582523, 8.10501635).
planeta('Kepler-419 b', 794.54119223, 69.7546).
planeta('epsilon Ret b', 437.534765572448, 428.1).
planeta('GJ 674 b', 11.0851208975161, 4.6938).
planeta('Kepler-511 b', 34.4824521098282, 296.637865).
planeta('Kepler-1361 b', 0.548726038177883, 3.57554956).
planeta('HD 7924 c', 7.89462484929266, 15.299).
planeta('Kepler-57 c', 3.68517739450581, 11.6092567).
planeta('HD 168443 c', 5525.46192230125, 1749.83).
planeta('Kepler-172 c', 7.80636721365975, 6.388996).
planeta('Kepler-1350 b', 6.33300180843613, 4.4968604).
planeta('WASP-70 A b', 187.535875418524, 3.7130203).
planeta('Kepler-933 b', 6.08319805759902, 14.20443009).
planeta('Kepler-1406 b', 1.29473983255124, 11.62905828).
planeta('Kepler-1530 b', 3.8629321500315, 2.5904434).
planeta('Kepler-400 c', 3.66413794373556, 17.340824).
planeta('Kepler-220 e', 2.5076514567971, 45.902733).
planeta('Kepler-1111 b', 4.68264440723135, 8.79617863).
planeta('WASP-57 b', 214.808025117103, 2.838971).
planeta('HAT-P-37 b', 372.995773609989, 2.79736).
planeta('Kepler-198 c', 6.13862525116898, 49.567416).
planeta('Kepler-1166 b', 3.98011108506158, 33.2406882).
planeta('Kepler-458 c', 18.4330378432591, 20.74028413).
planeta('Kepler-1605 b', 1.20372037173414, 85.7565495).
planeta('Kepler-1222 b', 0.391988486269055, 1.91694425).
planeta('Kepler-1635 b', 13.0111205291293, 469.63111).
planeta('Kepler-615 b', 4.0762823509691, 10.35584657).
planeta('Kepler-249 b', 1.25978955458743, 3.306539).
planeta('WASP-106 b', 611.7967180171, 9.289715).
planeta('HD 81040 b', 2185.47771600691, 1001.7).
planeta('HD 208527 b', 3182.61419959649, 875.5).
planeta('Kepler-165 b', 5.62042548559657, 8.180848).
planeta('Kepler-28 b', 12.6211597119828, 5.91213).
planeta('Kepler-118 c', 58.7061061620596, 20.17202).
planeta('Kepler-1216 b', 2.9086754655042, 4.37034536).
planeta('HAT-P-32 b', 273.803979906088, 2.150008).
planeta('GJ 163 c', 6.84970783656714, 25.63058).
planeta('HD 95089 b', 358.894256530291, 507).
planeta('XO-3 b', 4222.16011386253, 3.1915426).
planeta('Kepler-1380 b', 3.23368730743303, 10.3108245).
planeta('Kepler-478 b', 7.11626051573646, 13.2217576).
planeta('HD 114729 b', 300.259659075532, 1114).
planeta('Kepler-122 e', 6.63953580039846, 37.993273).
planeta('Kepler-634 b', 4.43338094440496, 5.16950177).
planeta('Kepler-881 b', 4.17490080374869, 4.44448017).
planeta('Kepler-103 c', 27.892591024768, 179.612).
planeta('Kepler-997 b', 2.67895771600666, 2.70730672).
planeta('Kepler-1503 b', 5.47772588747207, 96.16987).
planeta('HD 100655 b', 423.81462826502, 157.57).
planeta('Kepler-400 b', 3.89083643670262, 9.024389).
planeta('Kepler-106 c', 10.439572069653, 13.5708).
planeta('Kepler-113 b', 4.26001205626037, 4.754).
planeta('Kepler-1178 b', 1.15983309444013, 31.80634).
planeta('Kepler-595 b', 14.5335885800327, 25.30292332).
planeta('HD 142415 b', 528.191915605891, 386.29999).
planeta('Kepler-1359 b', 7.63382464835508, 59.4970952).
planeta('Kepler-785 b', 317.816476892, 1.97376093).
planeta('CoRoT-9 b', 268.098538512923, 95.2738).
planeta('HD 114386 b', 433.406329537621, 937.70001).
planeta('HD 103197 b', 31.2232759209484, 47.84).
planeta('Kepler-698 b', 13.3027807099731, 16.32976218).
planeta('Kepler-1022 b', 5.76989457467888, 10.99469878).
planeta('7 CMa b', 773.034551238718, 763).
planeta('K2-3 b', 5.20497578700335, 10.05403).
planeta('Kepler-368 b', 10.1099646014683, 26.84768).
planeta('Kepler-913 b', 4.8587782987249, 10.29672521).
planeta('Kepler-1224 b', 2.53240300401745, 13.32351601).
planeta('Kepler-335 b', 11.0119595445355, 6.562331).
planeta('WASP-16 b', 267.69491158727, 3.1186009).
planeta('Kepler-316 b', 1.14115819825795, 2.240508).
planeta('HD 152581 b', 481.094691895265, 689).
planeta('KIC 11442793 h', 297.926568318668, 331.60059).
planeta('Kepler-103 b', 9.69959996650539, 15.9654).
planeta('Kepler-1426 b', 3.70396034829012, 14.2563227).
planeta('Kepler-993 b', 8.37602146684097, 22.08557563).
planeta('Kepler-338 b', 6.03005914266267, 13.726976).
planeta('Kepler-1588 b', 0.354028486269075, 7.84931739).
planeta('Kepler-985 b', 8.43653372404121, 116.331901).
planeta('Kepler-974 b', 3.72633462826332, 4.19449651).
planeta('Kepler-1248 b', 1.64858080709895, 7.46725407).
planeta('Kepler-129 b', 5.78645281312495, 15.79186).
planeta('Kepler-1331 b', 1.11701368050847, 0.78916165).
planeta('PH-1 b', 31.9205334896018, 138.506).
planeta('Kepler-306 d', 6.13862525116898, 17.326644).
planeta('Kepler-37 d', 1.83532023442638, 39.792187).
planeta('Kepler-856 b', 179.328264902788, 8.02768059).
planeta('HD 13908 c', 1630.39852645596, 931).
planeta('HD 125595 b', 13.2454466175418, 9.6737).
planeta('Kepler-1499 b', 1.70375056932263, 44.2008).
planeta('WASP-79 b', 282.066572672326, 3.6623817).
planeta('Kepler-1470 b', 1.15983309444013, 16.2950903).
planeta('Kepler-107 b', 3.70783770930821, 3.179997).
planeta('Kepler-1040 b', 4.91941768251589, 201.1214).
planeta('Kepler-1542 c', 0.203206134628161, 2.89223021).
planeta('Kepler-109 c', 6.32527886804765, 21.2227).
planeta('HIP 57274 c', 130.335265907502, 32.03).
planeta('Kepler-30 d', 23.1011898191442, 143.343).
planeta('Kepler-1349 b', 0.25626559544528, 2.12823928).
planeta('Kepler-877 b', 5.01225187541604, 18.45847097).
planeta('Kepler-720 b', 121.172616878705, 4.70832654).
planeta('Kepler-932 b', 2.75420394507561, 1.9214374).
planeta('Kepler-1628 b', 35.6402575351458, 76.378033).
planeta('Kepler-158 c', 4.44698348961593, 28.551383).
planeta('Kepler-858 b', 24.9070230408445, 76.13602028).
planeta('Kepler-777 b', 3.49172250502165, 5.72812599).
planeta('HD 93083 b', 117.012399196189, 143.58).
planeta('Kepler-970 b', 7.36949668452401, 16.73652231).
planeta('HD 31253 b', 159.361762558525, 466).
planeta('Kepler-1579 b', 0.49994438713973, 0.84990789).
planeta('Kepler-191 d', 5.47772588747207, 5.94504102).
planeta('Kepler-357 c', 6.9310370730038, 16.85837).
planeta('Kepler-861 b', 5.47772588747207, 3.94963138).
planeta('Kepler-1258 b', 0.548726038177883, 0.98494017).
planeta('TRAPPIST-1 c', 1.07171211989228, 2.421848).
planeta('Kepler-552 b', 15.8713734762142, 5.26341577).
planeta('HD 89744 b', 2602.21139316678, 256.78).
planeta('Kepler-1441 b', 2.39105412591973, 39.4419839).
planeta('Kepler-1341 b', 8.49755448760447, 132.9968322).
planeta('Kepler-738 b', 6.24827193569672, 24.58721573).
planeta('HD 183263 c', 1104.87626925596, 3066).
planeta('WASP-42 b', 157.944618888063, 4.9816877).
planeta('Kepler-1612 b', 1.03453077026069, 3.91795101).
planeta('Kepler-885 b', 6.24827193569672, 18.11472949).
planeta('Kepler-53 d', 5.01644705291102, 9.751962).
planeta('Kepler-48 b', 3.93984373743937, 4.778).
planeta('Kepler-1614 b', 3.67058961821646, 3.9466141).
planeta('HD 192310 c', 23.3936127595325, 525.8).
planeta('HD 1690 b', 2074.21016744702, 533).
planeta('HAT-P-41 b', 254.333906898731, 2.694047).
planeta('Kepler-1493 b', 3.06848948090934, 15.0217983).
planeta('Kepler-42 c', 0.303363136972383, 0.45328509).
planeta('Kepler-1492 b', 3.67058961821646, 16.75255007).
planeta('HD 28185 b', 1842.44885800307, 379).
planeta('HIP 97233 b', 6307.73539852321, 1058.8).
planeta('Kepler-1461 b', 4.76966255860438, 29.3494775).
planeta('Kepler-846 b', 6.16500401875102, 19.80792185).
planeta('HD 23127 b', 446.490833891264, 1214).
planeta('HD 154672 b', 1591.11005358257, 163.94).
planeta('Kepler-275 d', 10.5855769591372, 35.676062).
planeta('Kepler-52 b', 4.95571232417696, 7.8773565).
planeta('Kepler-1561 b', 1.24868504688482, 1.00520701).
planeta('OGLE-TR-10 b', 197.04621567304, 3.10129).
planeta('Kepler-370 b', 3.76803215003155, 4.57953).
planeta('Kepler-601 b', 4.46023643670233, 5.37886844).
planeta('gamma Leo A b', 3296.4560616192, 428.5).
planeta('NN Ser c', 712.223546550203, 5571).
planeta('Kepler-1179 b', 2.46108180843812, 2.68505749).
planeta('Kepler-930 b', 5.04368392498066, 71.4517775).
planeta('Kepler-1073 b', 5.54888499664819, 8.67888593).
planeta('HAT-P-2 b', 2819.23873074202, 5.6334729).
planeta('HAT-P-24 b', 217.976655391716, 3.35524).
planeta('HD 11506 b', 1504.76567314055, 1405).
planeta('Kepler-758 c', 3.98011108506158, 4.75793986).
planeta('tau Boo b', 1891.0080375074, 3.312433).
planeta('Kepler-422 b', 317.816476892, 7.8914483).
planeta('Kepler-124 c', 4.10377347622026, 13.821375).
planeta('Kepler-1081 b', 0.95624621567265, 3.85691855).
planeta('Kepler-1539 b', 7.06690361687513, 133.3036741).
planeta('Kepler-1458 b', 7.31794685197213, 47.9872764).
planeta('Kepler-184 c', 4.61876329537606, 20.303005).
planeta('XO-2S c', 435.726389818932, 120.8).
planeta('HD 34445 b', 251.235831881987, 1049).
planeta('Kepler-318 b', 23.3027808104368, 4.662715).
planeta('OGLE-2007-BLG-368L b', 19.9906563965068, 0).
planeta('KELT-7 b', 406.80509042176, 2.7347749).
planeta('Kepler-1321 c', 5.88484879437072, 2.22649109).
planeta('Kepler-1311 c', 1.8764266175476, 2.53573424).
planeta('Kepler-1260 b', 4.15001577360805, 19.1187753).
planeta('HD 125612 b', 975.076841928501, 559.40487).
planeta('Kepler-20 f', 1.02684914601421, 19.57706).
planeta('Kepler-198 b', 7.6114185867342, 17.790037).
planeta('42 Dra b', 1186.10062625525, 479.1).
planeta('Kepler-808 b', 3.40432297387635, 0.63133235).
planeta('Kepler-216 b', 5.71926640990999, 7.693641).
planeta('Kepler-292 d', 5.33721922303811, 7.055679).
planeta('Kepler-53 b', 7.94353680508634, 18.6489525).
planeta('Kepler-11 b', 1.89991961151945, 10.3039).
planeta('HD 153950 b', 871.481383120784, 499.4).
planeta('Kepler-69 b', 5.36162752846342, 13.722341).
planeta('Kepler-27 c', 25.2342786671002, 31.3309).
planeta('Kepler-1434 b', 1.34189744139248, 8.05333618).
planeta('HD 16141 b', 79.3435190890416, 75.523).
planeta('Kepler-221 c', 8.16213097789266, 5.690586).
planeta('WASP-97 b', 419.51774949744, 2.07276).
planeta('Kepler-7 b', 139.126705291288, 4.885525).
planeta('HIP 91258 b', 339.427997320656, 5.0505).
planeta('Kepler-486 b', 242.207937039393, 30.36044667).
planeta('WASP-24 b', 346.737776289172, 2.3412127).
planeta('HAT-P-29 b', 247.580306764776, 5.723186).
planeta('Kepler-38 b', 19.7458105827092, 105.595).
planeta('Kepler-546 b', 65.0497230408239, 4.14702026).
planeta('HD 204313 d', 510.546744808847, 2831.6).
planeta('PSR B1257+12 B', 4.30021584058721, 66.5419).
planeta('Kepler-147 b', 3.99666932350766, 12.610584).
planeta('HD 50554 b', 1397.99840589345, 1224).
planeta('HD 11964 c', 24.4937662759419, 37.910254).
planeta('Kepler-1044 b', 6.92140723375398, 6.77408868).
planeta('Kepler-79 d', 6.0067314132588, 52.09059).
planeta('Kepler-344 c', 8.26723288680084, 125.596809).
planeta('HD 13189 b', 2263.90846617432, 471.6).
planeta('HD 60532 b', 328.876490287842, 201.3).
planeta('Kepler-1321 b', 25.5017212324048, 11.12830484).
planeta('Kepler-570 b', 6.08319805759902, 4.301662).
planeta('Kepler-1151 b', 5.30508797722433, 65.6478424).
planeta('HAT-P-11 b', 26.231110046872, 4.8878162).
planeta('Kepler-406 b', 6.34971895512065, 2.42629).
planeta('Kepler-171 b', 5.68608636972246, 4.166972).
planeta('Kepler-627 b', 13.8029602813057, 40.6994443).
planeta('Kepler-330 b', 2.63732057936904, 8.25978).
planeta('HD 104067 b', 59.093206630914, 55.806).
planeta('Kepler-1452 b', 7.06690361687513, 42.913751).
planeta('Kepler-229 b', 5.24708647019154, 6.252972).
planeta('Kepler-638 b', 4.27615713328648, 6.07972888).
planeta('Kepler-144 c', 2.63732057936904, 10.104665).
planeta('Kepler-1372 b', 2.12372279638203, 1.31155557).
planeta('Kepler-758 e', 3.94928288680306, 8.1934719).
planeta('HD 20794 b', 2.69724169792226, 18.315).
planeta('Kepler-94 b', 10.8395441058216, 2.50806).
planeta('Kepler-115 c', 6.63953580039846, 8.990889).
planeta('Kepler-320 c', 2.77116581044734, 17.934937).
planeta('Kepler-1478 b', 4.05203295378224, 26.0840594).
planeta('HD 195019 b', 1137.7480274609, 18.20132).
planeta('Kepler-274 c', 4.30587297387588, 33.197861).
planeta('Kepler-1627 b', 13.4013991627527, 7.20283653).
planeta('GJ 832 b', 217.387105827082, 3657).
planeta('Kepler-889 b', 1.24868504688482, 3.744439).
planeta('Kepler-26 e', 5.92406734761919, 46.827915).
planeta('GJ 667 C b', 5.56023104487323, 7.1999).
planeta('Kepler-254 d', 6.24973389149042, 18.746477).
planeta('Kepler-592 b', 5.84620231078065, 2.82019241).
planeta('CoRoT-19 b', 352.115231078185, 3.89713).
planeta('Kepler-264 b', 10.5855769591372, 40.806231).
planeta('Kepler-604 b', 6.59628097789346, 25.85501786).
planeta('Kepler-557 b', 6.92140723375398, 3.70598955).
planeta('Kepler-1237 b', 7.79794507702211, 84.5733226).
planeta('Kepler-122 c', 36.6757036168599, 12.465988).
planeta('Kepler-142 b', 4.66935967849726, 2.024152).
planeta('alpha Ari b', 545.570120562345, 380).
planeta('Kepler-1450 b', 4.02791068318614, 54.5094166).
planeta('Kepler-148 d', 136.134780977827, 51.84688575).
planeta('Kepler-1148 b', 3.98011108506158, 1.10446351).
planeta('Kepler-240 c', 5.24708647019154, 7.953528).
planeta('Kepler-545 b', 7.01795987943377, 13.24934059).
planeta('61 Vir b', 5.1088998660389, 4.215).
planeta('Kepler-298 b', 4.59371935699697, 10.475464).
planeta('HD 210702 b', 592.597424648054, 354.29).
planeta('Kepler-1299 b', 8.43653372404121, 19.9400874).
planeta('Kepler-1564 b', 3.49172250502165, 18.0540381).
planeta('Kepler-363 d', 4.82553469524199, 11.932125).
planeta('HAT-P-4 b', 213.415988948316, 3.056536).
planeta('Kepler-1414 b', 1.93640176490188, 3.51576315).
planeta('Kepler-485 b', 317.816476892, 3.2432598).
planeta('HAT-P-21 b', 1296.16047220295, 4.124481).
planeta('Kepler-398 d', 0.600930572672163, 6.83437001).
planeta('Kepler-1180 b', 4.68264440723135, 16.8601286).
planeta('Kepler-1388 b', 6.59628097789346, 12.2854603).
planeta('Kepler-215 d', 5.85475157400905, 30.864423).
planeta('Kepler-579 b', 4.68264440723135, 9.66857723).
planeta('Kepler-232 c', 14.7153796048149, 11.379349).
planeta('Kepler-1009 b', 5.1721771265881, 11.35011917).
planeta('Kepler-346 b', 6.88841788345259, 6.511127).
planeta('Kepler-330 c', 4.56883432685633, 15.955387).
planeta('Kepler-1233 b', 6.64150626255519, 45.1263042).
planeta('Kepler-1416 b', 0.600930572672163, 1.49514952).
planeta('alpha Cen B b', 1.12710117548502, 3.2357).
planeta('Kepler-1183 b', 7.63382464835508, 28.5057189).
planeta('mu Ara b', 554.755016744524, 643.25).
planeta('TYC 1422-614-1 c', 3178.16476892, 559.3).
planeta('Kepler-1109 b', 5.20497578700335, 37.6467384).
planeta('Kepler-830 b', 4.00394732082848, 11.29695137).
planeta('WASP-45 b', 319.90453114518, 3.1260876).
planeta('Kepler-916 b', 4.12528965170585, 32.2968798).
planeta('Kepler-725 b', 198.161433690454, 39.64317811).
planeta('Kepler-428 b', 403.62692565284, 3.52563254).
planeta('Kepler-1171 b', 6.46292518418958, 1.44259224).
planeta('Kepler-1093 c', 4.59766028131043, 89.722292).
planeta('HD 73526 c', 769.401908907843, 377.8).
planeta('HD 108341 b', 1105.14323509655, 1129).
planeta('Kepler-1330 b', 3.88610097119693, 10.10769068).
planeta('Kepler-382 c', 3.76803215003155, 12.162701).
planeta('Kepler-667 b', 23.5091072672351, 41.43962808).
planeta('Kepler-495 b', 28.9657937039369, 3.41303622).
planeta('Kepler-333 c', 1.34321320160681, 24.08821).
planeta('Kepler-17 b', 788.003707300332, 1.4857108).
planeta('14 Her b', 1657.36843268502, 1773.4).
planeta('HAT-P-33 b', 242.57533288668, 3.474474).
planeta('Kepler-692 b', 9.13627026121432, 21.81293494).
planeta('Kepler-1223 b', 1.8764266175476, 16.301259).
planeta('Kepler-1232 b', 4.51458305425086, 26.7839183).
planeta('Kepler-805 b', 7.96629246483181, 30.8638931).
planeta('Kepler-166 c', 5.8204591761524, 34.260281).
planeta('Kepler-1398 b', 0.62836449095748, 2.78815679).
planeta('Kepler-1629 b', 0.372652531814946, 3.87595807).
planeta('Kepler-835 b', 7.47386761553534, 11.41909375).
planeta('Kepler-992 b', 3.83989045545683, 20.16034462).
planeta('Kepler-1420 b', 2.18865588077583, 6.69960006).
planeta('OGLE-05-169L b', 12.71265907568, 3300).
planeta('HIP 79431 b', 671.543037508027, 111.7).
planeta('Kepler-562 b', 28.7108413261741, 18.00931444).
planeta('Kepler-1476 b', 3.93285177494774, 10.35863224).
planeta('Kepler-870 b', 7.42145967849585, 21.3587621).
planeta('Kepler-1155 b', 4.76966255860438, 33.469743).
planeta('HD 171238 b', 829.186366375997, 1523).
planeta('Kepler-1292 b', 4.25057290689668, 3.27646405).
planeta('Kepler-1410 b', 4.17490080374869, 60.866168).
planeta('Kepler-272 c', 4.19225358338699, 6.057342).
planeta('Kepler-157 c', 5.36772960481975, 13.5405).
planeta('HIP 5158 b', 453.311175485367, 345.72).
planeta('Kepler-661 b', 8.93912870059822, 6.02930132).
planeta('Kepler-308 c', 5.13003466175222, 15.38231).
planeta('WASP-46 b', 668.15193569959, 1.43037).
planeta('Kepler-800 b', 7.74277213663366, 14.13176026).
planeta('Kepler-157 b', 2.44437101808314, 1.732342).
planeta('Kepler-1268 b', 4.76966255860438, 40.9903986).
planeta('Kepler-1034 b', 5.4426071667755, 12.12400943).
planeta('Kepler-475 b', 6.20647906898542, 3.10550819).
planeta('Kepler-1541 b', 1.54175633288601, 8.40691199).
planeta('GJ 849 b', 264.069261218886, 1882).
planeta('Kepler-587 b', 5.3390307769564, 10.94027841).
planeta('WASP-84 b', 220.663158070885, 8.5234865).
planeta('Kepler-52 d', 4.56883432685633, 36.445171).
planeta('Kepler-1190 b', 2.53240300401745, 10.45843441).
planeta('Kepler-197 c', 1.92026940053485, 10.349695).
planeta('Kepler-599 b', 7.68807592096055, 15.65562652).
planeta('Kepler-163 b', 1.10331261218965, 7.810937).
planeta('Kepler-121 c', 5.46069092431066, 41.008011).
planeta('Kepler-191 b', 2.57196797722574, 9.939632).
planeta('Kepler-123 b', 8.21447535163677, 17.232366).
planeta('Kepler-1123 b', 3.93285177494774, 4.33946454).
planeta('Kepler-320 b', 1.47501169457392, 8.371554).
planeta('HAT-P-1 b', 169.195639986517, 4.4652934).
planeta('Kepler-186 f', 1.33898624246415, 129.9459).
planeta('Kepler-1025 b', 4.65410448760645, 37.3229493).
planeta('Kepler-201 b', 6.10217170126947, 25.672083).
planeta('OGLE2-TR-L9 b', 1453.8260482243, 2.4855335).
planeta('Kepler-54 b', 4.95571232417696, 8.0109434).
planeta('Kepler-973 b', 4.59766028131043, 49.6077331).
planeta('Kepler-355 c', 7.10485090421604, 25.762294).
planeta('Kepler-1472 b', 4.46023643670233, 38.1312831).
planeta('Kepler-1135 b', 4.32783409242912, 76.957857).
planeta('Kepler-375 c', 6.84611651037826, 19.986326).
planeta('Kepler-1209 b', 3.85501851975689, 25.369116).
planeta('Kepler-1019 b', 3.40432297387635, 1.41122985).
planeta('Kepler-484 b', 5.47772588747207, 10.04556931).
planeta('Kepler-137 b', 3.50449872739271, 8.436387).
planeta('Kepler-85 d', 1.76335704956373, 17.91323).
planeta('Kepler-1456 b', 1.49008573007291, 18.1373829).
planeta('Kepler-224 c', 9.22643479570858, 5.925003).
planeta('GJ 3341 b', 6.61732042866371, 14.207).
planeta('Kepler-1290 b', 3.15041303415779, 4.69500134).
planeta('Kepler-962 b', 4.62575525786768, 12.05707239).
planeta('WASP-22 b', 177.678161754765, 3.53269).
planeta('Kepler-468 b', 317.816476892, 38.47875707).
planeta('Kepler-640 b', 6.46292518418958, 22.24813967).
planeta('Kepler-503 b', 46.0840247822938, 7.25844721).
planeta('WASP-2 b', 288.786802076208, 2.1522254).
planeta('Kepler-392 b', 0.926698817816, 5.341853).
planeta('Kepler-247 c', 17.423462022764, 9.439452).
planeta('Kepler-1076 b', 0.412052240455247, 6.14727918).
planeta('HD 164922 b', 113.755098124523, 1155).
planeta('Kepler-271 b', 0.611809430676176, 5.217738).
planeta('Kepler-30 c', 640.034711988954, 60.3231).
planeta('Kepler-190 c', 3.42622052913421, 3.763024).
planeta('tau Gru b', 386.051674480712, 1311).
planeta('WASP-34 b', 185.399513060856, 4.3176782).
planeta('Kepler-397 c', 31.996491627579, 135.498527).
planeta('HD 96063 b', 362.84153717329, 361.1).
planeta('Kepler-490 b', 317.816476892, 3.26869515).
planeta('Kepler-1466 b', 3.68168141326, 31.1750448).
planeta('Kepler-630 b', 9.61534681848132, 161.4743937).
planeta('Kepler-423 b', 317.816476892, 2.68432848).
planeta('HAT-P-22 b', 683.740833891142, 3.21222).
planeta('51 Eri b', 0, 0).
planeta('Kepler-1374 b', 5.51313064299784, 10.65276707).
planeta('Kepler-1041 b', 8.19747217012305, 24.7576421).
planeta('WASP-28 b', 288.259544541044, 3.40883).
planeta('Kepler-221 b', 4.01723204956257, 2.795906).
planeta('CoRoT-7 b', 4.449430676488, 0.85359163).
planeta('Kepler-1418 b', 3.90939691895311, 22.4764425).
planeta('HD 5608 b', 468.372498325278, 792.6).
planeta('Kepler-584 b', 18.5344530810353, 35.1810304).
planeta('Kepler-733 b', 7.63382464835508, 20.83424726).
planeta('Kepler-172 e', 7.32983318820789, 35.118736).
planeta('Kepler-1200 b', 1.15983309444013, 1.11854972).
planeta('Kepler-178 b', 8.00738613529394, 9.576694).
planeta('Kepler-1207 b', 3.83989045545683, 13.68237119).
planeta('Kepler-147 c', 5.99446369725077, 33.416423).
planeta('Kepler-1096 b', 1.99760686202175, 2.89221751).
planeta('Kepler-1491 b', 3.85501851975689, 16.5861762).
planeta('HATS-1 b', 592.749976556963, 3.446459).
planeta('Kepler-1559 b', 0.286301795043389, 0.97191543).
planeta('Kepler-378 c', 0.262808801071533, 28.906009).
planeta('HD 80606 b', 1236.4777160074, 111.4367).
planeta('Kepler-471 b', 317.816476892, 5.01423457).
planeta('Kepler-158 b', 5.01644705291102, 16.709184).
planeta('Kepler-1511 b', 3.95640197588544, 23.2382792).
planeta('Kepler-45 b', 162.562810113781, 2.455239).
planeta('Kepler-68 b', 8.32138881446324, 5.398763).
planeta('Kepler-1195 b', 4.91941768251589, 8.49642241).
planeta('Kepler-665 b', 6.64150626255519, 16.01310205).
planeta('Kepler-950 b', 97.00458070993, 98.7180406).
planeta('Kepler-308 b', 5.01644705291102, 9.694928).
planeta('WASP-78 b', 280.948812123097, 2.17517656).
planeta('Kepler-108 c', 71.1943868050538, 190.323494).
planeta('HD 86264 b', 2106.2905626245, 1475).
planeta('Kepler-942 b', 5.04368392498066, 44.96417488).
planeta('Kepler-266 c', 15.3054376758126, 107.723601).
planeta('Kepler-1094 b', 9.61534681848132, 78.1000231).
planeta('Kepler-1194 b', 3.85501851975689, 16.22371307).
planeta('8 UMi b', 483.37661419935, 93.4).
planeta('Kepler-1291 b', 3.90939691895311, 8.63043276).
planeta('Kepler-239 c', 6.28736336235444, 56.228098).
planeta('Kepler-524 b', 4.46023643670233, 7.97419807).
planeta('HD 82943 c', 505.124795713069, 219.3).
planeta('Kepler-205 c', 3.87014658405695, 20.306546).
planeta('Kepler-319 b', 3.84952029470666, 4.362705).
planeta('Kepler-162 c', 8.703753817812, 19.446355).
planeta('Kepler-126 c', 3.7478825853966, 21.869741).
planeta('HD 216536 b', 470.552719356757, 148.6).
planeta('Kepler-728 b', 10.6573717012671, 5.74347727).
planeta('Kepler-384 c', 1.43018685867308, 45.348269).
planeta('Kepler-669 b', 24.5536429001883, 4.12554687).
planeta('Kepler-1046 b', 4.02791068318614, 14.37508035).
planeta('iota Hor b', 650.516299396853, 302.8).
planeta('Kepler-716 b', 8.02334052243392, 10.37168453).
planeta('HD 37124 d', 218.228683857892, 1862).
planeta('Kepler-853 b', 3.98011108506158, 7.16892463).
planeta('Kepler-690 b', 37.7387997320636, 7.74809437).
planeta('Kepler-1500 b', 1.76010896516989, 15.0330105).
planeta('Kepler-1316 b', 12.1733880776897, 87.9732136).
planeta('Kepler-921 b', 7.8535947421259, 51.300634).
planeta('HD 192263 b', 203.206134628161, 24.3556).
planeta('K2-3 c', 4.12528965170585, 24.6454).
planeta('HD 204313 b', 1112.63734762166, 1920.1).
planeta('Kepler-1079 b', 3.83989045545683, 13.24503188).
planeta('Kepler-771 b', 4.25057290689668, 8.73485836).
planeta('Kepler-212 c', 7.23877876757833, 31.805174).
planeta('Kepler-53 c', 9.51431296047736, 38.5583038).
planeta('Kepler-707 b', 2.53240300401745, 2.23749275).
planeta('Kepler-1211 b', 6.41922541861693, 11.01816836).
planeta('Kepler-321 b', 4.14775927662211, 4.915379).
planeta('Kepler-1442 b', 15.7556882786255, 81.4162941).
planeta('Kepler-402 d', 2.83966479571187, 8.921099).
planeta('Kepler-339 d', 1.61496535833808, 10.558345).
planeta('Kepler-407 b', 0, 0.6693109).
planeta('Kepler-756 b', 1.39016422973807, 1.22486632).
planeta('TrES-3 b', 607.02947086372, 1.30619).
planeta('Kepler-188 b', 3.9535734092411, 2.061897).
planeta('HIP 14810 b', 1231.35133623513, 6.673859).
planeta('Kepler-695 b', 172.306427662336, 3.04033042).
planeta('Kepler-10 c', 17.1992742799644, 45.29485).
planeta('HD 90156 b', 17.9660065304663, 49.77).
planeta('Kepler-786 b', 6.00282227059303, 53.5293487).
planeta('Kepler-259 c', 7.06089688546188, 36.924931).
planeta('Kepler-444 b', 0.0425899504353431, 3.6001053).
planeta('Kepler-550 b', 20.4086804085629, 8.60010411).
planeta('Kepler-304 d', 7.28413117883082, 9.653471).
planeta('Kepler-150 e', 9.22643479570858, 30.826557).
planeta('Kepler-218 c', 9.34730040187061, 44.699576).
planeta('Pr 211 b', 586.034514400235, 2.1451).
planeta('Kepler-203 b', 6.51940117213329, 3.162697).
planeta('Kepler-981 b', 5.58492538512774, 4.46975774).
planeta('Kepler-6 b', 212.738722036059, 3.234723).
planeta('Kepler-501 b', 19.3559768921535, 5.64067757).
planeta('Kepler-244 d', 5.5879764233059, 20.050401).
planeta('24 Sex c', 482.178446081467, 910).
planeta('Kepler-358 b', 7.14915452109478, 34.060467).
planeta('Kepler-373 c', 1.974511138646, 16.725948).
planeta('HATS-13 b', 172.383021433267, 3.0440499).
planeta('Kepler-466 c', 2.06004190890718, 3.70921385).
planeta('Kepler-1074 b', 2.06004190890718, 5.94566534).
planeta('Kepler-807 b', 179.384836235675, 117.93108781).
planeta('HD 60532 c', 782.820120562223, 604).
planeta('Kepler-299 b', 2.44437101808314, 2.927128).
planeta('Kepler-939 b', 4.1007224380421, 14.878296).
planeta('Kepler-1389 b', 4.15001577360805, 99.2530951).
planeta('Kepler-140 c', 4.21469142665557, 91.353282).
planeta('Kepler-23 d', 5.24708647019154, 15.274299).
planeta('Kepler-1048 b', 3.81694410582523, 6.92101021).
planeta('Kepler-89 c', 9.39961299396703, 10.423648).
planeta('WASP-95 b', 359.13261888796, 2.184673).
planeta('Kepler-831 b', 2.12372279638203, 5.62153941).
planeta('HD 68988 b', 572.044233087449, 6.27711).
planeta('Kepler-84 b', 5.47772588747207, 8.726).
planeta('Kepler-637 b', 23.7392063965049, 23.20584623).
planeta('HAT-P-26 b', 18.6395867715912, 4.234516).
planeta('Kepler-1252 b', 3.93285177494774, 15.0540329).
planeta('Kepler-292 f', 5.71926640990999, 20.834237).
planeta('Kepler-847 b', 1.64858080709895, 2.3432319).
planeta('Kepler-1355 b', 3.40432297387635, 1.28958811).
planeta('Kepler-20 e', 0.558088911587121, 6.098493).
planeta('Kepler-296 d', 5.49212297387527, 19.850242).
planeta('HD 149143 b', 422.095241125034, 4.072).
planeta('Kepler-688 b', 221.205352980462, 3.89593684).
planeta('Kepler-62 d', 0, 18.16406).
planeta('Kepler-713 b', 6.16500401875102, 7.411141).
planeta('HD 79498 b', 427.882679169237, 1966.1).
planeta('Kepler-89 e', 12.9994566644273, 54.32031).
planeta('Kepler-722 b', 6.77962930341245, 4.09357325).
planeta('Kepler-556 b', 5.37325961151767, 11.72292176).
planeta('Kepler-883 b', 4.17490080374869, 12.98495573).
planeta('Kepler-1181 b', 3.72633462826332, 4.89337519).
planeta('Kepler-1336 c', 4.02791068318614, 5.77721211).
planeta('Kepler-897 b', 5.84620231078065, 8.0472642).
planeta('Kepler-298 d', 6.24973389149042, 77.473633).
planeta('Kepler-269 b', 6.13862525116898, 5.326718).
planeta('Kepler-248 b', 8.64772277293594, 6.308205).
planeta('HD 181433 c', 203.534756865267, 962).
planeta('Kepler-1375 b', 4.0762823509691, 3.3004192).
planeta('Kepler-454 b', 6.86035468854302, 10.57).
planeta('70 Vir b', 2371.36857334104, 116.6884).
planeta('HD 102365 b', 16.2014576691142, 122.1).
planeta('BD -08 2823 b', 14.6008067648954, 5.6).
planeta('Kepler-1276 b', 1.70375056932263, 12.5720095).
planeta('Kepler-797 b', 5.1721771265881, 27.07237711).
planeta('Kepler-160 b', 3.6681424313444, 4.309427).
planeta('Kepler-1066 b', 5.76989457467888, 1.93155984).
planeta('Kepler-1318 b', 9.13627026121432, 213.257663).
planeta('CoRoT-11 b', 746.274403884412, 2.99433).
planeta('Kepler-369 c', 3.05161660415114, 14.871572).
planeta('Kepler-142 d', 5.13003466175222, 41.809118).
planeta('Kepler-1415 b', 2.2548506965829, 0.63642408).
planeta('Kepler-398 b', 0.715274584728366, 4.081423).
planeta('Kepler-443 b', 5.65316058271645, 177.6693).
planeta('Kepler-746 b', 1.34189744139248, 3.48159251).
planeta('Kepler-1348 b', 4.54207417950202, 27.5722742).
planeta('Kepler-299 d', 4.3523059611498, 15.054786).
planeta('GJ 436 b', 23.1045904554469, 2.64385).
planeta('Kepler-1231 b', 3.15041303415779, 10.41725184).
planeta('Kepler-142 c', 7.80636721365975, 4.761702).
planeta('Kepler-401 d', 5.47772588747207, 184.256405).
planeta('Kepler-815 b', 17.6321403214913, 8.57503552).
planeta('Kepler-578 b', 4.68264440723135, 1.6168837).
planeta('Kepler-181 c', 4.66935967849726, 4.302149).
planeta('XO-2S b', 82.314467515028, 18.157).
planeta('Kepler-364 b', 3.68794239785477, 25.745718).
planeta('Kepler-173 c', 5.99446369725077, 8.005777).
planeta('Kepler-609 b', 10.7362537508317, 6.52121067).
planeta('Kepler-1606 b', 4.88897086402964, 196.435224).
planeta('Kepler-290 b', 5.39849423978289, 14.589347).
planeta('Kepler-926 b', 5.58492538512774, 52.0688601).
planeta('Kepler-544 b', 5.01225187541604, 21.41616926).
planeta('WASP-37 b', 570.041989283029, 3.577469).
planeta('Kepler-223 c', 4.69494390488707, 9.848183).
planeta('HD 6718 b', 495.507669122317, 2496).
planeta('Kepler-224 e', 4.61876329537606, 18.643577).
planeta('Kepler-322 c', 3.93253395847085, 4.337234).
planeta('HD 33636 b', 2946.00301071516, 2127.7).
planeta('Kepler-477 b', 4.88897086402964, 11.11990653).
planeta('Kepler-1327 b', 4.22517937039301, 14.88801098).
planeta('Kepler-163 c', 5.42948134627986, 21.347262).
planeta('Kepler-1128 b', 13.1076413931614, 61.6178167).
planeta('HAT-P-40 b', 197.109778968418, 4.457243).
planeta('HD 240237 b', 1690.62157066223, 745.7).
planeta('Kepler-494 b', 69.5067813127573, 8.02511821).
planeta('Kepler-169 f', 6.55912823174479, 87.090195).
planeta('Kepler-283 b', 5.04451024782058, 11.008151).
planeta('rho CrB b', 338.185334896008, 39.8449).
planeta('Kepler-214 b', 6.68024809108833, 15.660544).
planeta('Kepler-700 b', 38.179293369036, 80.8720639).
planeta('Kepler-1549 b', 6.50697454788681, 214.886545).
planeta('Kepler-730 b', 172.306427662336, 6.49168426).
planeta('Kepler-1515 b', 122.03008573336, 214.3114164).
planeta('Kepler-1424 b', 1.54175633288601, 29.6091744).
planeta('Kepler-314 b', 0.47787203281958, 2.461069).
planeta('Kepler-188 c', 9.657203248488, 5.996553).
planeta('Kepler-731 b', 317.816476892, 3.85560355).
planeta('Kepler-1338 b', 0.685994152712306, 0.93511806).
planeta('Kepler-233 b', 5.99446369725077, 8.472382).
planeta('Kepler-1530 c', 3.88610097119693, 5.3227406).
planeta('Kepler-118 b', 4.59371935699697, 7.518496).
planeta('Kepler-1440 b', 2.06004190890718, 39.859484).
planeta('Kepler-1513 b', 79.3848352310375, 160.88465087).
planeta('Kepler-110 b', 4.28289484259659, 12.691112).
planeta('HD 11977 b', 2351.88006697803, 711).
planeta('Kepler-1192 b', 5.76989457467888, 25.2034787).
planeta('Kepler-1382 b', 4.40671614199372, 16.3583055).
planeta('HD 73534 b', 339.516985934186, 1770).
planeta('Kepler-689 b', 7.96629246483181, 22.36656079).
planeta('Kepler-1643 b', 5.54888499664819, 5.34264507).
planeta('Kepler-195 b', 4.77271359678254, 8.307872).
planeta('Kepler-498 b', 8.68369959812012, 9.61375356).
planeta('Kepler-50 c', 7.45730937708927, 9.3761368).
planeta('Kepler-863 b', 8.02334052243392, 15.59461874).
planeta('Kepler-1464 b', 3.90939691895311, 31.7785901).
planeta('HD 164604 b', 854.449598124142, 606.4).
planeta('Kepler-1356 b', 3.94928288680306, 0.63400294).
planeta('Kepler-359 b', 12.0770896851914, 25.563222).
planeta('TRAPPIST-1 b', 1.4667516443395, 1.510848).
planeta('Kepler-1201 b', 5.51313064299784, 15.18725932).
planeta('Kepler-1594 b', 1.15983309444013, 2.71603809).
planeta('Kepler-642 b', 8.02334052243392, 4.41745855).
planeta('Kepler-359 d', 16.5517232082969, 77.095691).
planeta('Kepler-115 b', 1.25978955458743, 2.403679).
planeta('OGLE-05-071L b', 1207.7026121896, 3600).
planeta('OGLE235-MOA53 b', 826.3228399192, 0).
planeta('HD 37124 c', 205.979719021997, 885.5).
planeta('HD 217107 c', 831.23628265195, 4270).
planeta('Kepler-1323 b', 3.94928288680306, 0.92990668).
planeta('HD 74156 b', 563.622096449811, 51.638).
planeta('Kepler-928 b', 3.7714327863343, 3.9324613).
planeta('Kepler-180 b', 3.74562608841067, 13.817124).
planeta('HD 103774 b', 116.973625586008, 5.8881).
planeta('Kepler-43 b', 1027.00169792312, 3.024095).
planeta('Kepler-76 b', 622.92029470832, 1.545).
planeta('Kepler-310 b', 1.71297042531727, 13.930698).
planeta('Kepler-222 c', 22.5949717347506, 10.08881).
planeta('Kepler-1154 c', 5.76989457467888, 8.45808312).
planeta('Kepler-538 b', 5.4426071667755, 81.73780699).
planeta('KELT-6 b', 137.048821165368, 7.8457).
planeta('WASP-13 b', 150.607825519012, 4.3530135).
planeta('Kepler-683 b', 4.62575525786768, 2.53918318).
planeta('Kepler-84 c', 30.510381781632, 12.883).
planeta('Kepler-918 b', 4.0762823509691, 4.85386933).
planeta('Kepler-569 b', 9.47569825853498, 34.18890521).
planeta('HD 13931 b', 597.885890823537, 4218).
planeta('Kepler-58 d', 8.21447535163677, 40.101371).
planeta('HAT-P-18 b', 62.6749983254869, 5.508023).
planeta('Kepler-672 b', 6.24827193569672, 38.3774623).
planeta('Kepler-357 b', 4.30587297387588, 6.475434).
planeta('Kepler-1518 b', 8.81034946416158, 5.11177904).
planeta('Kepler-971 b', 5.04368392498066, 9.59070716).
planeta('Kepler-406 c', 2.72529535833751, 4.62332).
planeta('HD 155358 c', 256.487749162628, 391.9).
planeta('WASP-43 b', 564.470666443112, 0.813475).
planeta('Kepler-1570 b', 1.15983309444013, 26.548955).
planeta('Kepler-159 c', 11.1580279973151, 43.595792).
planeta('Kepler-39 b', 5778.06245813501, 21.0874).
planeta('Kepler-920 c', 14.4269929336831, 100.8274113).
planeta('14 And b', 1488.59834896106, 185.84).
planeta('Kepler-1130 b', 0.412052240455247, 5.45298175).
planeta('Kepler-520 b', 3.90939691895311, 19.67416124).
planeta('Kepler-1191 b', 3.85501851975689, 5.60014851).
planeta('Kepler-1012 b', 2.2548506965829, 5.50860439).
planeta('Kepler-1145 b', 2.98791029135814, 3.97076766).
planeta('Kepler-891 b', 35.3062324179323, 53.44945593).
planeta('Kepler-727 b', 6.37593881446424, 5.15448442).
planeta('Kepler-215 b', 3.82902113194713, 9.360672).
planeta('Kepler-294 b', 4.14775927662211, 3.701212).
planeta('WASP-88 b', 179.103886470102, 4.954).
planeta('Kepler-29 b', 12.6211597119828, 10.3376).
planeta('Kepler-792 b', 4.59766028131043, 11.30119217).
planeta('Kepler-975 b', 3.58045686536989, 1.97034246).
planeta('Kepler-24 b', 5.88186131948793, 8.14561).
planeta('Kepler-542 b', 3.72633462826332, 13.14497566).
planeta('Kepler-306 b', 3.91187588747287, 4.646186).
planeta('Kepler-656 b', 9.20307528465702, 1.26025909).
planeta('Kepler-83 b', 7.63382464835508, 9.77).
planeta('Kepler-770 b', 5.54888499664819, 18.92540274).
planeta('Kepler-489 b', 59.6922906898555, 17.27629612).
planeta('81 Cet b', 1370.09411922234, 952.7).
planeta('Kepler-1204 b', 8.81034946416158, 85.7350285).
planeta('Kepler-1218 b', 3.23368730743303, 22.9221266).
planeta('Kepler-1043 b', 6.41922541861693, 38.5053398).
planeta('Kepler-1396 b', 4.88897086402964, 18.2206421).
planeta('CoRoT-3 b', 6945.84732082697, 4.2568).
planeta('Kepler-377 b', 2.90930156396367, 12.509529).
planeta('Kepler-648 b', 9.82904661754351, 17.4211749).
planeta('Kepler-910 b', 0.454433067648795, 2.36436901).
planeta('Kepler-126 d', 6.24973389149042, 100.283134).
planeta('Kepler-1506 b', 2.46108180843812, 14.0329154).
planeta('HAT-P-38 b', 85.0378369055156, 4.640382).
planeta('Kepler-1602 b', 2.60502724715204, 11.17931605).
planeta('Kepler-18 d', 16.3993302076272, 14.85888).
planeta('Kepler-1077 b', 7.36949668452401, 34.3511874).
planeta('Kepler-380 b', 1.71297042531727, 3.930821).
planeta('Kepler-1580 b', 4.98104229738525, 56.6449279).
planeta('HD 32963 b', 222.4715338244, 2372).
planeta('Kepler-132 d', 3.68794239785477, 18.010199).
planeta('Kepler-228 b', 3.99666932350766, 2.566546).
planeta('mu Ara e', 172.676683857915, 310.54999).
planeta('Kepler-97 b', 3.39876118553074, 2.58664).
planeta('WASP-96 b', 152.55190890816, 3.4252602).
planeta('Kepler-1229 b', 2.98791029135814, 86.828989).
planeta('Kepler-518 b', 4.98104229738525, 8.51203588).
planeta('Kepler-139 b', 8.21447535163677, 15.771044).
planeta('Kepler-952 b', 57.9039373743842, 130.3546919).
planeta('Kepler-375 b', 3.3491500334879, 12.125934).
planeta('Kepler-1285 b', 0.847092146684092, 14.7967458).
planeta('HD 136118 b', 3712.38248492776, 1187.3).
planeta('Kepler-182 b', 6.55912823174479, 9.825792).
planeta('Kepler-1313 b', 4.12528965170585, 3.83309118).
planeta('HD 6434 b', 126.235115539118, 21.997999).
planeta('HD 5319 b', 561.089099128981, 641).
planeta('Kepler-306 e', 5.46069092431066, 44.840975).
planeta('Kepler-1519 b', 46.0525609510815, 240.7989397).
planeta('Kepler-253 b', 3.84952029470666, 3.783986).
planeta('Kepler-259 b', 7.5160736436666, 8.115317).
planeta('Kepler-1586 b', 3.94928288680306, 15.6049212).
planeta('Kepler-1172 b', 9.68602920294211, 26.0204423).
planeta('Kepler-1501 b', 3.70396034829012, 14.5564533).
planeta('HD 231701 b', 345.36163094423, 141.60001).
planeta('Kepler-666 b', 5.88484879437072, 4.49876092).
planeta('PH-2 b', 155.157368385721, 282.5255).
planeta('Kepler-1027 b', 0.600930572672163, 1.9078052).
planeta('CoRoT-18 b', 1108.0735030135, 1.9000693).
planeta('Kepler-703 b', 111.050797722649, 4.58352176).
planeta('Kepler-1505 b', 0.716224855994274, 30.8609366).
planeta('Kepler-203 d', 3.27312833221533, 11.32972).
planeta('HD 75898 b', 799.321152042456, 418.20001).
planeta('Kepler-776 b', 2.18865588077583, 4.89718784).
planeta('Kepler-876 b', 3.23368730743303, 5.14438011).
planeta('Kepler-224 b', 2.90930156396367, 3.132924).
planeta('Kepler-1459 b', 2.67895771600666, 62.8691611).
planeta('Kepler-710 b', 4.40671614199372, 4.34728553).
planeta('Kepler-806 b', 1.49008573007291, 8.09219642).
planeta('Kepler-205 b', 3.82819480910721, 2.75564).
planeta('KOI-4427 b', 4.30590475552357, 147.6606).
planeta('Kepler-612 b', 7.68807592096055, 3.72215641).
planeta('MOA-2008-BLG-310L b', 73.09778968516, 0).
planeta('KIC 11442793 g', 69.1451061620542, 210.60697).
planeta('GJ 1214 b', 6.46778777628602, 1.58040482).
planeta('Kepler-824 b', 4.38021024782092, 4.51436633).
planeta('Kepler-1451 b', 10.7362537508317, 35.622233).
planeta('Kepler-268 c', 10.9396245143949, 83.446393).
planeta('Kepler-135 c', 1.56739140991212, 11.448708).
planeta('Kepler-265 c', 6.76253077695567, 17.028937).
planeta('Kepler-1296 b', 0.656713720696246, 8.3839865).
planeta('Kepler-1480 b', 3.93285177494774, 22.12679948).
planeta('Kepler-620 b', 10.5014191560562, 12.91375431).
planeta('16 Cyg B b', 521.209487608573, 798.5).
planeta('HAT-P-25 b', 180.259467180081, 3.652836).
planeta('Kepler-341 e', 4.66935967849726, 42.473269).
planeta('HD 213240 b', 1440.50000334822, 882.7).
planeta('Kepler-1577 b', 1.43955926657662, 6.30560247).
planeta('Kepler-1409 b', 1.07524941728009, 0.76486493).
planeta('Kepler-1352 b', 0.600930572672163, 1.87788275).
planeta('Kepler-1249 b', 5.80787364366748, 24.3347127).
planeta('Kepler-1269 b', 3.83989045545683, 37.3331536).
planeta('HAT-P-45 b', 283.492297387664, 3.128992).
planeta('Kepler-399 b', 0.80095472873368, 14.425281).
planeta('Kepler-341 c', 3.99590656396312, 8.01041).
planeta('Kepler-925 b', 5.69495344942775, 33.8678531).
planeta('Kepler-265 d', 6.2124222371033, 43.130617).
planeta('Kepler-677 b', 30.6513651707813, 6.57531678).
planeta('HD 33844 b', 622.92029470832, 551.4).
planeta('Kepler-243 c', 4.66935967849726, 20.026218).
planeta('Kepler-561 b', 44.2302012725827, 58.3620495).
planeta('HD 12661 b', 743.944809108794, 262.70861).
planeta('Kepler-467 b', 5.40777448090814, 24.99324193).
planeta('Kepler-1107 b', 2.60502724715204, 0.57103852).
planeta('Kepler-9 c', 53.6064229738505, 38.90861).
planeta('HD 74156 c', 2620.91807099664, 2520).
planeta('Kepler-165 c', 5.33721922303811, 15.31299).
planeta('Kepler-790 b', 5.1721771265881, 13.73469807).
planeta('Kepler-326 d', 1.81470030140563, 6.766888).
planeta('HD 20794 c', 2.36333735096998, 40.114).
planeta('WASP-47 c', 393.084953114332, 572).
planeta('Kepler-31 c', 18.3688071332792, 42.6318).
planeta('Kepler-82 b', 16.4617175820411, 26.444).
planeta('Kepler-573 b', 7.47386761553534, 22.18329658).
planeta('Kepler-1288 b', 1.39016422973807, 2.76122421).
planeta('Kepler-306 c', 5.71926640990999, 7.240193).
planeta('Kepler-1484 b', 4.98104229738525, 30.4549136).
planeta('Kepler-85 e', 2.14319859008597, 25.216751).
planeta('Kepler-583 b', 5.47772588747207, 6.5100253).
planeta('Kepler-610 b', 18.3319404219598, 6.99692655).
planeta('HD 38801 b', 3181.50184192737, 696.3).
planeta('Kepler-964 b', 5.01225187541604, 13.5225106).
planeta('HD 132563 B b', 474.331557267003, 1544).
planeta('Kepler-1227 b', 5.51313064299784, 94.2887577).
planeta('Kepler-351 d', 7.16603057601775, 142.544247).
planeta('Kepler-390 c', 0.401510267916739, 13.060022).
planeta('Kepler-61 b', 5.09583760883864, 59.87756).
planeta('Kepler-1486 b', 5.62128359008418, 54.6495759).
planeta('Kepler-803 b', 14.3211600468781, 50.28638192).
planeta('GJ 667 C c', 4.15344819155848, 28.1).
planeta('HD 207832 c', 232.099466175366, 1155.7).
planeta('Kepler-80 b', 7.06690361687513, 7.053).
planeta('Kepler-1462 b', 14.6408834226315, 65.6488341).
planeta('Kepler-886 b', 3.94928288680306, 6.24146367).
planeta('Kepler-1468 c', 1.54175633288601, 3.54553021).
planeta('Kepler-272 d', 5.39849423978289, 10.937304).
planeta('Kepler-1544 b', 4.17490080374869, 168.811174).
planeta('Kepler-44 b', 324.519226389652, 3.24674).
planeta('HD 5891 b', 1661.68755860598, 177.11).
planeta('Kepler-292 b', 2.44437101808314, 2.580827).
planeta('Kepler-228 d', 16.8775804420543, 11.094286).
planeta('Kepler-1000 b', 23.8547009042074, 120.0181272).
planeta('Kepler-140 b', 3.80861731413066, 3.25427).
planeta('Kepler-245 d', 8.703753817812, 36.277108).
planeta('Kepler-884 b', 1.93640176490188, 5.69919514).
planeta('Kepler-1073 c', 3.8629321500315, 4.02582254).
planeta('Kepler-908 b', 1.8764266175476, 1.34059747).
planeta('HD 173416 b', 863.850609510607, 323.6).
planeta('Kepler-1379 b', 2.32231360013276, 0.88184115).
planeta('Kepler-104 c', 9.28666101807962, 23.668205).
planeta('Kepler-263 b', 6.9310370730038, 16.568087).
planeta('Kepler-1008 b', 2.18865588077583, 12.43931193).
planeta('Kepler-278 c', 12.5647472873345, 51.078775).
planeta('Kepler-1587 b', 2.53240300401745, 9.4060467).
planeta('Kepler-1569 b', 3.95640197588544, 5.79180156).
planeta('Kepler-1273 b', 6.20647906898542, 28.625653).
planeta('Kepler-1365 c', 0.412052240455247, 4.77468005).
planeta('HD 76700 b', 73.7785525786627, 3.97097).
planeta('Kepler-366 b', 3.42622052913421, 3.281959).
planeta('HD 39091 b', 3206.1326188865, 2151).
planeta('Kepler-1636 b', 9.90141342933181, 425.47785).
planeta('Kepler-1068 b', 12.915330642994, 16.92344113).
planeta('Kepler-596 b', 11.5592395177436, 21.30022655).
planeta('HD 7449 b', 417.324815806885, 1275).
planeta('HD 149026 b', 114.881439718628, 2.8758911).
planeta('Kepler-186 b', 1.17611801071607, 3.8867907).
planeta('Kepler-219 c', 12.4821150033425, 22.714613).
planeta('OGLE-2006-BLG-109L c', 86.128265237732, 4927.5).
planeta('Kepler-561 c', 6.96946108506005, 5.35016198).
planeta('Kepler-1240 b', 1.54175633288601, 4.8663815).
planeta('Kepler-361 c', 6.32527886804765, 55.188023).
planeta('Kepler-265 e', 6.59917310783318, 67.831024).
planeta('Qatar-2 b', 789.484732082648, 1.3371182).
planeta('Kepler-1448 b', 3.81694410582523, 12.27065865).
planeta('Kepler-293 b', 8.93178713998201, 19.254196).
planeta('Kepler-166 b', 5.46069092431066, 7.650254).
planeta('Kepler-1551 b', 6.87373476222018, 24.4973698).
planeta('HD 216437 b', 689.080150702928, 1353).
planeta('Kepler-1052 b', 8.13893037507954, 34.8538276).
planeta('HAT-P-49 b', 549.692200267634, 2.691548).
planeta('Kepler-623 b', 8.62112153382008, 9.07097734).
planeta('Kepler-1621 b', 5.13966450100205, 92.263714).
planeta('Kepler-367 c', 1.76335704956373, 53.578637).
planeta('Kepler-313 b', 6.36348040857007, 14.970418).
planeta('Kepler-1439 b', 3.40432297387635, 8.07392849).
planeta('Kepler-150 c', 13.421199129263, 7.381998).
planeta('Kepler-87 b', 324.185519088916, 114.73635).
planeta('Kepler-681 b', 9.00431286000877, 26.39435646).
planeta('Kepler-564 b', 22.4879629269811, 3.75083228).
planeta('HAT-P-7 b', 569.399999999707, 2.204737).
planeta('Kepler-316 c', 1.56739140991212, 6.827766).
planeta('PSR B1257+12 C', 3.90021202277093, 98.2114).
planeta('HD 49674 b', 32.2809373743973, 4.94737).
planeta('HD 82943 b', 535.558901540247, 442.4).
planeta('Kepler-342 c', 4.59371935699697, 26.234138).
planeta('Kepler-783 b', 0.391988486269055, 4.29264638).
planeta('Kepler-1378 b', 5.23806048224781, 11.95398936).
planeta('Kepler-828 b', 3.85501851975689, 0.56785714).
planeta('WASP-38 b', 860.968014065197, 6.87188).
planeta('WASP-69 b', 82.4870418619804, 3.8681382).
planeta('Kepler-139 c', 10.9396245143949, 157.072878).
planeta('Kepler-1199 b', 1.54175633288601, 15.0447198).
planeta('Kepler-817 b', 159.186963496234, 3.99010623).
planeta('HD 77338 b', 15.8316781982504, 5.7361).
planeta('Kepler-29 c', 7.99419675150292, 13.2907).
planeta('Kepler-605 c', 0.548726038177883, 2.35895152).
planeta('Kepler-444 c', 0.0868458948425541, 4.5458841).
planeta('HD 220773 b', 460.754437374177, 3724.7).
planeta('Kepler-655 b', 7.11626051573646, 46.4063358).
planeta('Kepler-559 b', 12.725753114528, 17.58752333).
planeta('WASP-6 b', 165.696798392413, 3.361006).
planeta('HD 7924 d', 6.47713158070665, 24.451).
planeta('Kepler-1337 b', 5.92381309443768, 24.4002549).
planeta('Kepler-1552 b', 6.12394212993657, 184.771853).
planeta('Kepler-206 c', 4.14775927662211, 13.137471).
planeta('Kepler-169 c', 1.81470030140563, 6.195469).
planeta('HD 159868 c', 232.00602813116, 352.3).
planeta('HD 137388 b', 72.4036784996279, 330).
planeta('HD 95086 b', 1430.174146014, 0).
planeta('Kepler-196 b', 4.44698348961593, 20.739886).
planeta('Kepler-352 b', 0.541794460816868, 10.05537).
planeta('Kepler-329 b', 2.97992674145862, 7.416397).
planeta('Kepler-179 b', 3.87014658405695, 2.735926).
planeta('Kepler-1080 b', 10.2719874413879, 77.2548396).
planeta('Kepler-176 b', 3.19821898861189, 5.433074).
planeta('WASP-104 b', 404.262558606624, 1.7554137).
planeta('WASP-83 b', 95.3449430676, 4.971252).
planeta('Kepler-1095 b', 1.81766552913503, 4.27103091).
planeta('Kepler-1170 b', 5.92381309443768, 9.98969327).
planeta('Kepler-310 c', 10.9396245143949, 56.47542).
planeta('Kepler-339 b', 3.1243775083708, 4.977656).
planeta('Kepler-124 d', 1.34321320160681, 30.950851).
planeta('Kepler-52 c', 4.30209095780087, 16.3850021).
planeta('Kepler-1132 b', 5.73226510381487, 62.8916228).
planeta('Kepler-1265 b', 2.60502724715204, 6.49441289).
planeta('Kepler-1494 b', 8.93912870059822, 91.080482).
planeta('WASP-99 b', 883.52980575976, 5.75251).
planeta('HD 100777 b', 370.262551908718, 383.70001).
planeta('Kepler-818 b', 27.5778573677018, 10.03538581).
planeta('HAT-P-5 b', 335.490251171964, 2.788491).
planeta('Kepler-1381 b', 5.40777448090814, 25.3842686).
planeta('Kepler-125 b', 5.78645281312495, 4.164389).
planeta('Kepler-193 b', 5.85475157400905, 11.38848).
planeta('Kepler-1078 b', 4.46023643670233, 3.00725242).
planeta('Kepler-585 b', 7.63382464835508, 2.75235975).
planeta('HD 222582 b', 2424.94925318027, 572.38).
planeta('Kepler-119 c', 0.688282431345929, 4.125103).
planeta('Kepler-558 b', 5.76989457467888, 29.00790538).
planeta('Kepler-670 b', 317.816476892, 2.81650485).
planeta('Kepler-770 c', 1.76010896516989, 1.47532231).
planeta('Kepler-1188 b', 4.91941768251589, 17.1369543).
planeta('Kepler-434 b', 908.95512391112, 12.8747099).
planeta('Kepler-1398 c', 1.03453077026069, 4.13827595).
planeta('Kepler-16 b', 105.832886805036, 228.776).
planeta('Kepler-32 d', 7.05037716007675, 22.7802).
planeta('Kepler-58 c', 7.79378168117483, 15.5741568).
planeta('Kepler-758 b', 6.16500401875102, 12.1097104).
planeta('Kepler-1122 b', 4.79912414601227, 42.1917357).
planeta('Kepler-1534 b', 4.43338094440496, 5.71668872).
planeta('WASP-33 b', 0, 1.21986983).
planeta('HD 128311 b', 463.122170127022, 454.2).
planeta('HD 181433 d', 170.185002679082, 2172).
planeta('TrES-1 b', 239.1518137976, 3.030065).
planeta('HD 4208 b', 256.623138981784, 828).
planeta('Kepler-773 b', 3.23368730743303, 3.74910006).
planeta('Kepler-62 e', 0, 122.3874).
planeta('Kepler-120 b', 5.10130405224118, 6.312501).
planeta('HD 5388 b', 624.5379805757, 777).
planeta('Kepler-1393 b', 0.412052240455247, 2.44357812).
planeta('Kepler-1001 b', 9.40673208304942, 14.30511983).
planeta('CoRoT-10 b', 875.698807769141, 13.2406).
planeta('Kepler-1309 b', 5.76989457467888, 28.8432647).
planeta('11 UMi b', 3523.72662424467, 516.22).
planeta('Kepler-286 d', 2.5076514567971, 5.914323).
planeta('Kepler-338 c', 5.68608636972246, 24.310856).
planeta('WASP-62 b', 178.698670462065, 4.411953).
planeta('Kepler-496 b', 5.62128359008418, 8.30864937).
planeta('Kepler-1641 c', 8.25649068988189, 32.657212).
planeta('Kepler-1616 b', 0.994841848626414, 6.76284377).
planeta('Kepler-300 c', 5.39849423978289, 40.714955).
planeta('Kepler-1582 b', 3.67058961821646, 4.83817712).
planeta('HD 4732 c', 751.613720696198, 2732).
planeta('Kepler-258 c', 12.7316962826458, 33.653079).
planeta('Kepler-555 b', 7.63382464835508, 16.21775407).
planeta('Kepler-1270 b', 10.5014191560562, 6.03356196).
planeta('Kepler-632 b', 5.27143121232147, 30.99660733).
planeta('kappa CrB b', 627.592196918632, 1300).
planeta('Kepler-25 b', 7.10485090421604, 6.2385).
planeta('HD 99492 b', 33.7454356999157, 17.0431).
planeta('Kepler-167 c', 2.77116581044734, 7.406097).
planeta('Kepler-291 b', 5.13003466175222, 3.546511).
planeta('HD 204941 b', 84.8220395177059, 1733).
planeta('Kepler-664 b', 6.87373476222018, 2.52559332).
planeta('Kepler-1051 b', 11.0579158070941, 25.96200249).
planeta('Kepler-603 d', 2.46108180843812, 6.2171292).
planeta('Kepler-218 d', 6.87373476222018, 124.5244647).
planeta('Kepler-332 d', 1.66352453784241, 34.21154).
planeta('HD 196050 b', 903.679370394713, 1378).
planeta('WASP-11 b', 171.543032484841, 3.722465).
planeta('HD 111232 b', 2174.44312792922, 1143).
planeta('HD 117618 b', 56.1429162759256, 25.827).
planeta('Kepler-192 c', 7.4689732417912, 21.2234).
planeta('HD 180902 b', 497.049079035244, 479).
planeta('Kepler-671 b', 7.01795987943377, 4.28095859).
planeta('Kepler-1263 b', 1.49008573007291, 4.55139967).
planeta('HIP 12961 b', 112.606827193512, 57.435).
planeta('Kepler-1357 b', 2.18865588077583, 3.0091324).
planeta('HD 63454 b', 122.221411252449, 2.818049).
planeta('Kepler-460 c', 32.2507448090926, 220.1303357).
planeta('BD +48 738 b', 402.164969859137, 392.6).
planeta('Kepler-560 b', 4.02791068318614, 18.47764449).
planeta('Kepler-62 c', 0, 12.4417).
planeta('Kepler-371 c', 4.16994286670918, 67.968015).
planeta('Kepler-909 b', 3.49172250502165, 13.93290318).
planeta('Kepler-732 b', 5.1721771265881, 9.46781405).
planeta('Kepler-724 b', 10.3478820160697, 3.31494634).
planeta('NGC 2423 3 b', 2107.46012725947, 714.3).
planeta('Kepler-227 b', 9.1666535164052, 9.488015).
planeta('Kepler-33 c', 9.70236496985435, 13.17562).
planeta('Kepler-1280 b', 4.38021024782092, 66.5579057).
planeta('Kepler-1383 b', 3.06848948090934, 13.9093583).
planeta('Kepler-938 b', 5.30508797722433, 52.6298417).
planeta('Kepler-275 b', 5.68608636972246, 10.300682).
planeta('TRAPPIST-1 d', 1.56559892498245, 18.202).
planeta('HD 13908 b', 274.91125251158, 19.382).
planeta('HD 50499 b', 554.503941727779, 2457.8717).
planeta('CoRoT-14 b', 2445.48337575226, 1.51214).
planeta('Kepler-1542 e', 0.354028486269075, 5.10115756).
planeta('Kepler-820 b', 39.5166651037975, 127.8338098).
planeta('Kepler-521 b', 9.61534681848132, 22.20813214).
planeta('Kepler-1136 b', 3.8629321500315, 2.36172433).
planeta('Kepler-176 d', 6.28736336235444, 25.751974).
planeta('Kepler-319 d', 5.5238410582691, 31.781925).
planeta('Kepler-832 b', 4.8587782987249, 7.1396941).
planeta('Kepler-80 d', 4.08193948425778, 3.072186).
planeta('Kepler-155 b', 4.93340160749914, 5.931194).
planeta('Kepler-342 d', 6.2124222371033, 39.459357).
planeta('Kepler-1015 b', 12.2637750837177, 16.00494214).
planeta('CoRoT-4 b', 228.007579035382, 9.20205).
planeta('Kepler-610 c', 10.3478820160697, 151.86392).
planeta('HAT-P-19 b', 92.8891751506555, 4.008778).
planeta('Kepler-736 b', 8.13893037507954, 3.60147201).
planeta('Kepler-784 b', 3.74883603482728, 31.5922646).
planeta('Kepler-825 c', 4.30190026791473, 8.1818246).
planeta('HD 154857 c', 819.70272270554, 3452).
planeta('Kepler-1037 b', 2.18865588077583, 1.06378867).
planeta('Kepler-1425 b', 0.747431255860299, 14.4541302).
planeta('Kepler-24 c', 7.50431443402159, 12.3318).
planeta('Kepler-47 c', 23.1765123241676, 303.158).
planeta('GJ 163 b', 10.7663509711934, 8.631).
planeta('Kepler-133 c', 7.70816192230012, 31.517586).
planeta('Kepler-919 b', 5.40777448090814, 11.04603384).
planeta('HIP 116454 b', 11.8195947756135, 9.1205).
planeta('Kepler-924 b', 8.93912870059822, 61.0370117).
planeta('Kepler-988 b', 4.88897086402964, 17.76080053).
planeta('Kepler-33 f', 20.7882168452673, 41.02902).
planeta('Kepler-116 b', 11.2317932016017, 5.968734).
planeta('Kepler-869 b', 12.725753114528, 40.4287755).
planeta('Kepler-848 b', 4.00394732082848, 6.91134416).
planeta('Kepler-107 c', 4.23728817816259, 4.901425).
planeta('Kepler-84 e', 6.63953580039846, 27.434389).
planeta('Kepler-109 b', 5.78645281312495, 6.48163).
planeta('Kepler-764 b', 3.8629321500315, 7.33683936).
planeta('Kepler-734 b', 12.3548295043473, 6.10485286).
planeta('Kepler-315 b', 14.1467741460075, 96.101141).
planeta('Kepler-837 b', 6.46292518418958, 16.56059504).
planeta('Kepler-639 b', 5.80787364366748, 10.21420496).
planeta('KIC 11442793 f', 8.08089708639906, 124.9144).
planeta('Kepler-1208 b', 5.62128359008418, 11.08507637).
planeta('Kepler-1238 b', 4.51458305425086, 4.14787559).
planeta('Kepler-586 b', 7.47386761553534, 2.10472218).
planeta('Kepler-757 b', 2.67895771600666, 1.02267882).
planeta('HD 2039 b', 1883.05944742033, 1120).
planeta('Kepler-170 b', 9.72051229068489, 7.930592).
planeta('Kepler-36 c', 8.10082417950019, 16.23855).
planeta('Kepler-247 d', 15.8137851306014, 20.477912).
planeta('Kepler-136 b', 4.82553469524199, 11.5789).
planeta('XO-2 b', 180.056064634871, 2.615857).
planeta('Kepler-859 b', 9.07003730743003, 20.38177573).
planeta('Kepler-305 d', 7.10485090421604, 16.738661).
planeta('Kepler-120 c', 3.99666932350766, 12.794585).
planeta('Kepler-393 b', 2.26060317481464, 9.182417).
planeta('Kepler-96 b', 8.31595415270838, 16.23844).
planeta('Kepler-11 d', 7.29970418619852, 22.6845).
planeta('Kepler-1497 b', 3.90939691895311, 8.74199772).
planeta('Kepler-1257 b', 3.94928288680306, 2.66831376).
planeta('HD 187085 b', 255.427195579239, 986).
planeta('HD 118203 b', 678.929092430997, 6.1335).
planeta('Kepler-833 b', 4.74042344273032, 18.7546998).
planeta('Kepler-106 b', 0.45771611185509, 6.16486).
planeta('Kepler-198 d', 3.94928288680306, 1.31184443).
planeta('Kepler-464 b', 10.3478820160697, 7.25696522).
planeta('WASP-63 b', 120.165138646958, 4.37808).
planeta('Kepler-30 b', 11.3006004688488, 29.334).
planeta('Kepler-836 b', 7.21624557936668, 11.36112327).
planeta('Kepler-214 c', 5.04451024782058, 28.7798).
planeta('Kepler-946 b', 4.51458305425086, 11.79162572).
planeta('HD 175167 b', 2472.09097119766, 1290).
planeta('Kepler-273 b', 3.74562608841067, 2.936532).
planeta('Kepler-461 b', 6.551437073004, 8.31378306).
planeta('Kepler-1603 b', 2.2548506965829, 2.27163926).
planeta('Kepler-323 c', 3.84952029470666, 3.553822).
planeta('Kepler-84 d', 2.83966479571187, 4.224537).
planeta('Kepler-267 c', 5.04451024782058, 6.87745).
planeta('HAT-P-16 b', 1335.62374413863, 2.77596).
planeta('TrES-4 b', 293.9802411251, 3.553945).
planeta('Kepler-231 c', 4.51960455458575, 19.271566).
planeta('NGC 4349 127 b', 3141.80974212832, 677.8).
planeta('Kepler-184 b', 5.75273248492671, 10.687576).
planeta('GJ 676 A b', 1556.35046550489, 1056.8).
planeta('Kepler-60 b', 5.48573486268975, 7.1316185).
planeta('Kepler-1124 b', 2.18865588077583, 2.85234897).
planeta('Kepler-1235 b', 0.391988486269055, 4.16055856).
planeta('Kepler-151 b', 8.87416701272149, 15.228958).
planeta('Kepler-242 c', 4.69494390488707, 14.496481).
planeta('Kepler-230 b', 18.9482501339487, 32.625555).
planeta('HD 47186 c', 110.69071165433, 1353.6).
planeta('Kepler-463 b', 8.81034946416158, 8.98101683).
planeta('Kepler-1553 b', 1.54175633288601, 4.24261881).
planeta('Kepler-1003 b', 4.17490080374869, 3.55485691).
planeta('Kepler-840 b', 317.816476892, 2.49577962).
planeta('Kepler-351 c', 9.657203248488, 57.24809).
planeta('Kepler-534 b', 5.37325961151767, 15.95994513).
planeta('Kepler-350 b', 4.32901001339362, 11.189562).
planeta('Kepler-382 b', 2.44437101808314, 5.262155).
planeta('Kepler-900 b', 4.91941768251589, 6.9913086).
planeta('HIP 14810 d', 184.524246483495, 950.69651).
planeta('Kepler-209 b', 5.42948134627986, 16.087845).
planeta('Kepler-123 c', 3.58376215672957, 26.695074).
planeta('HD 142245 b', 600.793911587099, 1299).
planeta('Kepler-1251 b', 4.30190026791473, 45.0904643).
planeta('Kepler-59 c', 4.75335857333982, 17.9801235).
planeta('Kepler-493 b', 317.816476892, 3.00387658).
planeta('KIC 11442793 b', 2.39105412591973, 7.008151).
planeta('Kepler-1054 b', 6.77962930341245, 4.30655689).
planeta('Kepler-258 b', 17.0979226054835, 13.19722).
planeta('Kepler-1607 b', 0.685994152712306, 13.6473676).
planeta('Kepler-309 c', 6.28736336235444, 105.356383).
planeta('Kepler-1447 b', 8.02334052243392, 56.6747285).
planeta('Kepler-302 c', 317.816476892, 127.282184).
planeta('Kepler-1489 b', 4.15001577360805, 82.294751).
planeta('HD 30177 b', 3078.94882116386, 2770).
planeta('Kepler-466 b', 7.74277213663366, 51.07926307).
planeta('Kepler-678 b', 27.9529125920821, 7.27503724).
planeta('Kepler-446 d', 2.8307754688532, 5.148921).
planeta('Kepler-4 b', 24.5442990957677, 3.21346).
planeta('Kepler-1370 b', 4.30190026791473, 20.2641684).
planeta('Kepler-882 b', 1.93640176490188, 3.98953967).
planeta('bet Cnc b', 2478.9685197576, 605.2).
planeta('HD 190647 b', 604.7920428664, 1038.1).
planeta('Kepler-530 b', 8.62112153382008, 39.30941904).
planeta('Kepler-1522 b', 4.05203295378224, 1.84788917).
planeta('Kepler-759 b', 5.47772588747207, 41.805985).
planeta('Kepler-1351 b', 0.203206134628161, 0.91614077).
planeta('Kepler-529 c', 4.68264440723135, 12.8345022).
planeta('Kepler-977 b', 6.73319631613853, 26.85328322).
planeta('HD 97658 b', 7.86246182183119, 9.4909).
planeta('Kepler-261 b', 5.18813151372808, 10.381227).
planeta('Kepler-658 b', 3.83989045545683, 1.28707676).
planeta('Kepler-57 b', 5.21174527796115, 5.7293196).
planeta('Kepler-175 b', 6.47996014735099, 11.903515).
planeta('Kepler-509 b', 6.20647906898542, 41.74600392).
planeta('Kepler-577 b', 6.41922541861693, 25.69578251).
planeta('Kepler-323 b', 3.19821898861189, 1.678327).
planeta('Kepler-1153 b', 4.05203295378224, 1.75583533).
planeta('Kepler-433 b', 896.24246483544, 5.33408384).
planeta('Kepler-1319 b', 2.60502724715204, 2.88676265).
planeta('Kepler-377 c', 4.85219949765323, 27.014976).
planeta('HD 106270 b', 3523.59949765391, 2890).
planeta('Kepler-1287 b', 3.65949782317293, 11.47685909).
planeta('Kepler-426 b', 317.816476892, 3.21751883).
planeta('Kepler-379 c', 5.5238410582691, 62.784697).
planeta('WASP-20 b', 98.840924313412, 4.8996285).
planeta('HD 30856 b', 590.251939048591, 912).
planeta('Kepler-315 c', 17.9540884125829, 265.469335).
planeta('Kepler-80 c', 6.991962491624, 9.522).
planeta('Kepler-179 c', 4.69494390488707, 6.40013).
planeta('HD 24064 b', 3003.8773911572, 535.6).
planeta('HD 48265 b', 383.429688546353, 762).
planeta('Kepler-476 b', 9.00431286000877, 14.00640607).
planeta('Kepler-154 e', 3.76208898191367, 3.93276465).
planeta('HATS-4 b', 420.471198928116, 2.156729).
planeta('Kepler-1608 b', 4.05203295378224, 16.4735686).
planeta('Kepler-527 b', 7.68807592096055, 13.28535633).
planeta('CoRoT-27 b', 3301.54112524947, 3.57532).
planeta('Kepler-1115 b', 4.00394732082848, 23.5540725).
planeta('Kepler-1141 b', 0.454433067648795, 2.34451194).
planeta('Kepler-360 c', 4.96086095110261, 7.186434).
planeta('Kepler-154 d', 14.8577931681102, 20.54981883).
planeta('Kepler-262 b', 2.70371879772132, 13.060855).
planeta('Kepler-969 c', 0.882395200937255, 1.6829346).
planeta('Kepler-1106 b', 3.88610097119693, 1.25275217).
planeta('Kepler-381 b', 0.893985967849507, 5.629021).
planeta('Kepler-168 c', 7.01729246483229, 13.193242).
planeta('Kepler-84 f', 5.24708647019154, 44.552169).
planeta('Kepler-874 b', 15.8713734762142, 40.0686727).
planeta('Kepler-987 b', 10.1220098459426, 105.3033148).
planeta('Kepler-529 b', 4.35392682518195, 1.98035766).
planeta('HD 89307 b', 569.36186202248, 2166).
planeta('Kepler-1039 b', 3.40432297387635, 0.93488424).
planeta('Kepler-1112 b', 8.62112153382008, 14.36267939).
planeta('HD 163607 c', 728.562491627221, 1314).
planeta('Kepler-960 b', 5.51313064299784, 3.12686223).
planeta('WASP-49 b', 120.208043871338, 2.7817387).
planeta('Kepler-288 b', 3.93253395847085, 6.097326).
planeta('Kepler-37 c', 3.42914444072161, 21.301886).
planeta('Kepler-1314 b', 27.5778573677018, 5.42474928).
planeta('Kepler-55 b', 5.98677253850998, 27.9481449).
planeta('Kepler-1504 b', 5.04368392498066, 82.304003).
planeta('HD 4313 b', 690.211577360663, 356).
planeta('Kepler-1197 b', 2.06004190890718, 2.03231845).
planeta('HR 8799 b', 2224.715338244, 164253).
planeta('Kepler-774 b', 9.54523650367895, 11.0895723).
planeta('Kepler-1173 b', 0.600930572672163, 0.7698536).
planeta('HD 2638 b', 151.701749832474, 3.4442).
planeta('Kepler-272 b', 3.19821898861189, 2.971353).
planeta('Kepler-231 b', 4.06026440053375, 10.065275).
planeta('Kepler-512 b', 7.01795987943377, 34.43587975).
planeta('Kepler-747 b', 29.3504152042716, 35.61760587).
planeta('Kepler-827 b', 33.6157665773437, 51.92927591).
planeta('Kepler-1057 b', 10.8157396517024, 14.08827448).
planeta('HD 168443 b', 2446.37644005233, 58.11247).
planeta('WASP-41 c', 945.554869390003, 350.3).
planeta('Kepler-373 b', 2.70371879772132, 5.535309).
planeta('Kepler-1622 b', 3.49172250502165, 10.8118737).
planeta('Kepler-288 d', 6.9310370730038, 56.633742).
planeta('HD 10180 f', 23.6217732082933, 122.72).
planeta('Kepler-445 c', 6.50697454788681, 4.871229).
planeta('Kepler-1088 b', 3.15041303415779, 23.12748644).
planeta('HD 45350 b', 583.555545880477, 963.6).
planeta('Kepler-770 d', 2.98791029135814, 4.15244722).
planeta('HD 69830 c', 11.686397890148, 31.559999).
planeta('Kepler-963 b', 6.87373476222018, 9.97683705).
planeta('TYC 1422-614-1 b', 794.54119223, 198.4).
planeta('Kepler-21 b', 3.86061208975019, 2.785755).
planeta('Kepler-352 c', 1.974511138646, 16.332995).
planeta('Kepler-363 b', 1.56739140991212, 3.614568).
planeta('Kepler-1053 b', 0.847092146684092, 2.41435165).
planeta('Kepler-390 b', 0.457859129269691, 6.738088).
planeta('CoRoT-28 b', 153.823174815728, 5.20851).
planeta('Kepler-340 b', 6.36348040857007, 14.844387).
planeta('Kepler-679 b', 8.62112153382008, 12.39358604).
planeta('Kepler-335 c', 8.93178713998201, 67.844469).
planeta('Kepler-841 b', 28.9657937039369, 124.4198398).
planeta('HD 47186 b', 22.6294866041411, 4.0845).
planeta('Kepler-226 b', 3.68794239785477, 3.940997).
planeta('KELT-3 b', 464.533275284423, 2.70339).
planeta('Kepler-51 c', 4.0044876088392, 85.3128662).
planeta('Kepler-1639 b', 6.551437073004, 9.878482).
planeta('HD 148427 b', 363.445388479384, 331.5).
planeta('Kepler-810 b', 4.51458305425086, 4.59725385).
planeta('Kepler-226 c', 5.46069092431066, 5.349555).
planeta('Kepler-1520 b', 35.433676825166, 0.65355357).
planeta('Kepler-533 b', 10.9765865706575, 28.51120525).
planeta('epsilon Tau b', 2439.75950100343, 594.90002).
planeta('Kepler-11 e', 8.40027086402783, 31.9996).
planeta('Kepler-366 c', 4.19225358338699, 12.51616).
planeta('Kepler-1419 b', 7.79794507702211, 42.5215895).
planeta('HAT-P-46 b', 156.683523107756, 4.463129).
planeta('HD 208487 b', 162.785599464082, 130.08).
planeta('Kepler-1033 b', 6.29044618218029, 7.56052806).
planeta('Kepler-616 c', 11.1399124581322, 90.4113556).
planeta('Kepler-288 c', 7.7570738780938, 19.305772).
planeta('Kepler-1517 b', 221.205352980462, 5.54608367).
planeta('Kepler-48 d', 4.7990288010692, 42.8961).
planeta('Kepler-626 b', 5.51313064299784, 14.48585199).
planeta('Kepler-311 b', 3.99590656396312, 9.176092).
planeta('Kepler-117 c', 293.584241794893, 50.790412).
planeta('epsilon Eri b', 335.131118553076, 2500).
planeta('Kepler-271 d', 0.215633394507592, 5.24972541).
planeta('Kepler-69 c', 4.01399032149827, 242.4613).
planeta('Kepler-935 b', 2.60502724715204, 4.88083852).
planeta('Kepler-1245 b', 3.23368730743303, 4.35409304).
planeta('Kepler-296 f', 4.19225358338699, 63.335879).
planeta('HD 20782 b', 603.8513060948, 591.9).
planeta('Kepler-613 b', 5.51313064299784, 15.77979614).
planeta('Kepler-1011 b', 7.8535947421259, 5.75322197).
planeta('Kepler-1536 b', 9.33827441392688, 364.758031).
planeta('Kepler-726 b', 10.1220098459426, 21.80451088).
planeta('Kepler-1400 b', 3.83989045545683, 9.06689421).
planeta('Kepler-896 b', 6.37593881446424, 144.547396).
planeta('Kepler-228 c', 7.06089688546188, 4.134444).
planeta('HD 190360 c', 18.7428453449334, 17.111027).
planeta('Kepler-23 c', 9.70236496985435, 10.7421).
planeta('Kepler-823 b', 3.72633462826332, 4.16809082).
planeta('Kepler-1490 b', 8.74675438713549, 92.4362973).
planeta('Kepler-378 b', 0.334527267246981, 16.092361).
planeta('Kepler-760 b', 8.87448482919838, 8.70419416).
planeta('Kepler-1558 b', 0.242147869725261, 3.50470358).
planeta('Kepler-1618 b', 2.06004190890718, 6.10826019).
planeta('HD 65216 b', 386.579249832353, 613.09998).
planeta('Kepler-343 c', 4.74662086402971, 23.22182).
planeta('Kepler-42 b', 0.382714601473346, 1.2137672).
planeta('Kepler-593 b', 7.8535947421259, 21.21708973).
planeta('Kepler-212 b', 1.25978955458743, 16.257582).
planeta('Kepler-296 c', 5.10130405224118, 5.841648).
planeta('Kepler-1482 b', 0.95624621567265, 12.25383217).
planeta('Kepler-157 d', 3.40432297387635, 7.02573474).
planeta('Kepler-1004 b', 46.3385957802843, 5.28789787).
planeta('Kepler-356 b', 3.72782836570471, 4.612696).
planeta('Kepler-968 b', 4.68264440723135, 3.69298373).
planeta('HAT-P-13 b', 272.394146014595, 2.91625).
planeta('Kepler-244 b', 7.32983318820789, 4.311792).
planeta('Kepler-448 b', 0, 17.8552333).
planeta('GJ 3634 b', 7.05174377092739, 2.64561).
planeta('Kepler-9 b', 79.118822839879, 19.243158).
planeta('Kepler-1070 b', 4.05203295378224, 6.2216147).
planeta('Kepler-1087 b', 0.1586771858673, 0.69384285).
planeta('Kepler-1071 b', 5.80787364366748, 6.1799844).
planeta('Kepler-1432 b', 5.30508797722433, 23.9109011).
planeta('HD 130322 b', 331.511188881276, 10.7085).
planeta('Kepler-1422 b', 4.74042344273032, 18.6051942).
planeta('Kepler-1388 e', 6.08319805759902, 37.6327084).
planeta('Kepler-934 b', 4.91941768251589, 55.6738309).
planeta('Kepler-31 d', 21.7998266912145, 87.648901).
planeta('Kepler-399 d', 4.42308369055365, 58.034616).
planeta('Kepler-215 c', 4.14775927662211, 14.667108).
planeta('Kepler-108 b', 85.3419872739012, 49.183921).
planeta('Kepler-742 b', 9.97438409242622, 8.36086824).
planeta('Kepler-1050 c', 3.58045686536989, 21.1284569).
planeta('Kepler-1298 b', 2.39105412591973, 7.12811928).
planeta('Kepler-1297 b', 0.847092146684092, 1.68189002).
planeta('Kepler-1613 b', 4.91941768251589, 1.5184299).
planeta('Kepler-903 c', 6.37593881446424, 62.9228557).
planeta('Kepler-348 c', 2.5076514567971, 17.265427).
planeta('Kepler-1543 b', 7.11626051573646, 6.96710269).
planeta('Kepler-124 b', 0.304310547889998, 3.410493).
planeta('Kepler-185 c', 4.74662086402971, 20.729042).
planeta('Kepler-191 c', 4.3523059611498, 17.738506).
planeta('omega Ser b', 540.551798392221, 277.02).
planeta('Kepler-111 b', 3.7478825853966, 3.341815).
planeta('Kepler-673 b', 52.4931118552979, 3.72873109).
planeta('Kepler-965 b', 10.9765865706575, 134.2527298).
planeta('Kepler-1295 b', 3.68168141326, 3.81371974).
planeta('Kepler-968 c', 3.98011108506158, 5.70940492).
planeta('HD 16175 b', 1391.86454788944, 990).
planeta('Kepler-235 b', 5.33721922303811, 3.340222).
planeta('Kepler-1436 b', 2.39105412591973, 9.705716).
planeta('HD 46375 b', 72.2082213663393, 3.023573).
planeta('Kepler-48 c', 14.6093878097715, 9.67395).
planeta('Kepler-114 b', 2.08600115873972, 5.188549).
planeta('Kepler-60 d', 6.43200164098799, 11.9016171).
planeta('Kepler-741 b', 8.37602146684097, 7.03902374).
planeta('CoRoT-29 b', 270.1440053582, 2.85057).
planeta('Kepler-868 b', 4.82883998660167, 5.03251791).
planeta('Kepler-14 b', 2671.70196583922, 6.790123).
planeta('Kepler-234 c', 11.9186899531084, 7.21205).
planeta('Kepler-1308 b', 0.0915098516409443, 2.10433812).
planeta('Kepler-1302 b', 3.23368730743303, 8.83922659).
planeta('CoRoT-13 b', 416.654223040643, 4.03519).
planeta('HD 98219 b', 674.892823174469, 436.9).
planeta('HD 12648 b', 921.467558606358, 133.6).
planeta('HD 11964 b', 193.266106496887, 1944.5898).
planeta('HAT-P-34 b', 1059.60013395793, 5.452654).
planeta('Kepler-654 b', 4.88897086402964, 13.72465129).
planeta('Kepler-421 b', 18.8403832216916, 704.1984).
planeta('Kepler-1241 b', 6.77962930341245, 18.5525701).
planeta('MOA-2010-BLG-477L b', 476.724715338, 0).
planeta('Kepler-31 b', 19.2810993301977, 20.8613).
planeta('Kepler-85 c', 5.1721771265881, 12.513).
planeta('Kepler-1198 b', 3.49172250502165, 7.6847716).
planeta('Kepler-1139 b', 1.70375056932263, 0.81316672).
planeta('Kepler-219 d', 7.56352364366657, 47.903645).
planeta('Kepler-1206 b', 3.8629321500315, 1.21699766).
planeta('mu Leo b', 762.7595445408, 357.8).
planeta('Kepler-431 b', 0.384167022772743, 6.803).
planeta('Kepler-1531 b', 1.34189744139248, 1.13854338).
planeta('Kepler-248 c', 17.2090948091003, 16.239494).
planeta('Kepler-481 b', 6.24827193569672, 10.06082567).
planeta('HD 139357 b', 3202.12813127766, 1125.7).
planeta('HD 1461 b', 7.62899383790633, 5.7727).
planeta('Kepler-1275 b', 3.58045686536989, 3.65691115).
planeta('Kepler-283 c', 4.26001205626037, 92.743711).
planeta('HAT-P-30 b', 225.995482920178, 2.810595).
planeta('Kepler-430 c', 4.1007224380421, 110.979).
planeta('Kepler-1360 b', 11.0579158070941, 40.5286413).
planeta('Kepler-901 b', 2.75420394507561, 3.51749439).
planeta('Kepler-251 d', 7.37585301406185, 30.133001).
planeta('Kepler-234 b', 13.5099017079636, 2.711506).
planeta('Kepler-37 b', 3.04682075351484, 13.367308).
planeta('Kepler-392 c', 1.30105802411186, 10.423118).
planeta('HD 8535 b', 216.813129269815, 1313).
planeta('Kepler-1619 b', 0.354028486269075, 23.6225913).
planeta('Kepler-1473 b', 1.70375056932263, 14.4273551).
planeta('HAT-P-28 b', 199.535672136535, 3.257215).
planeta('Kepler-474 b', 8.87448482919838, 5.66067294).
planeta('Kepler-349 c', 4.59371935699697, 12.247629).
planeta('HD 4203 b', 661.741577360678, 431.88).
planeta('Kepler-553 c', 274.168197588606, 328.2399546).
planeta('Kepler-331 d', 3.87014658405695, 32.134328).
planeta('HD 102956 b', 302.401424313307, 6.4948).
planeta('WTS-2 b', 355.95445411904, 1.0187074).
planeta('Kepler-362 c', 3.3491500334879, 37.866281).
planeta('Kepler-1147 b', 6.68714470863688, 10.62784997).
planeta('Kepler-186 e', 2.13667381781538, 22.407793).
planeta('Kepler-321 c', 5.62042548559657, 13.093921).
planeta('Kepler-1083 b', 10.8157396517024, 33.4177993).
planeta('Kepler-376 c', 4.19225358338699, 14.172327).
planeta('Kepler-1589 b', 1.24868504688482, 0.99166527).
planeta('Fomalhaut b', 158.908238446, 318498).
planeta('GJ 176 b', 8.26224316811364, 8.7832).
planeta('Kepler-873 b', 14.0080472538441, 20.5533844).
planeta('HD 23079 b', 776.520997990224, 730.6).
planeta('HD 178911 B b', 2317.28574346833, 71.484).
planeta('WASP-58 b', 283.294933355514, 5.01718).
planeta('Kepler-506 b', 7.21624557936668, 6.8834055).
planeta('Kepler-1571 b', 3.94928288680306, 3.38555488).
planeta('Kepler-543 b', 6.24827193569672, 13.89961966).
planeta('Kepler-1535 b', 6.41922541861693, 138.9442).
planeta('Kepler-1030 b', 6.16500401875102, 19.32952416).
planeta('Kepler-244 c', 4.82553469524199, 9.767292).
planeta('Kepler-245 e', 4.1007224380421, 3.21982106).
planeta('Kepler-1067 b', 0.412052240455247, 0.76212926).
planeta('Kepler-354 b', 4.30587297387588, 5.47666).
planeta('Kepler-1203 b', 1.15983309444013, 0.58800076).
planeta('Kepler-278 b', 17.2090948091003, 30.160546).
planeta('HD 162020 b', 4835.19631613951, 8.428198).
planeta('Kepler-809 b', 8.62112153382008, 55.63934).
planeta('Kepler-1468 b', 4.05203295378224, 8.23984869).
planeta('Kepler-1368 b', 3.88610097119693, 0.67564949).
planeta('Kepler-183 b', 4.85219949765323, 5.687945).
planeta('Kepler-1392 b', 4.59766028131043, 15.1410397).
planeta('MOA-bin-1L b', 1175.9209645004, 0).
planeta('Kepler-1556 b', 4.59766028131043, 8.82713457).
planeta('Kepler-944 b', 6.77962930341245, 43.3167737).
planeta('Kepler-1110 b', 6.87373476222018, 9.69312032).
planeta('Kepler-210 c', 12.8159176490222, 7.972513).
planeta('Kepler-437 b', 5.07285947755935, 66.65062).
planeta('Kepler-184 d', 6.2124222371033, 29.022358).
planeta('HD 168746 b', 77.8977719356599, 6.404).
planeta('GJ 876 c', 194.557077026022, 30.0881).
planeta('Kepler-1164 b', 1.39016422973807, 3.97599768).
planeta('Kepler-958 b', 4.8587782987249, 9.7678805).
planeta('Kepler-20 c', 15.73375894172, 10.854092).
planeta('Kepler-712 c', 24.7889224380315, 226.89047).
planeta('Kepler-47 b', 8.41355559276192, 49.514).
planeta('Kepler-580 b', 6.50697454788681, 8.22241966).
planeta('Kepler-296 b', 0.74304221031442, 3.621457).
planeta('Kepler-755 b', 4.12528965170585, 1.26909037).
planeta('Kepler-402 b', 1.86700335900775, 4.028751).
planeta('Kepler-260 b', 4.72068703951532, 8.187399).
planeta('Kepler-255 c', 8.48226751506597, 9.946047).
planeta('Kepler-750 b', 8.93912870059822, 9.42887179).
planeta('HD 215497 b', 6.62806262558266, 3.93404).
planeta('Kepler-1221 b', 4.40671614199372, 12.00096042).
planeta('Kepler-62 f', 0, 267.291).
planeta('Kepler-1160 b', 5.07543379102217, 7.97034958).
planeta('HATS-5 b', 75.5332173475834, 4.763387).
planeta('HD 154345 b', 304.118904554432, 3341.5588).
planeta('Kepler-60 c', 6.13055271265592, 8.9193459).
planeta('Kepler-1031 b', 0.574389718686912, 1.22621732).
planeta('Kepler-523 b', 4.59766028131043, 5.83598311).
planeta('Kepler-395 c', 2.44437101808314, 34.989262).
planeta('HD 217107 b', 445.299022102919, 7.1268163).
planeta('Kepler-1550 b', 8.62112153382008, 225.582809).
planeta('Kepler-431 c', 0.240768228399072, 8.703).
planeta('mu Ara c', 600.377572002371, 4205.8).
planeta('HD 7199 b', 93.7615813797241, 615).
planeta('Kepler-887 c', 1.43955926657662, 7.63846023).
planeta('Kepler-233 c', 7.10485090421604, 60.418955).
planeta('GJ 433 b', 5.78381493636675, 7.3709).
planeta('Kepler-1301 b', 2.98791029135814, 9.08237046).
planeta('Kepler-1350 c', 4.05203295378224, 1.76678906).
planeta('HD 159243 b', 359.13261888796, 12.62).
planeta('Kepler-327 d', 4.06026440053375, 13.969457).
planeta('HAT-P-31 b', 689.356651037824, 5.005425).
planeta('Kepler-878 b', 4.51458305425086, 25.9422033).
planeta('OGLE-TR-113 b', 400.44876088392, 1.4324757).
planeta('Kepler-356 c', 4.23728817816259, 13.121632).
planeta('Kepler-41 b', 156.856733087662, 1.855558).
planeta('Kepler-798 b', 5.84620231078065, 13.71933369).
planeta('Kepler-825 b', 3.94928288680306, 3.77360059).
planeta('Kepler-473 b', 17.3217607501585, 14.55731705).
planeta('Kepler-270 b', 4.72068703951532, 11.476094).
planeta('HD 285507 b', 291.437709309964, 6.0881).
planeta('Kepler-1307 b', 6.12394212993657, 18.01621096).
planeta('Kepler-1573 b', 1.76010896516989, 2.6157554).
planeta('HD 40307 d', 8.92301540521979, 20.46).
planeta('Kepler-590 b', 16.7034170127175, 5.85296257).
planeta('Kepler-1220 b', 3.94928288680306, 7.42693741).
planeta('Kepler-849 b', 47.5132454788771, 394.6244904).
planeta('HD 290327 b', 809.675612859597, 2443).
planeta('Kepler-438 b', 1.38628686871998, 35.23319).
planeta('Kepler-1315 b', 2.8307754688532, 0.84338011).
planeta('GJ 876 e', 12.4676225719963, 124.26).
planeta('Kepler-1413 b', 4.25057290689668, 13.1829642).
planeta('Kepler-1604 b', 3.06848948090934, 0.68368426).
planeta('Kepler-1471 b', 3.06848948090934, 3.63899398).
planeta('Kepler-1445 b', 0.81284424313421, 10.60052251).
planeta('Kepler-1020 b', 5.47772588747207, 96.9151496).
planeta('Kepler-572 b', 6.551437073004, 17.20523483).
planeta('Kepler-1598 b', 0.779632421298996, 4.34195123).
planeta('Kepler-1187 b', 6.68714470863688, 18.87064068).
planeta('Kepler-949 b', 8.08089708639906, 8.6893073).
planeta('HD 169830 c', 1291.62840924247, 2102).
planeta('Kepler-608 b', 13.0111205291293, 6.41251504).
planeta('47 UMa c', 173.455969859254, 2391).
planeta('Kepler-85 b', 4.62575525786768, 8.306).
planeta('Kepler-880 b', 6.87373476222018, 7.71468975).
planeta('Kepler-1343 b', 4.51458305425086, 3.35183158).
planeta('Kepler-575 b', 5.84620231078065, 9.37891944).
planeta('Kepler-313 c', 6.51940117213329, 32.273273).
planeta('Kepler-199 b', 9.1666535164052, 23.637604).
planeta('Kepler-172 b', 5.71926640990999, 2.940309).
planeta('Kepler-223 d', 8.42792089751744, 14.788759).
planeta('Kepler-431 d', 1.43955926657662, 11.922).
planeta('Kepler-917 b', 4.46023643670233, 2.97041437).
planeta('Kepler-1072 b', 3.74883603482728, 1.5690665).
planeta('Kepler-360 b', 3.89083643670262, 3.289672).
planeta('Kepler-1212 b', 5.07543379102217, 12.94130146).
planeta('Kepler-246 b', 5.68608636972246, 4.60182).
planeta('Kepler-347 b', 4.61876329537606, 12.79836).
planeta('HD 63765 b', 204.618828867946, 358).
planeta('Kepler-217 c', 4.32901001339362, 8.586004).
planeta('HD 85390 b', 41.9149082384245, 788).
planeta('Kepler-1590 b', 1.49008573007291, 7.61760804).
planeta('Kepler-1498 b', 2.53240300401745, 48.051405).
planeta('Kepler-401 c', 5.10130405224118, 47.318218).
planeta('Kepler-299 c', 6.84611651037826, 6.885875).
planeta('Kepler-1176 b', 6.08319805759902, 24.1738579).
planeta('HAT-P-57 b', 317.816476892, 2.465295).
planeta('Kepler-525 b', 6.77962930341245, 18.68404933).
planeta('Kepler-112 b', 5.75273248492671, 8.408878).
planeta('Kepler-1326 b', 18.2310972538419, 42.3514267).
planeta('Kepler-748 b', 6.33300180843613, 7.40742793).
planeta('Kepler-155 c', 5.36772960481975, 52.661793).
planeta('Kepler-271 c', 0.926698817816, 7.410935).
planeta('Kepler-961 b', 6.41922541861693, 16.87727414).
planeta('Kepler-241 c', 6.51940117213329, 36.065978).
planeta('Kepler-492 b', 204.6153328867, 11.72012266).
planeta('WASP-77 A b', 559.105924313175, 1.3600309).
planeta('Kepler-164 c', 7.19377595445042, 10.945723).
planeta('Kepler-371 b', 4.42308369055365, 34.763278).
planeta('Kepler-548 b', 317.816476892, 4.45419434).
planeta('55 Cnc e', 8.37989882785905, 0.736546).
planeta('HIP 57274 d', 167.989208640235, 431.7).
planeta('Kepler-1254 d', 2.39105412591973, 5.72717226).
planeta('HD 221287 b', 990.109561285492, 456.10001).
planeta('KOI-13 b', 2070.57434695138, 1.76358799).
planeta('Kepler-1017 b', 4.68264440723135, 7.23400469).
planeta('Kepler-1100 b', 4.1007224380421, 6.42200058).
planeta('Kepler-1050 b', 3.79412488278439, 15.3787546).
planeta('Kepler-1460 b', 4.59766028131043, 29.9633247).
planeta('Kepler-1310 b', 3.23368730743303, 0.67933627).
planeta('HD 192699 b', 728.406761553544, 345.53).
planeta('Kepler-178 d', 15.9172979571251, 96.678988).
planeta('Kepler-1371 c', 0.191311852980478, 2.00541269).
planeta('Kepler-1090 b', 5.40777448090814, 198.680179).
planeta('Kepler-312 b', 2.26060317481464, 1.772419).
planeta('Kepler-164 b', 3.05161660415114, 5.03503).
planeta('Kepler-1557 b', 3.94928288680306, 3.74032496).
planeta('Kepler-341 b', 1.66352453784241, 5.195528).
planeta('Kepler-311 c', 3.19821898861189, 19.738286).
planeta('Kepler-1509 b', 4.32783409242912, 25.4338197).
planeta('HD 181342 b', 1000.94392498274, 663).
planeta('WASP-8 b', 679.482093100789, 8.158715).
planeta('HD 131496 b', 712.274397186506, 883).
planeta('Kepler-154 c', 8.26723288680084, 62.303276).
planeta('Kepler-334 c', 3.19821898861189, 12.758005).
planeta('Kepler-911 b', 6.64150626255519, 20.310501).
planeta('Kepler-372 c', 4.93340160749914, 20.053763).
planeta('Kepler-127 b', 2.97992674145862, 14.435889).
planeta('HD 44219 b', 187.278126255764, 472.3).
planeta('75 Cet b', 877.078131278853, 691.9).
planeta('Kepler-27 b', 16.4063221701188, 15.3348).
planeta('Kepler-210 b', 8.21447535163677, 2.453234).
planeta('Kepler-40 b', 691.835619557581, 6.87349).
planeta('Kepler-171 c', 6.47996014735099, 11.463462).
planeta('Kepler-298 c', 4.51960455458575, 22.92881).
planeta('Kepler-331 c', 4.30587297387588, 17.28111).
planeta('Kepler-1538 b', 7.63382464835508, 175.138819).
planeta('Kepler-576 b', 10.1966967180122, 29.91136794).
planeta('Kepler-479 b', 5.01225187541604, 12.49341307).
planeta('Kepler-915 b', 3.76208898191367, 4.59489604).
planeta('HD 220074 b', 3555.82608841076, 672.1).
planeta('Kepler-133 b', 4.12570281312581, 8.129976).
planeta('Kepler-1185 b', 2.53240300401745, 104.3518976).
planeta('Kepler-788 b', 6.41922541861693, 8.39846269).
planeta('WASP-89 b', 1850.2989249823, 3.3564227).
planeta('HAT-P-39 b', 190.434361687779, 3.54387).
planeta('WASP-26 b', 323.365552578534, 2.7566).
planeta('Kepler-751 b', 6.08319805759902, 17.44490636).
planeta('WASP-71 b', 712.544541191864, 2.9036747).
planeta('HIP 2247 b', 1628.23419624833, 655.6).
planeta('GJ 876 d', 5.85395703281682, 1.93778).
planeta('Kepler-312 c', 9.40838472872925, 19.747412).
planeta('OGLE-TR-56 b', 441.76490287988, 1.211909).
planeta('Kepler-697 b', 17.7312354989862, 3.70987065).
planeta('Kepler-826 b', 2.06004190890718, 4.48758907).
planeta('Kepler-235 c', 2.20139714333443, 7.824904).
planeta('Kepler-1591 b', 2.12372279638203, 8.18504949).
planeta('Kepler-146 c', 9.28666101807962, 76.732171).
planeta('Kepler-1633 b', 3.74883603482728, 186.404271).
planeta('Kepler-903 b', 4.71143858003777, 10.3507721).
planeta('Kepler-372 d', 3.97467642330673, 30.092568).
planeta('Kepler-156 b', 5.55578161419674, 4.973456).
planeta('HD 38529 b', 255.290216677699, 14.310195).
planeta('Kepler-393 c', 2.5076514567971, 14.613612).
planeta('Kepler-136 c', 4.66935967849726, 16.399235).
planeta('Kepler-1353 b', 4.22517937039301, 24.7543966).
planeta('Kepler-436 b', 7.19387129939349, 64.00205).
planeta('Kepler-1595 b', 1.93640176490188, 4.56380468).
planeta('Kepler-1593 b', 9.54523650367895, 174.509835).
planeta('WASP-82 b', 397.270596115, 2.705785).
planeta('Kepler-1219 b', 5.01225187541604, 16.10467749).
planeta('Kepler-737 b', 4.59766028131043, 28.59915399).
planeta('Kepler-948 b', 4.32783409242912, 7.76846622).
planeta('Kepler-1021 b', 5.65795961151752, 13.47469571).
planeta('Kepler-866 b', 3.83989045545683, 2.61703254).
planeta('BD +20 2457 c', 2193.54072002566, 621.99).
planeta('Kepler-497 b', 38.9194879437174, 3.57320367).
planeta('Kepler-1344 b', 4.30190026791473, 4.7683049).
planeta('Kepler-1388 d', 7.79794507702211, 20.9568158).
planeta('Kepler-144 b', 2.5076514567971, 5.885273).
planeta('HD 22781 b', 4398.67538512835, 528.07).
planeta('Kepler-1253 b', 2.53240300401745, 68.8861915).
planeta('Kepler-208 d', 1.76335704956373, 11.131786).
planeta('Kepler-286 e', 4.14775927662211, 29.221289).
planeta('Kepler-351 b', 8.87416701272149, 37.054919).
planeta('HD 120084 b', 1422.92793034086, 2082).
planeta('HD 95127 b', 1600.58734092349, 482).
planeta('MOA-2009-BLG-266L b', 10.3925987943684, 0).
planeta('Kepler-755 c', 2.06004190890718, 2.85313364).
planeta('Kepler-1578 b', 1.07524941728009, 1.45088691).
planeta('Kepler-89 d', 52.0977481580442, 23.342989).
planeta('Kepler-387 b', 1.03012901205573, 6.791636).
planeta('HD 20868 b', 638.496480240797, 380.85).
planeta('Kepler-854 b', 317.816476892, 2.14463285).
planeta('HAT-P-9 b', 246.816593770804, 3.92289).
planeta('Kepler-410 A b', 0, 17.833648).
planeta('Kepler-33 e', 16.694772404546, 31.7844).
planeta('Kepler-1527 b', 23.9704814467392, 160.129918).
planeta('Kepler-1093 b', 4.56975599463931, 25.0824626).
planeta('Kepler-1024 b', 15.5266061620818, 66.4162133).
planeta('Kepler-1271 b', 3.58045686536989, 3.0255955).
planeta('Kepler-216 c', 8.76013446081264, 17.406669).
planeta('Kepler-365 c', 3.87014658405695, 17.784129).
planeta('Kepler-1488 b', 4.35392682518195, 39.8189932).
planeta('Kepler-19 b', 5.27391018084123, 9.2869944).
planeta('Kepler-130 b', 0.994775107166267, 8.457458).
planeta('Kepler-160 c', 12.7316962826458, 13.699087).
planeta('Kepler-598 b', 3.76208898191367, 3.70175428).
planeta('Kepler-207 c', 3.74562608841067, 3.071571).
planeta('Kepler-284 b', 5.36772960481975, 12.699149).
planeta('Kepler-326 b', 3.91187588747287, 2.248329).
planeta('Kepler-1391 b', 3.95640197588544, 54.4092333).
planeta('Kepler-1516 b', 4.1007224380421, 7.25931979).
planeta('Kepler-969 b', 4.88897086402964, 34.1731714).
planeta('HD 107148 b', 67.4314397186525, 48.056).
planeta('HD 1666 b', 2056.5014333546, 270).
planeta('Kepler-200 c', 3.76803215003155, 10.222157).
planeta('Kepler-95 b', 12.9994566644273, 11.5231).
planeta('Kepler-1444 b', 5.1721771265881, 33.42035034).
planeta('Kepler-280 c', 4.72068703951532, 4.807091).
planeta('KIC 11442793 e', 6.87373476222018, 91.93913).
planeta('Kepler-829 b', 4.98104229738525, 6.88337562).
planeta('Kepler-249 d', 3.72782836570471, 15.368459).
planeta('Kepler-812 b', 12.2637750837177, 10.11716531).
planeta('HD 95872 b', 1460.09656731338, 4375).
planeta('Kepler-1242 b', 5.4426071667755, 13.62798432).
planeta('51 Peg b', 146.558843603408, 4.230785).
planeta('WASP-60 b', 162.7674839249, 4.3050011).
planeta('Kepler-904 b', 4.15001577360805, 3.02166863).
planeta('Kepler-1113 b', 7.58005010046496, 42.3004954).
planeta('Kepler-99 b', 6.1497488278602, 4.60358).
planeta('Kepler-1394 b', 2.9086754655042, 3.93766373).
planeta('Kepler-752 b', 7.58005010046496, 18.82747265).
planeta('Kepler-125 c', 0.319157662424484, 5.774464).
planeta('HD 5319 c', 365.4889484258, 886).
planeta('Kepler-996 b', 4.65410448760645, 3.77059058).
planeta('Kepler-588 b', 6.77962930341245, 4.22162536).
planeta('Kepler-1454 b', 4.40671614199372, 47.0319479).
planeta('Kepler-319 c', 6.76253077695567, 6.941357).
planeta('Kepler-1143 c', 12.6319972538448, 210.630591).
planeta('Kepler-153 b', 8.11016798392081, 18.870227).
planeta('Kepler-1642 c', 6.87373476222018, 6.6513802).
planeta('Kepler-1336 b', 4.65410448760645, 23.198681).
planeta('55 Cnc f', 54.9431590756583, 261.2).
planeta('Kepler-539 b', 76.687844608132, 125.63243).
planeta('Kepler-929 b', 1.34189744139248, 0.92103214).
planeta('Kepler-238 d', 8.93178713998201, 13.233549).
planeta('HAT-P-54 b', 241.54052243792, 3.799847).
planeta('HIP 67851 b', 450.628804420398, 88.8).
planeta('Kepler-845 b', 4.79912414601227, 0.92785982).
planeta('Kepler-1245 c', 3.23368730743303, 2.93658468).
planeta('Kepler-153 c', 6.36348040857007, 46.90232).
planeta('HD 212301 b', 125.902997320766, 2.245715).
planeta('Kepler-574 b', 5.84620231078065, 7.65880414).
planeta('Kepler-865 b', 6.20647906898542, 14.16399294).
planeta('Kepler-295 c', 1.61496535833808, 21.526258).
planeta('GJ 504 b', 1271.265907568, 0).
planeta('HAT-P-15 b', 620.231567313814, 10.863502).
planeta('Kepler-24 e', 7.42222243804039, 18.998355).
planeta('HD 209458 b', 219.18086202266, 3.52474859).
planeta('Kepler-729 b', 12.4465513395783, 3.16635371).
planeta('HD 102272 b', 1305.90154721969, 127.58).
planeta('K2-3 d', 3.70396034829012, 44.5631).
planeta('HD 181433 b', 7.54277022772553, 9.3743).
planeta('Kepler-898 b', 3.67058961821646, 5.8706191).
planeta('HD 187123 b', 162.104200937626, 3.0965828).
planeta('Kepler-1481 b', 1.93640176490188, 5.94220998).
planeta('HD 108147 b', 81.9963332216591, 10.8985).
planeta('Kepler-82 c', 30.2580354989798, 51.538).
planeta('Kepler-1143 b', 3.93285177494774, 2.88890485).
planeta('Kepler-1617 b', 1.76010896516989, 27.4785572).
planeta('WASP-61 b', 653.08425653014, 3.8559).
planeta('Kepler-58 b', 7.4107174815769, 10.2184954).
planeta('eta Cet b', 809.955291359262, 407.5).
planeta('Kepler-606 b', 10.4243486604099, 24.31575992).
planeta('Kepler-686 b', 317.816476892, 1.59474546).
planeta('Kepler-487 b', 317.816476892, 15.3587684).
planeta('Kepler-957 b', 32.1159906228904, 5.90741354).
planeta('Kepler-1099 b', 7.63382464835508, 2.16845259).
planeta('Kepler-379 b', 3.91162163429136, 20.09838).
planeta('Kepler-376 b', 1.17984281982525, 4.920199).
planeta('Kepler-166 d', 4.05203295378224, 1.55400393).
planeta('HD 215497 c', 104.092523777575, 567.94).
planeta('Kepler-1345 b', 5.76989457467888, 44.6169557).
planeta('Kepler-1325 b', 7.79794507702211, 33.8786838).
planeta('Kepler-1624 b', 34.5886028131101, 3.29030452).
planeta('Kepler-1086 c', 8.19747217012305, 161.5163345).
planeta('Kepler-662 b', 5.1721771265881, 21.67697486).
planeta('Kepler-225 b', 1.76335704956373, 6.738975).
planeta('CoRoT-17 b', 781.831711319089, 3.7681).
planeta('HD 20794 d', 4.70152270595874, 90.309).
planeta('xi Aql b', 565.433650368095, 136.75).
planeta('Kepler-444 d', 0.108122754521043, 6.189392).
planeta('Kepler-1058 b', 7.16603057601775, 110.96546).
planeta('Kepler-892 b', 7.58005010046496, 13.7521072).
planeta('Kepler-444 e', 0.120076785666382, 7.743493).
planeta('HD 33564 b', 2900.98112859864, 388).
planeta('Kepler-1243 b', 4.1007224380421, 16.8320729).
planeta('Kepler-635 b', 6.82647545210634, 23.44971004).
planeta('Kepler-890 b', 93.6525703281501, 52.75875577).
planeta('HD 40979 b', 1278.33414601408, 264.15).
planeta('Kepler-959 b', 20.0898469189448, 14.80074836).
planeta('GJ 581 c', 5.33156208974944, 12.9182).
planeta('Kepler-945 b', 6.77962930341245, 31.0033814).
planeta('Kepler-1303 b', 3.15041303415779, 7.56127224).
planeta('HD 10180 c', 13.1910999999932, 5.75962).
planeta('WASP-31 b', 152.338654052165, 3.405909).
planeta('Kepler-1496 b', 5.30508797722433, 64.6588017).
planeta('bet UMi b', 1938.6805090412, 522.3).
planeta('HD 134987 c', 255.81874547877, 5000).
planeta('Kepler-1118 b', 7.21624557936668, 38.6715075).
planeta('Kepler-1286 b', 5.10740612859751, 11.25402929).
planeta('Kepler-102 d', 1.82740978231654, 10.3117).
planeta('Kepler-164 d', 6.06597240455147, 28.986769).
planeta('HD 40307 b', 4.10208904889273, 4.3115).
planeta('WASP-101 b', 158.908238446, 3.585722).
planeta('Kepler-1395 b', 0.412052240455247, 3.78470649).
planeta('Kepler-199 c', 10.0439223375702, 67.093408).
planeta('Kepler-344 b', 6.68024809108833, 21.963945).
planeta('Kepler-132 b', 1.81470030140563, 6.178196).
planeta('iota Dra b', 2960.56853985112, 511.098).
planeta('HD 108874 b', 410.046818486059, 394.48124).
planeta('Kepler-250 d', 5.18813151372808, 17.648312).
planeta('Kepler-256 d', 6.17539661754539, 5.839172).
planeta('Kepler-187 b', 3.05161660415114, 4.938864).
planeta('HD 4732 b', 755.535576021045, 360.2).
planeta('Kepler-991 b', 6.41922541861693, 82.5342519).
planeta('Kepler-374 d', 2.38204720696462, 5.028219).
planeta('Kepler-563 b', 9.07003730743003, 22.18432708).
planeta('Kepler-1119 b', 4.48731440053353, 8.3265153).
planeta('Kepler-383 c', 1.974511138646, 31.200751).
planeta('HD 23596 b', 2460.76399196123, 1561).
planeta('Kepler-1630 b', 5.20497578700335, 509.997402).
planeta('Kepler-295 b', 1.86700335900775, 12.645164).
planeta('Kepler-171 d', 4.42308369055365, 39.595519).
planeta('HD 25171 b', 303.897386470038, 1845).
planeta('HD 83443 b', 125.809241460083, 2.985698).
planeta('Kepler-304 e', 1.76010896516989, 1.49914695).
planeta('Kepler-287 b', 5.65312880106876, 20.342199).
planeta('Kepler-1065 b', 13.8029602813057, 3.60930891).
planeta('WASP-36 b', 721.217752846247, 1.5373653).
planeta('Kepler-1358 b', 1.39016422973807, 7.06317341).
planeta('Kepler-213 c', 5.68608636972246, 4.822962).
planeta('Kepler-268 b', 6.44083693904558, 25.934138).
planeta('Kepler-532 b', 6.50697454788681, 12.92491623).
planeta('Kepler-430 b', 10.5014191560562, 35.968).
planeta('HD 43691 b', 793.641771600396, 36.959999).
planeta('Kepler-204 b', 6.36348040857007, 14.400974).
planeta('Kepler-149 c', 3.80861731413066, 55.328328).
planeta('Kepler-1371 b', 0.302252050569168, 3.4462039).
planeta('30 Ari B b', 3139.36573342102, 335.1).
planeta('Kepler-1120 b', 2.8307754688532, 2.94902905).
planeta('Kepler-1597 b', 1.15983309444013, 2.94654179).
planeta('HAT-P-6 b', 336.748804420456, 3.852985).
planeta('Kepler-35 b', 40.3661885465298, 131.458).
planeta('Kepler-1581 b', 0.412052240455247, 6.28385491).
planeta('Kepler-397 b', 6.10217170126947, 22.250949).
planeta('Kepler-129 c', 6.44083693904558, 82.20017).
planeta('Kepler-398 c', 0.960292019423485, 11.419412).
planeta('Kepler-551 b', 7.21624557936668, 12.3764661).
planeta('Kepler-850 b', 4.17490080374869, 7.19303878).
planeta('Kepler-211 b', 2.08600115873972, 4.138575).
planeta('Kepler-242 b', 6.68024809108833, 8.20395).
planeta('Kepler-138 b', 0.06674146014732, 10.312364).
planeta('Kepler-389 b', 3.82819480910721, 3.244107).
planeta('PSR B1257+12 A', 0.0199991420964398, 25.262).
planeta('BD -08 2823 c', 104.275903884742, 237.6).
planeta('Kepler-611 b', 3.88610097119693, 2.4370333).
planeta('Kepler-951 b', 33.2032407903379, 71.52530845).
planeta('4 UMa b', 2266.80059611404, 269.29999).
planeta('Qatar-1 b', 346.353218352133, 1.420033).
planeta('Kepler-794 b', 4.98104229738525, 11.13125132).
planeta('HD 10697 b', 1981.60162424546, 1075.2).
planeta('Kepler-597 b', 5.76989457467888, 13.02365861).
planeta('Kepler-1433 b', 3.70396034829012, 4.13592271).
planeta('Kepler-194 b', 3.82819480910721, 2.092281).
planeta('Kepler-1121 b', 4.46023643670233, 13.15141081).
planeta('HD 33844 c', 562.112468184574, 916).
planeta('Kepler-221 d', 7.19377595445042, 10.04156).
planeta('Kepler-338 d', 8.53699551238677, 44.431014).
planeta('Kepler-1575 b', 2.39105412591973, 2.55314213).
planeta('Kepler-535 b', 5.76989457467888, 4.90332155).
planeta('Kepler-32 e', 3.73469320160558, 2.896).
planeta('HD 113337 b', 899.42062960436, 324).
planeta('Kepler-146 b', 13.5991445746749, 31.158799).
planeta('Kepler-11 f', 2.297911651037, 46.6888).
planeta('BD +20 2457 b', 3778.29762223516, 379.63).
planeta('Kepler-1152 b', 0.574389718686912, 1.64680191).
planeta('Kepler-176 c', 6.63953580039846, 12.759712).
planeta('mu Ara d', 10.9924138312067, 9.6386).
planeta('HD 3651 b', 72.7720277963457, 62.218).
planeta('KIC 11442793 d', 7.8535947421259, 56.73667).
planeta('Kepler-714 b', 212.154893168009, 8.09888799).
planeta('Kepler-1236 b', 5.07543379102217, 31.0571618).
planeta('Kepler-442 b', 2.57204107501542, 112.3053).
planeta('Kepler-1193 b', 2.46108180843812, 2.83265213).
planeta('Kepler-1262 b', 4.25057290689668, 8.67900242).
planeta('HD 99706 b', 445.861557267018, 868).
planeta('Kepler-251 b', 2.5076514567971, 4.790936).
planeta('HD 169830 b', 918.317997320358, 225.62).
planeta('Kepler-292 c', 3.50449872739271, 3.715335).
planeta('Kepler-1367 b', 0.685994152712306, 1.57409027).
planeta('Kepler-491 b', 151.557461151965, 4.22538451).
planeta('HD 175541 b', 167.689507702526, 297.3).
planeta('Kepler-324 b', 1.47501169457392, 4.385315).
planeta('Kepler-250 c', 5.49212297387527, 7.156804).
planeta('Kepler-462 b', 14.1116872069586, 84.6879808).
planeta('Kepler-568 b', 5.4426071667755, 11.02347475).
planeta('Kepler-1149 b', 3.23368730743303, 3.73089898).
planeta('HD 202206 c', 740.823851305714, 1383.4).
planeta('Kepler-309 b', 3.70783770930821, 5.923653).
planeta('Kepler-1116 b', 6.41922541861693, 41.6977827).
planeta('Kepler-1146 b', 1.93640176490188, 2.3522658).
planeta('Kepler-940 b', 10.6573717012671, 59.6225257).
planeta('Kepler-1103 b', 5.47772588747207, 19.79191978).
planeta('Kepler-1117 b', 1.34189744139248, 4.79028459).
planeta('Kepler-571 b', 6.82647545210634, 4.79859939).
planeta('Kepler-843 b', 6.59628097789346, 2.05387982).
planeta('Kepler-936 b', 3.31832183522937, 10.56134221).
planeta('Kepler-1339 b', 0.270978273610042, 1.34155513).
planeta('Kepler-1005 b', 3.76208898191367, 6.49801525).
planeta('HD 145457 b', 944.610954453634, 176.3).
planeta('Kepler-261 c', 4.69494390488707, 24.570858).
planeta('Kepler-465 b', 8.25649068988189, 9.94067247).
planeta('Kepler-336 c', 4.96086095110261, 9.600001).
planeta('Kepler-1584 b', 3.81694410582523, 13.3997099).
planeta('Kepler-1475 b', 8.13893037507954, 82.177374).
planeta('HD 206610 b', 626.457592096128, 610).
planeta('M 67 SAND 364 b', 598.365793703644, 121.71).
planeta('Kepler-711 b', 11.1399124581322, 23.58914398).
planeta('Kepler-365 b', 4.7990288010692, 10.664903).
planeta('Kepler-1610 b', 3.81694410582523, 8.70181574).
planeta('Kepler-838 b', 7.21624557936668, 15.74957994).
planeta('Kepler-802 b', 12.1733880776897, 40.0587473).
planeta('Kepler-1412 b', 0.476788278633378, 3.6146051).
planeta('Kepler-864 b', 5.88484879437072, 5.83376092).
planeta('HD 12661 c', 619.328968519441, 1707.8812).
planeta('Kepler-12 b', 137.282734092361, 4.4379637).
planeta('Kepler-229 d', 14.9096290354913, 41.194912).
planeta('Kepler-1411 b', 7.63382464835508, 86.1150888).
planeta('Kepler-1545 b', 7.06690361687513, 163.692349).
planeta('KIC 11442793 c', 1.70375056932263, 8.719375).
planeta('HAT-P-36 b', 584.537598794073, 1.327347).
planeta('WASP-35 b', 227.905559946299, 3.161575).
planeta('HD 69830 d', 17.9049222036077, 197).
planeta('CoRoT-22 b', 12.1723710649636, 9.75598).
planeta('HD 28254 b', 369.112056262369, 1116).
planeta('HD 81688 b', 855.148794373305, 184.02).
planeta('HD 210277 b', 404.500920964293, 442.19).
planeta('Kepler-1514 b', 317.816476892, 217.8317626).
planeta('Kepler-132 c', 2.20139714333443, 6.414914).
planeta('WTS-1 b', 1270.90041861957, 3.352059).
planeta('Kepler-322 b', 0.960292019423485, 1.653888).
planeta('HR 8799 c', 3019.256530474, 82145).
planeta('Kepler-717 b', 5.96312699262922, 4.40840023).
planeta('Kepler-51 b', 2.10076691225612, 45.1555023).
planeta('Kepler-252 b', 1.92026940053485, 6.668391).
planeta('XO-1 b', 291.902992632134, 3.941534).
planeta('Kepler-63 b', 39.8170016744604, 9.4341505).
planeta('Kepler-1423 b', 1.15983309444013, 23.955378).
planeta('Kepler-33 d', 30.2580354989798, 21.77596).
planeta('Kepler-287 c', 10.1099646014683, 44.851896).
planeta('Kepler-154 f', 3.76208898191367, 9.91935684).
planeta('Kepler-245 b', 6.51940117213329, 7.49019).
planeta('Kepler-537 b', 3.06848948090934, 3.24755522).
planeta('Kepler-989 b', 5.27143121232147, 7.96431535).
planeta('Kepler-100 c', 0, 12.8159).
planeta('GJ 15 A b', 5.3393168117856, 11.4433).
planeta('Kepler-180 c', 8.59216845277522, 41.885775).
planeta('Kepler-82 e', 6.13862525116898, 5.902206).
planeta('Kepler-20 d', 7.52795997990236, 77.61184).
planeta('Kepler-217 b', 5.33721922303811, 5.374943).
planeta('Kepler-1523 b', 3.74883603482728, 0.93875077).
planeta('Kepler-235 e', 5.30693131279031, 46.183669).
planeta('Kepler-227 c', 8.76013446081264, 54.418694).
planeta('Kepler-169 d', 2.0297921366366, 8.348125).
planeta('Kepler-1226 b', 3.31832183522937, 17.2923453).
planeta('Kepler-1623 b', 2.39105412591973, 4.36128348).
planeta('Kepler-254 b', 15.1062620897444, 5.826662).
planeta('Kepler-79 e', 4.0998325519068, 81.065298).
planeta('Kepler-241 b', 5.65312880106876, 12.718092).
planeta('Kepler-1525 b', 0.656713720696246, 2.41660118).
planeta('Kepler-749 b', 9.13627026121432, 17.31716585).
planeta('55 Cnc b', 254.720689551108, 14.651).
planeta('Kepler-176 e', 3.31832183522937, 51.16579).
planeta('Kepler-565 b', 13.0111205291293, 4.24374723).
planeta('Kepler-631 b', 8.02334052243392, 17.97979059).
planeta('Kepler-380 c', 2.14319859008597, 7.630004).
planeta('Kepler-384 b', 1.38624873074276, 22.597053).
planeta('Kepler-1592 b', 3.65949782317293, 3.05710069).
planeta('Kepler-193 c', 7.28413117883082, 50.697494).
planeta('Kepler-1097 b', 10.1220098459426, 187.747029).
planeta('Kepler-368 c', 15.2054843938301, 72.379334).
planeta('Kepler-102 f', 0.619974135967531, 27.4536).
planeta('Kepler-131 c', 16.7010651707885, 25.5169).
planeta('Kepler-74 b', 212.018549899422, 7.340718).
planeta('HD 207832 b', 179.304428667021, 161.97).
planeta('M 67 YBP 1514 b', 126.305988613465, 5.118).
planeta('WASP-55 b', 181.528190555834, 4.465633).
planeta('Kepler-1064 b', 3.68168141326, 16.54080322).
planeta('Kepler-280 b', 3.3491500334879, 2.139542).
planeta('HAT-P-56 b', 692.932086402859, 2.7908327).
planeta('Kepler-1277 b', 3.79412488278439, 40.8365012).
planeta('Kepler-1144 b', 4.68264440723135, 17.14647302).
planeta('Kepler-325 c', 6.40203154721707, 12.762172).
planeta('GJ 3293 b', 25.743134628252, 30.6).
planeta('Kepler-547 b', 16.4617175820411, 6.01038429).
planeta('HD 33283 b', 104.933783991909, 18.179001).
planeta('Kepler-1312 b', 4.95011875418366, 5.44832529).
planeta('Kepler-842 b', 3.79412488278439, 1.21956827).
planeta('OGLE-TR-111 b', 174.7990622906, 4.0144479).
planeta('MOA-2007-BLG-400L b', 263.78767582036, 0).
planeta('Kepler-704 b', 6.68714470863688, 3.76182115).
planeta('HD 10180 e', 25.3583542196789, 49.747).
planeta('Kepler-1532 b', 2.60502724715204, 1.09366356).
planeta('Kepler-647 b', 1.59458696583977, 16.2254649).
planeta('Kepler-765 b', 6.00282227059303, 27.6655226).
planeta('Kepler-1016 c', 13.3027807099731, 105.6551369).
planeta('Kepler-185 b', 1.61496535833808, 1.6329).
planeta('55 Cnc d', 1126.50368050846, 4909).
planeta('HD 155233 b', 633.735589416955, 885).
planeta('WASP-3 b', 639.395900870401, 1.846834).
planeta('HD 148156 b', 269.385059611382, 1027).
planeta('Kepler-172 d', 5.39849423978289, 14.627119).
planeta('Kepler-967 c', 13.1076413931614, 198.7112502).
planeta('Kepler-182 c', 11.3060669122514, 20.684342).
planeta('Kepler-1016 b', 5.1721771265881, 1.95452434).
planeta('Kepler-1266 b', 6.551437073004, 28.474748).
planeta('TrES-5 b', 565.109477561665, 1.4822446).
planeta('Kepler-1306 b', 4.46023643670233, 16.29595382).
planeta('Kepler-1483 b', 3.94928288680306, 9.5085156).
planeta('Kepler-1047 b', 4.91941768251589, 56.1886887).
planeta('Kepler-645 b', 4.95011875418366, 3.27582262).
planeta('Kepler-49 e', 3.70783770930821, 18.596108).
planeta('HD 222155 b', 644.001061620567, 3999).
planeta('Kepler-399 c', 3.19821898861189, 26.67569).
planeta('Kepler-761 b', 4.76966255860438, 10.12804789).
planeta('Kepler-1278 b', 0.95624621567265, 3.23941344).
planeta('Kepler-175 c', 9.10725361687408, 34.035257).
planeta('Kepler-391 c', 12.1570205291297, 20.485435).
planeta('HD 73526 b', 907.556731412795, 188.3).
planeta('Kepler-768 b', 4.19997652377547, 11.3910025).
planeta('Kepler-879 b', 6.50697454788681, 33.3855938).
planeta('Kepler-1428 b', 3.8629321500315, 10.67607169).
planeta('Kepler-200 b', 5.04451024782058, 8.594805).
planeta('Kepler-1036 b', 8.62112153382008, 122.8808058).
planeta('Kepler-1129 c', 7.21624557936668, 76.5369586).
planeta('HD 117207 b', 578.076389818859, 2597).
planeta('Kepler-122 d', 5.24708647019154, 21.587475).
planeta('Kepler-1140 b', 7.36949668452401, 24.0862707).
planeta('Kepler-1565 b', 1.70375056932263, 1.53818844).
planeta('Kepler-1645 b', 4.17490080374869, 16.1779561).
planeta('Kepler-769 b', 8.13893037507954, 7.42608998).
planeta('Kepler-1239 b', 8.02334052243392, 5.19104016).
planeta('HD 121504 b', 388.467079705092, 63.330002).
planeta('Kepler-1089 b', 4.27615713328648, 5.13248562).
planeta('Kepler-499 b', 5.1721771265881, 5.63252845).
planeta('Kepler-852 b', 6.41922541861693, 44.9309804).
planeta('Kepler-1354 b', 8.37602146684097, 76.613377).
planeta('Kepler-342 e', 0.600930572672163, 1.64422461).
planeta('Kepler-1366 b', 3.23368730743303, 2.16457097).
planeta('HD 156846 b', 3498.39665103638, 359.51001).
planeta('Kepler-18 b', 6.991962491624, 3.504725).
planeta('Kepler-1548 b', 6.82647545210634, 124.828679).
planeta('HR 8799 d', 3019.256530474, 41054).
planeta('HAT-P-23 b', 666.162404554246, 1.212884).
planeta('HD 224693 b', 227.109747488162, 26.73).
planeta('Kepler-1401 b', 3.95640197588544, 11.20066445).
planeta('Kepler-505 b', 6.64150626255519, 27.52197994).
planeta('Kepler-388 c', 0.541794460816868, 13.297004).
planeta('Kepler-862 b', 5.27143121232147, 3.14866453).
planeta('Kepler-246 c', 3.74562608841067, 11.187161).
planeta('Kepler-795 b', 3.95640197588544, 29.6193421).
planeta('Kepler-941 b', 9.00431286000877, 17.42395198).
planeta('HD 158038 b', 570.242213663471, 521).
planeta('Kepler-1502 b', 9.61534681848132, 41.7083629).
planeta('Kepler-888 b', 4.12528965170585, 70.6979061).
planeta('Kepler-822 b', 4.15001577360805, 3.22296927).
planeta('Kepler-240 b', 2.77116581044734, 4.144495).
planeta('Kepler-26 c', 12.6211597119828, 17.25204).
planeta('Kepler-143 c', 10.867829772265, 27.082511).
planeta('Kepler-1469 b', 7.52672049564248, 21.8635301).
planeta('Kepler-1334 b', 5.51313064299784, 15.64591713).
planeta('Kepler-508 b', 3.8629321500315, 25.30889748).
planeta('K2-21 c', 4.49519624916045, 15.5012).
planeta('Kepler-1091 b', 3.40432297387635, 1.43474156).
planeta('GJ 179 b', 261.958006362893, 2288).
planeta('Kepler-206 b', 1.76335704956373, 7.781987).
planeta('Kepler-22 b', 5.82700619557637, 289.8623).
planeta('Kepler-1101 b', 6.12394212993657, 81.3151059).
planeta('Kepler-1369 b', 7.01795987943377, 25.873148).
planeta('Kepler-68 c', 4.81237709309866, 9.605085).
planeta('Kepler-986 b', 5.76989457467888, 56.4349938).
planeta('Kepler-300 b', 3.93253395847085, 10.446347).
planeta('Kepler-937 b', 13.7014814802341, 67.668827).
planeta('Kepler-110 c', 5.27689765572401, 31.719775).
planeta('Kepler-42 d', 0.128622235097054, 1.865169).
planeta('Kepler-357 d', 11.3060669122514, 49.499875).
planeta('HD 143361 b', 964.569829202451, 1086).
planeta('Kepler-715 b', 14.0080472538441, 10.00652995).
planeta('HD 155358 b', 260.445517749364, 194.3).
planeta('Kepler-134 b', 4.69494390488707, 5.317429).
planeta('Kepler-369 b', 1.43018685867308, 2.732756).
planeta('HD 192310 b', 16.884254588069, 74.72).
planeta('Kepler-257 d', 25.8149293703819, 24.664551).
planeta('Kepler-342 b', 5.39849423978289, 15.170318).
planeta('Kepler-644 b', 9.40673208304942, 3.1739171).
planeta('Kepler-1108 b', 3.40432297387635, 4.51005748).
planeta('Kepler-119 b', 12.6479834226325, 2.422082).
planeta('WASP-64 b', 404.062334226182, 1.5732918).
planeta('Kepler-190 b', 3.70783770930821, 2.019999).
planeta('upsilon And b', 212.707258204847, 4.6171363).
planeta('Kepler-56 c', 62.5268958472552, 21.4050484).
planeta('Kepler-1267 b', 8.62112153382008, 13.0313945).
planeta('Kepler-1138 b', 4.00394732082848, 3.17060005).
planeta('Kepler-237 b', 3.05161660415114, 4.715106).
planeta('Kepler-132 e', 1.64858080709895, 110.2869374).
planeta('Kepler-223 e', 5.88926644339952, 19.721734).
planeta('HD 86081 b', 475.437558606587, 2.1375).
planeta('WASP-74 b', 301.9256530474, 2.13775).
planeta('HD 109246 b', 244.110068653592, 68.27).
planeta('WASP-68 b', 304.156406898705, 5.084298).
planeta('Kepler-81 d', 1.81470030140563, 20.837846).
planeta('Kepler-68 d', 257.339179504221, 580).
planeta('Kepler-403 c', 4.10377347622026, 54.280749).
planeta('Kepler-197 d', 1.86700335900775, 15.677563).
planeta('Kepler-1631 b', 2.60502724715204, 4.09513932).
planeta('Kepler-589 b', 5.47772588747207, 16.54964934).
planeta('Kepler-701 b', 7.68807592096055, 10.35533177).
planeta('Kepler-1300 b', 2.75420394507561, 22.2419092).
planeta('Kepler-1485 b', 3.49172250502165, 19.9157725).
planeta('Kepler-348 b', 3.91187588747287, 7.05677).
planeta('Kepler-341 d', 4.32901001339362, 27.666313).
planeta('Kepler-1632 b', 6.12394212993657, 448.303558).
planeta('HD 128311 c', 1032.42046885412, 923.8).
planeta('Kepler-445 d', 2.18865588077583, 8.15275).
planeta('Kepler-603 b', 6.82647545210634, 21.05358596).
planeta('Kepler-364 c', 5.10130405224118, 59.980627).
planeta('Kepler-299 e', 4.37572903549675, 38.285489).
planeta('Kepler-1075 b', 3.15041303415779, 1.52372816).
planeta('K2-25 b', 11.3057173141268, 3.484552).
planeta('Kepler-902 b', 6.41922541861693, 40.1099547).
planeta('CoRoT-23 b', 980.559176154888, 3.6313).
planeta('Kepler-1158 b', 5.69495344942775, 13.5396293).
planeta('Kepler-387 c', 0.611809430676176, 11.837549).
planeta('Kepler-821 b', 2.39105412591973, 1.92279873).
planeta('Kepler-684 b', 10.8157396517024, 6.77030201).
planeta('Kepler-54 d', 3.99666932350766, 20.995694).
planeta('Kepler-1082 b', 1.39016422973807, 1.5432066).
planeta('Kepler-1474 b', 5.13966450100205, 36.4333452).
planeta('WASP-39 b', 90.3673014065175, 4.055259).
planeta('Kepler-102 e', 8.92962598793915, 16.1457).
planeta('Kepler-1463 b', 4.35392682518195, 25.15864).
planeta('Kepler-219 b', 8.26723288680084, 4.585512).
planeta('Kepler-1377 b', 2.06004190890718, 0.74092842).
planeta('Kepler-549 c', 8.13893037507954, 117.040498).
planeta('GJ 876 b', 618.756898861035, 61.1166).
planeta('Kepler-984 b', 5.01225187541604, 43.0342272).
planeta('Kepler-385 b', 7.19377595445042, 10.043686).
planeta('Kepler-374 b', 1.03012901205573, 1.897806).
planeta('Kepler-296 e', 4.10377347622026, 34.142347).
planeta('HD 164509 b', 152.657741794965, 282.4).
planeta('HD 9446 b', 222.080301741346, 30.052).
planeta('HD 18742 b', 910.16282652331, 772).
planeta('Kepler-255 b', 3.68794239785477, 5.714606).
planeta('Kepler-636 b', 20.7300882116437, 16.08066115).
planeta('Kepler-197 b', 0.994775107166267, 5.599308).
planeta('Kepler-183 c', 5.46069092431066, 11.637071).
planeta('Kepler-745 b', 5.13966450100205, 9.93143556).
planeta('Kepler-517 b', 6.92140723375398, 60.92832271).
planeta('Kepler-232 b', 8.98985221031018, 4.431222).
planeta('Kepler-345 c', 1.76335704956373, 9.387427).
planeta('WASP-80 b', 175.359372739361, 3.0678504).
planeta('HD 167042 b', 520.208365706364, 420.77).
planeta('Kepler-1373 b', 1.54175633288601, 1.29123275).
planeta('Kepler-152 b', 7.4689732417912, 18.207973).
planeta('Kepler-743 b', 1.81766552913503, 3.17926292).
planeta('HD 69830 b', 10.0585101138595, 8.6669998).
planeta('Kepler-983 b', 5.76989457467888, 60.0855082).
planeta('Kepler-8 b', 186.158458807674, 3.52254).
planeta('Kepler-1014 b', 5.84620231078065, 16.57110363).
planeta('Kepler-336 d', 5.78645281312495, 20.678772).
planeta('Kepler-646 b', 4.68264440723135, 15.87364565).
planeta('Kepler-1272 b', 5.76989457467888, 51.1309704).
planeta('Kepler-353 c', 2.83966479571187, 8.410894).
planeta('HD 114762 b', 3697.82649028611, 83.9151).
planeta('Kepler-154 b', 5.42948134627986, 33.040532).
planeta('Kepler-804 b', 4.54207417950202, 14.37457351).
planeta('61 Vir c', 10.6070295713274, 38.021).
planeta('HD 45652 b', 148.880492967104, 43.6).
planeta('Kepler-1244 b', 2.60502724715204, 3.70428172).
planeta('Kepler-1386 b', 1.99760686202175, 6.73972381).
planeta('Kepler-978 b', 8.49755448760447, 49.6221509).
planeta('Kepler-1404 b', 4.71143858003777, 15.9314739).
planeta('Kepler-735 b', 8.25649068988189, 11.51516988).
planeta('Kepler-237 c', 4.9061329537818, 8.103636).
planeta('HAT-P-14 b', 710.647176824819, 4.627669).
planeta('Kepler-972 b', 22.7128498660298, 7.03932553).
planeta('Kepler-317 c', 4.03868466175278, 8.77501).
planeta('Kepler-1572 b', 0.747431255860299, 5.49548621).
planeta('Kepler-301 d', 4.10377347622026, 13.751243).
planeta('Kepler-1363 b', 2.06004190890718, 2.94194094).
planeta('Kepler-148 c', 12.6479834226325, 4.180043).
planeta('Kepler-49 d', 3.78827705960957, 2.576549).
planeta('Kepler-668 b', 7.06690361687513, 8.35390639).
planeta('Kepler-1013 b', 5.10740612859751, 18.93054959).
planeta('Kepler-796 b', 2.32231360013276, 6.40087618).
planeta('Kepler-1634 b', 9.68602920294211, 374.876239).
planeta('HIP 105854 b', 2606.0951105144, 184.2).
planeta('Kepler-169 b', 1.43018685867308, 3.250619).
planeta('WASP-66 b', 735.255706630566, 4.086052).
planeta('HD 73256 b', 594.005351640686, 2.5485799).
planeta('Kepler-1427 b', 1.29473983255124, 0.96897238).
planeta('Kepler-303 c', 1.47501169457392, 7.061149).
planeta('Kepler-1274 b', 3.15041303415779, 6.98152703).
planeta('Kepler-1032 b', 4.38021024782092, 3.29011795).
planeta('Kepler-168 b', 3.42622052913421, 4.425391).
planeta('Kepler-56 b', 14.7789111185456, 10.5034294).
planeta('6 Lyn b', 702.018459477201, 874.774).
planeta('Kepler-238 b', 4.06026440053375, 2.090876).
planeta('Kepler-151 c', 4.93340160749914, 24.674612).
planeta('Kepler-1487 b', 5.04368392498066, 7.31946363).
planeta('Kepler-150 b', 2.0297921366366, 3.428054).
planeta('HD 180314 b', 7190.94738780608, 396.03).
planeta('HD 17092 b', 1577.02442732672, 359.89999).
planeta('Kepler-780 b', 0.600930572672163, 0.67737516).
planeta('Kepler-353 b', 0.611809430676176, 5.795278).
planeta('Kepler-931 b', 2.53240300401745, 8.03755877).
planeta('Kepler-1246 b', 2.67895771600666, 11.32271513).
planeta('Kepler-1169 b', 0.747431255860299, 6.11009134).
planeta('Kepler-1105 b', 4.71143858003777, 4.42157218).
planeta('HIP 57274 b', 11.622802813122, 8.1352).
planeta('Kepler-93 b', 2.58988964835768, 4.72674).
planeta('Kepler-281 c', 29.8317482585245, 36.337373).
planeta('WASP-94 A b', 133.053868050836, 3.9501907).
planeta('Kepler-236 b', 3.72782836570471, 8.295611).
planeta('HD 202206 b', 5347.07153382177, 255.87).
planeta('WASP-5 b', 516.207056262293, 1.6284229).
planeta('Kepler-78 b', 1.8592263898182, 0.35500744).
planeta('Kepler-55 f', 3.76803215003155, 10.198545).
planeta('Kepler-314 c', 8.00738613529394, 5.960392).
planeta('CoRoT-2 b', 1040.93477227006, 1.7429935).
planeta('Kepler-447 b', 435.40857334204, 7.79430132).
planeta('Kepler-187 c', 6.9310370730038, 10.640263).
planeta('Kepler-257 c', 31.000709042181, 6.581484).
planeta('Kepler-424 c', 2236.48090421854, 223.3).
planeta('Kepler-522 b', 43.2440167447869, 38.58422849).
planeta('HD 108874 c', 326.832930341426, 1680.3835).
planeta('Kepler-1615 b', 4.8587782987249, 47.3126192).
planeta('GJ 832 c', 5.32310817146411, 35.68).
planeta('Kepler-894 b', 7.42145967849585, 9.803224).
planeta('Kepler-1609 b', 5.30508797722433, 114.34219).
planeta('Kepler-289 b', 5.99446369725077, 34.543901).
planeta('Kepler-1524 b', 12.1733880776897, 70.9674603).
planeta('Kepler-346 c', 8.93178713998201, 23.851549).
planeta('Kepler-1403 b', 5.07543379102217, 5.19492202).
planeta('Kepler-953 b', 18.5344530810353, 88.40655258).
planeta('Kepler-1479 b', 4.27615713328648, 14.53261362).
planeta('HD 200964 c', 300.566034159256, 825).
planeta('HD 10180 h', 65.4806821834894, 2248).
planeta('HD 33142 b', 448.556640991062, 326.6).
planeta('Kepler-402 e', 3.42622052913421, 11.242861).
planeta('HAT-P-20 b', 2316.73274279854, 2.875317).
planeta('HD 7924 b', 8.69695254520651, 5.39792).
planeta('Kepler-834 b', 4.74042344273032, 13.32388301).
planeta('Kepler-439 b', 5.36779316811512, 178.1396).
planeta('Kepler-1060 b', 5.80787364366748, 46.8779367).
planeta('Kepler-1150 b', 0.994841848626414, 2.78786839).
planeta('CoRoT-5 b', 147.001879772195, 4.0378962).
planeta('Kepler-1184 b', 6.96946108506005, 53.5991044).
planeta('WASP-47 b', 357.038208305242, 4.1591409).
planeta('Kepler-194 d', 5.88926644339952, 52.814973).
planeta('OGLE-2011-BLG-0251 b', 168.44273275276, 0).
planeta('Kepler-1566 b', 0.391988486269055, 0.53991524).
planeta('Kepler-36 b', 4.46147592096221, 13.83989).
planeta('Kepler-161 b', 5.01644705291102, 4.921355).
planeta('Kepler-943 b', 37.446408573323, 49.7701438).
planeta('Kepler-899 b', 6.96946108506005, 19.17891293).
planeta('HAT-P-35 b', 335.048486269084, 3.646706).
planeta('HD 99109 b', 160.242432015993, 439.3).
planeta('Kepler-1347 b', 1.03453077026069, 14.00947528).
planeta('Kepler-649 b', 5.4426071667755, 29.90722674).
planeta('Kepler-778 b', 3.95640197588544, 3.75574426).
planeta('Kepler-253 c', 6.84611651037826, 10.281951).
planeta('Kepler-744 b', 3.83989045545683, 12.06222443).
planeta('Kepler-5 b', 672.699889483914, 3.54846).
planeta('Kepler-161 c', 4.82553469524199, 7.06424).
planeta('HD 10647 b', 293.992000334745, 1003).
planeta('Kepler-675 b', 6.04283536503373, 2.33743801).
planeta('Kepler-758 d', 5.01225187541604, 20.4966197).
planeta('Kepler-331 b', 4.26001205626037, 8.457496).
planeta('Kepler-28 c', 11.0625877093044, 8.98597).
planeta('Kepler-600 b', 8.02334052243392, 23.67517607).
planeta('HATS-9 b', 266.012391158604, 1.9153073).
planeta('Kepler-782 b', 9.7572518754136, 158.6853308).
planeta('Kepler-121 b', 5.68608636972246, 3.177422).
planeta('Kepler-1407 b', 5.40777448090814, 20.0711504).
planeta('Kepler-816 b', 279.693754855851, 10.50682565).
planeta('Kepler-1205 b', 3.06848948090934, 1.07839035).
planeta('Kepler-1585 b', 4.19997652377547, 3.5827463).
planeta('Kepler-621 b', 5.54888499664819, 2.62811375).
planeta('Kepler-412 b', 298.871754520945, 1.720861232).
planeta('upsilon And c', 609.746801741147, 241.33335).
planeta('Kepler-170 c', 7.80636721365975, 16.665863).
planeta('Kepler-122 b', 5.68608636972246, 5.766193).
planeta('WASP-12 b', 432.430632953562, 1.09142245).
planeta('Kepler-148 b', 4.21469142665557, 1.729366).
planeta('HD 170469 b', 212.516250502235, 1145).
planeta('Kepler-285 b', 2.57196797722574, 2.633867).
planeta('HD 88133 b', 94.1080013395363, 3.41587).
planeta('HD 196885 b', 935.619926322359, 1333).
planeta('24 Sex b', 583.396637642031, 455.2).
planeta('HD 190228 b', 1888.44325853888, 1136.1).
planeta('Kepler-333 b', 2.44437101808314, 12.551158).
planeta('Kepler-510 b', 6.12394212993657, 19.55659418).
planeta('Kepler-370 c', 4.47101041526897, 19.02293).
planeta('OGLE-2006-BLG-109L b', 231.052578700484, 1788.5).
planeta('Kepler-762 b', 317.816476892, 3.7705521).
planeta('Kepler-111 c', 50.6125917615279, 224.784608).
planeta('Kepler-267 d', 5.46069092431066, 28.464515).
planeta('HD 181720 b', 118.224551239055, 956).
planeta('55 Cnc c', 52.2992438043937, 44.38).
planeta('Kepler-1125 b', 4.30190026791473, 17.6700642).
planeta('Kepler-995 b', 7.06690361687513, 28.26731672).
planeta('HD 156411 b', 232.867628600014, 842.2).
planeta('Kepler-1196 b', 5.3390307769564, 66.1849031).
planeta('HATS-3 b', 341.175987943562, 3.547851).
planeta('Kepler-101 b', 36.6757036168599, 3.487691).
planeta('Kepler-536 b', 9.13627026121432, 1.8270823).
planeta('Kepler-680 b', 5.96312699262922, 3.68992629).
planeta('91 Aqr b', 975.747434694743, 181.4).
planeta('Kepler-362 b', 0.587769792364065, 10.327186).
planeta('Kepler-301 b', 2.63732057936904, 2.508553).
planeta('Kepler-1126 b', 4.05203295378224, 108.593329).
planeta('Kepler-860 b', 9.97438409242622, 5.10137945).
planeta('Kepler-403 b', 2.0297921366366, 7.031462).
planeta('Kepler-676 b', 8.74675438713549, 11.59822172).
planeta('Kepler-1596 b', 4.46023643670233, 66.373379).
planeta('Kepler-404 c', 4.03868466175278, 14.751166).
planeta('Kepler-279 b', 12.8159176490222, 12.309681).
planeta('HD 27894 b', 196.386746483489, 17.990999).
planeta('Kepler-1256 b', 3.67058961821646, 12.4127754).
planeta('HD 156279 b', 3109.77066309284, 131.05).
planeta('Kepler-411 c', 10.1966967180122, 7.83442788).
planeta('Kepler-207 d', 10.4472632283938, 5.868075).
planeta('Kepler-502 b', 23.9704814467392, 4.28686431).
planeta('Kepler-297 c', 37.252222705942, 74.920137).
planeta('Kepler-436 c', 5.65795961151752, 16.79713874).
planeta('Kepler-345 b', 0.319157662424484, 7.415563).
planeta('Kepler-1449 b', 3.95640197588544, 13.2274528).
planeta('61 Vir d', 22.7534032484813, 123.01).
planeta('Kepler-141 c', 3.05161660415114, 7.010606).
planeta('Kepler-1399 b', 2.06004190890718, 1.63865306).
planeta('HD 179079 b', 26.6258381111718, 14.476).
planeta('Kepler-504 b', 3.7714327863343, 9.54927542).
planeta('Kepler-220 d', 0.862131222370622, 28.122397).
planeta('OGLE-05-390L b', 5.4982250502316, 3500).
planeta('WASP-4 b', 388.724511051374, 1.3382299).
planeta('Kepler-432 c', 751.324507702226, 406.2).
planeta('Kepler-141 b', 0.249948992967052, 3.107675).
planeta('Kepler-1641 b', 9.13627026121432, 19.672266).
planeta('Kepler-1026 b', 5.27143121232147, 36.5156053).
planeta('HD 4113 b', 523.853720696315, 526.62).
planeta('Kepler-488 b', 317.816476892, 3.12082923).
planeta('HD 330075 b', 198.229764232986, 3.38773).
planeta('Kepler-1029 b', 2.06004190890718, 4.41769648).
planeta('Kepler-754 b', 4.71143858003777, 14.5596237).
planeta('Kepler-524 c', 0.81284424313421, 1.88897906).
planeta('Kepler-256 e', 5.71926640990999, 10.681572).
planeta('HD 104985 b', 1562.83074346872, 199.505).
planeta('HATS-10 b', 167.171466845192, 3.312846).
planeta('Kepler-189 b', 1.81470030140563, 10.399931).
planeta('Kepler-691 b', 4.91941768251589, 8.114379).
planeta('Kepler-101 c', 2.5076514567971, 6.029809).
planeta('Kepler-653 c', 0.391988486269055, 0.90037648).
planeta('Kepler-1537 b', 1.64858080709895, 1.4444538).
planeta('Kepler-750 c', 3.83989045545683, 4.08899022).
planeta('HD 87883 b', 557.993566644053, 2754).
planeta('Kepler-520 c', 1.15983309444013, 5.21104261).
planeta('WASP-135 b', 603.984789015095, 1.4013794).
planeta('Kepler-81 c', 5.76989457467888, 12.04).
planeta('Kepler-156 c', 6.44083693904558, 15.906801).
planeta('Kepler-127 d', 6.80416473542852, 48.630408).
planeta('Kepler-657 b', 11.9946480910856, 24.54350418).
planeta('Kepler-1311 b', 1.99760686202175, 11.1726994).
planeta('HD 10180 g', 21.4148873744029, 602).
planeta('Kepler-1092 b', 4.88897086402964, 58.6017925).
planeta('Kepler-1214 b', 5.76989457467888, 18.82634264).
planeta('Kepler-275 c', 10.9396245143949, 16.088134).
planeta('Kepler-482 b', 5.76989457467888, 56.35418576).
planeta('Kepler-1495 b', 8.19747217012305, 85.273256).
planeta('Kepler-201 c', 7.7570738780938, 151.884058).
planeta('WASP-94 B b', 196.99504722026, 2.00839).
planeta('Kepler-208 c', 2.90930156396367, 7.466623).
planeta('Kepler-722 c', 7.63382464835508, 105.144749).
planeta('Kepler-1174 b', 3.7714327863343, 6.89225223).
planeta('Kepler-274 b', 3.6681424313444, 11.634788).
planeta('Kepler-581 b', 6.77962930341245, 40.6069821).
planeta('Kepler-693 b', 159.900461486857, 15.37563332).
planeta('Kepler-1102 b', 6.87373476222018, 51.3285623).
planeta('Kepler-769 c', 4.19997652377547, 15.9870174).
planeta('Kepler-652 b', 6.20647906898542, 4.18200253).
planeta('Kepler-420 b', 460.8338914934, 86.647661).
planeta('HD 66428 b', 873.874541191781, 1973).
planeta('HD 52265 b', 340.50539517732, 119.29).
planeta('HATS-14 b', 339.491560616034, 2.766741).
planeta('Kepler-75 b', 3173.33078030647, 8.884924).
planeta('Kepler-326 c', 2.97992674145862, 4.580358).
planeta('Kepler-554 b', 19.2522733757436, 1.90220856).
planeta('Kepler-1294 b', 9.68602920294211, 115.6862258).
planeta('Kepler-249 c', 3.82819480910721, 7.113702).
planeta('Kepler-1282 b', 3.68168141326, 2.13194651).
planeta('Kepler-740 b', 21.9307035163986, 3.58410122).
planeta('Kepler-79 c', 5.9113864701912, 27.402).
planeta('HD 16417 b', 21.2808323844499, 17.24).
planeta('Kepler-251 c', 7.37585301406185, 16.514043).
planeta('Kepler-15 b', 210.531486604044, 4.942782).
planeta('HD 205739 b', 472.618526456555, 279.8).
planeta('Kepler-851 b', 3.95640197588544, 8.50699658).
planeta('Kepler-1342 b', 3.90939691895311, 2.21571036).
planeta('Kepler-302 b', 17.0979226054835, 30.184104).
planeta('Kepler-781 b', 7.96629246483181, 13.2140732).
planeta('Kepler-317 b', 4.93340160749914, 5.524242).
planeta('Kepler-152 c', 5.85475157400905, 88.255055).
planeta('Kepler-343 b', 5.92406734761919, 8.96855).
planeta('Kepler-1161 b', 5.04368392498066, 10.71252541).
planeta('CoRoT-16 b', 170.979543871312, 5.35227).
planeta('HD 216770 b', 205.604059946311, 118.45).
planeta('HD 136418 b', 633.567146684202, 464.3).
planeta('Kepler-907 b', 1.76010896516989, 15.86621821).
planeta('Kepler-1402 b', 0.354028486269075, 2.03387914).
planeta('Kepler-59 b', 1.40220947421227, 11.8681707).
planeta('Kepler-98 b', 3.54985113864519, 1.54168).
planeta('Kepler-192 b', 7.23877876757833, 9.926746).
planeta('beta Pic b', 2860.348292028, 7154).
planeta('Kepler-1259 b', 3.23368730743303, 0.66308526).
planeta('Kepler-202 c', 4.32901001339362, 16.282493).
planeta('Kepler-1142 b', 3.49172250502165, 18.3027248).
planeta('GJ 163 d', 29.4329203616727, 603.95116).
planeta('Kepler-339 c', 1.52074230743391, 6.988055).
planeta('HD 188015 b', 467.053559946177, 461.2).
planeta('WASP-59 b', 273.034546215533, 7.919585).
planeta('WASP-54 b', 201.092019423875, 3.6936411).
planeta('Kepler-1542 b', 0.354028486269075, 3.95116882).
planeta('HAT-P-8 b', 411.051118553037, 3.076337).
planeta('Kepler-446 b', 3.65949782317293, 1.565409).
planeta('Kepler-1533 b', 11.5592395177436, 308.5471).
planeta('WASP-15 b', 172.509830207547, 3.7521).
planeta('Kepler-425 b', 317.816476892, 3.79701816).
planeta('HD 10180 d', 11.9673476557206, 16.3567).
planeta('Kepler-767 b', 38.7561302745949, 161.5280101).
planeta('HD 9446 c', 576.989457467888, 192.9).
planeta('Kepler-445 b', 3.81694410582523, 2.984151).
planeta('XO-4 b', 509.313616878506, 4.1250828).
planeta('WASP-48 b', 312.806417950275, 2.143634).
planeta('Kepler-566 b', 5.10740612859751, 18.42794624).
planeta('HD 37124 b', 214.326215338135, 154.378).
planeta('Kepler-89 b', 9.13239290019624, 3.743208).
planeta('WASP-32 b', 1097.61734092375, 2.718661).
planeta('Kepler-265 b', 4.3523059611498, 6.846262).
planeta('OGLE-TR-211 b', 240.675108171343, 3.67724).
planeta('gamma Cep b', 482.216584058694, 905.574).
planeta('Kepler-325 b', 8.05858636972124, 4.544439).
planeta('Kepler-11 g', 10.558912156726, 118.3807).
planeta('Kepler-256 b', 3.76803215003155, 1.620493).
planeta('Kepler-1182 b', 5.92381309443768, 11.17394617).
planeta('Kepler-617 b', 2.46108180843812, 1.68269615).
planeta('Kepler-1035 b', 1.59458696583977, 2.71407755).
planeta('HD 1605 c', 1113.29522772883, 2111).
planeta('GJ 86 b', 1271.59643670397, 15.76491).
planeta('Kepler-470 b', 317.816476892, 24.66919569).
planeta('Kepler-1637 b', 0.600930572672163, 6.10960324).
planeta('Kepler-1346 b', 3.74883603482728, 3.40165668).
planeta('HR 8799 e', 2224.715338244, 16422).
planeta('HD 8574 b', 573.986091761259, 227).
planeta('Kepler-269 c', 3.97467642330673, 8.127899).
planeta('MOA-2007-BLG-192L b', 3.17816476892, 0).
planeta('Kepler-250 b', 1.43018685867308, 4.148141).
planeta('HD 82886 b', 414.677404554375, 705).
planeta('HD 179949 b', 286.694298392351, 3.092514).
planeta('Kepler-1167 b', 4.02791068318614, 1.00393374).
planeta('HD 2952 b', 514.929434025187, 311.6).
planeta('Kepler-1063 b', 3.67058961821646, 14.07971466).
planeta('Kepler-169 e', 5.24708647019154, 13.767102).
planeta('MOA-2009-BLG-319L b', 49.897186872044, 0).
planeta('Kepler-1340 b', 3.68168141326, 0.66502692).
planeta('HIP 14810 c', 405.273215003141, 147.76916).
planeta('Kepler-358 c', 7.7570738780938, 83.488369).
planeta('HD 28678 b', 603.755961151733, 387.1).
planeta('WASP-56 b', 192.401327863263, 4.617101).
planeta('Kepler-18 c', 17.2892163429248, 7.64159).
planeta('Kepler-215 e', 4.10377347622026, 68.16101).
planeta('Kepler-540 b', 7.11626051573646, 172.7049784).
planeta('HATS-6 b', 101.383456128548, 3.3252725).
planeta('Kepler-230 c', 4.7990288010692, 91.773242).
planeta('Kepler-739 b', 10.5014191560562, 12.53248465).
planeta('Kepler-515 b', 3.40432297387635, 19.96371318).
planeta('Kepler-388 b', 0.43846914601451, 3.173315).
planeta('Kepler-107 e', 11.4561398526398, 14.749049).
planeta('Kepler-947 b', 5.47772588747207, 26.9644317).
planeta('Kepler-1560 b', 0.600930572672163, 3.03195744).
planeta('Kepler-1230 b', 7.11626051573646, 9.95661537).
planeta('Kepler-923 b', 2.8307754688532, 6.93366476).
planeta('CoRoT-8 b', 68.6731486938696, 6.21229).
planeta('Kepler-723 b', 317.816476892, 4.08227507).
planeta('Kepler-844 b', 3.95640197588544, 2.61302086).
planeta('Kepler-1283 b', 4.46023643670233, 12.9460978).
planeta('Kepler-1430 b', 1.64858080709895, 2.46050993).
planeta('Kepler-401 b', 4.01723204956257, 14.383035).
planeta('Kepler-760 c', 3.58045686536989, 2.46697439).
planeta('Kepler-1069 b', 3.79412488278439, 23.8990296).
planeta('Kepler-291 c', 4.39931101808213, 5.700786).
planeta('Kepler-1324 b', 3.85501851975689, 4.11584468).
planeta('CoRoT-20 b', 1347.54186202208, 9.24285).
planeta('Kepler-292 e', 6.9310370730038, 11.97901).
planeta('HD 96167 b', 217.567625585956, 498.9).
planeta('HD 43197 b', 189.694484929574, 327.8).
planeta('Kepler-1388 c', 5.4426071667755, 5.53608151).
planeta('Kepler-912 b', 7.52672049564248, 2.53475627).
planeta('Kepler-514 b', 4.02791068318614, 5.65179605).
planeta('Kepler-998 b', 5.62128359008418, 5.65377733).
planeta('Kepler-1129 b', 8.31601771600376, 24.3397804).
planeta('Kepler-1335 b', 3.31832183522937, 6.26406846).
planeta('HD 37605 c', 1069.61770930956, 2720).
planeta('Kepler-1601 b', 0.454433067648795, 2.20921951).
planeta('Kepler-659 b', 6.24827193569672, 17.671796).
planeta('Kepler-1332 b', 2.75420394507561, 11.87456832).
planeta('Kepler-81 b', 5.96312699262922, 5.955).
planeta('Kepler-814 b', 5.01225187541604, 6.1469851).
planeta('Kepler-1168 b', 6.24827193569672, 55.8226539).
planeta('Kepler-955 b', 9.27042059611044, 14.53244172).
planeta('Kepler-1328 b', 0.847092146684092, 4.52158888).
planeta('HD 183263 b', 1136.01910582661, 626.516).
planeta('Kepler-663 b', 6.64150626255519, 4.99678284).
planeta('Kepler-624 b', 5.58492538512774, 14.58649607).
planeta('Kepler-1526 b', 6.00282227059303, 3.908632).
planeta('Kepler-347 c', 4.10377347622026, 27.320871).
planeta('Kepler-699 b', 317.816476892, 27.80756293).
planeta('Kepler-32 c', 4.69411758204715, 8.7522).
planeta('Kepler-23 b', 4.44291543871171, 7.10664).
planeta('WASP-23 b', 277.207794373602, 2.9444256).
planeta('Kepler-594 b', 5.1721771265881, 13.64618192).
planeta('11 Com b', 5125.87126590493, 326.03).
planeta('HD 145377 b', 1837.61804755431, 103.95).
planeta('Kepler-1554 b', 8.02334052243392, 198.088774).
planeta('Kepler-650 b', 8.31601771600376, 3.03214559).
planeta('Kepler-289 d', 3.813797722704, 66.0634).
planeta('Kepler-1429 b', 2.2548506965829, 4.48487493).
planeta('Kepler-194 c', 6.59917310783318, 17.308032).
planeta('CoRoT-25 b', 85.81044876084, 4.86069).
planeta('Kepler-419 c', 2320.0602813116, 675.47).
planeta('Kepler-332 b', 1.61496535833808, 7.626324).
planeta('omicron CrB b', 469.529350301165, 187.83).
planeta('Kepler-229 c', 25.4937122571872, 16.068638).
planeta('Kepler-954 b', 5.62128359008418, 16.78176602).
planeta('Kepler-1408 b', 0.600930572672163, 2.99793191).
planeta('Kepler-779 b', 0.685994152712306, 7.09714223).
planeta('OGLE-TR-132 b', 375.02344273256, 1.689868).
planeta('beta Gem b', 876.607762893052, 589.64001).
planeta('Kepler-633 b', 3.83989045545683, 8.50340718).
planeta('Kepler-1159 b', 5.76989457467888, 22.70816791).
planeta('Kepler-1443 b', 0.847092146684092, 2.41811321).
planeta('Pr 201 b', 171.670159075598, 4.4264).
planeta('Kepler-541 b', 10.8157396517024, 5.08005848).
planeta('Kepler-937 c', 6.92140723375398, 153.343364).
planeta('Kepler-625 c', 1.11701368050847, 4.1653651).
planeta('WASP-52 b', 145.294569658331, 1.7497798).
planeta('Kepler-953 c', 1.70375056932263, 9.10967112).
planeta('Kepler-337 c', 4.82553469524199, 9.693201).
planeta('Kepler-213 b', 3.82902113194713, 2.46236).
planeta('Kepler-386 c', 3.7478825853966, 25.193458).
planeta('Kepler-1186 b', 5.3390307769564, 16.07677615).
planeta('Kepler-927 b', 4.02791068318614, 9.1149903).
planeta('Kepler-660 b', 6.50697454788681, 9.27358194).
planeta('Kepler-1385 b', 0.523914105826924, 2.88879862).
planeta('47 UMa b', 809.125790354574, 1078).
planeta('HD 240210 b', 2316.46259879318, 501.75).
planeta('Kepler-1255 b', 5.62128359008418, 36.2919336).
planeta('Kepler-804 c', 1.49008573007291, 9.65185017).
planeta('Kepler-906 b', 4.98104229738525, 41.6979976).
planeta('Kepler-304 b', 7.80636721365975, 3.295709).
planeta('Kepler-149 d', 16.0215735431934, 160.018032).
planeta('Kepler-1625 b', 39.2172819825652, 287.378949).
planeta('Kepler-77 b', 136.965235431946, 3.57878087).
planeta('Kepler-719 b', 127.190154052178, 5.00731778).
planeta('HD 109749 b', 87.2946517079257, 5.24).
planeta('Kepler-1455 b', 5.13966450100205, 49.276764).
planeta('Kepler-775 b', 1.70375056932263, 0.97486893).
planeta('HD 45364 c', 209.286281647582, 342.85).
planeta('Kepler-55 d', 3.76803215003155, 2.211099).
planeta('Kepler-685 b', 317.816476892, 1.6255222).
planeta('Kepler-500 b', 6.551437073004, 8.5083244).
planeta('Kepler-327 b', 1.34321320160681, 2.549575).
planeta('Kepler-1162 b', 5.27143121232147, 32.5637069).
planeta('Kepler-721 b', 6.82647545210634, 5.39202539).
planeta('WASP-50 b', 467.965693234857, 1.9550959).
planeta('Kepler-1540 b', 6.20647906898542, 125.4131177).
planeta('HD 11506 c', 114.41393168112, 223.6).
planeta('Kepler-607 b', 0.574389718686912, 0.6381632).
planeta('Kepler-1317 b', 3.70396034829012, 0.56887443).
planeta('Kepler-1507 b', 0.49994438713973, 16.0506213).
planeta('Kepler-1384 b', 4.54207417950202, 15.36262753).
planeta('Kepler-217 d', 2.46108180843812, 3.88689525).
planeta('Kepler-1007 b', 3.23368730743303, 5.18500207).
planeta('HD 159243 c', 603.8513060948, 248.4).
planeta('Kepler-1477 b', 1.64858080709895, 11.55530021).
planeta('Kepler-87 c', 6.39974326858345, 191.2318).
planeta('Kepler-105 c', 3.80861731413066, 7.125939).
planeta('WASP-98 b', 263.78767582036, 2.96264).
planeta('Kepler-1547 b', 0.62836449095748, 0.69297968).
planeta('Kepler-195 c', 3.68794239785477, 34.096863).
planeta('GJ 3470 b', 13.9868806764831, 3.336649).
planeta('K2-22 b', 0, 0.381078).
planeta('Kepler-696 b', 43.3549346952222, 4.19042557).
planeta('Kepler-1133 b', 4.62575525786768, 11.55562343).
planeta('Kepler-290 c', 7.06089688546188, 36.77031).
planeta('Kepler-801 b', 4.68264440723135, 11.41928253).
planeta('Kepler-334 d', 3.05161660415114, 25.09849).
planeta('Kepler-1620 b', 3.81694410582523, 101.951829).
planeta('Kepler-1644 b', 4.40671614199372, 21.0907758).
planeta('Kepler-273 c', 4.64399792364128, 8.014927).
planeta('Kepler-789 b', 5.01225187541604, 8.63847725).
planeta('Kepler-625 b', 4.68264440723135, 7.75192492).
planeta('eta Cet c', 1044.67229403831, 744.5).
planeta('Kepler-266 b', 6.17539661754539, 6.61833).
planeta('Kepler-641 b', 4.32783409242912, 9.48961571).
planeta('HD 96127 b', 1273.49380107101, 647.3).
planeta('Kepler-223 b', 3.97467642330673, 7.384108).
planeta('HD 17156 b', 1049.66836905505, 21.21663).
planeta('Kepler-1038 b', 12.0837002679107, 148.4603382).
planeta('Kepler-137 c', 4.39931101808213, 18.735753).
planeta('Kepler-990 b', 6.64150626255519, 9.91723428).
planeta('Kepler-116 c', 5.55578161419674, 13.07163).
planeta('Kepler-1137 b', 5.23806048224781, 23.9210791).
planeta('Kepler-117 b', 61.7352150033172, 18.795952).
planeta('Kepler-1264 b', 1.64858080709895, 0.96852602).
planeta('Kepler-513 b', 5.23806048224781, 28.86235584).
planeta('HAT-P-44 b', 111.871399865984, 4.301219).
planeta('Kepler-381 c', 1.38624873074276, 13.391635).
planeta('HD 16760 b', 4224.44839249615, 465.1).
planeta('HD 30562 b', 423.503168117666, 1157).
planeta('Kepler-354 d', 1.974511138646, 24.209842).
planeta('Kepler-332 c', 1.25978955458743, 15.995622).
planeta('Kepler-46 b', 100.050216007986, 33.60134).
planeta('Kepler-1215 b', 1.8764266175476, 4.76703963).
planeta('Kepler-920 b', 5.96312699262922, 6.53192704).
planeta('WASP-100 b', 645.16744809076, 2.849375).
planeta('Kepler-1086 b', 6.04283536503373, 18.78425728).
planeta('Kepler-1465 b', 4.15001577360805, 31.8277111).
planeta('epsilon CrB b', 1922.58946081616, 417.9).
planeta('omicron UMa b', 1301.79853650301, 1630).
planeta('Kepler-367 b', 2.3208166845266, 37.815724).
planeta('TrES-2 b', 381.605421968993, 2.47063).
planeta('Kepler-235 d', 4.82553469524199, 20.060548).
planeta('Kepler-282 c', 1.76335704956373, 13.638723).
planeta('Kepler-614 b', 5.84620231078065, 14.03491514).
planeta('Kepler-1018 b', 6.551437073004, 49.1013514).
planeta('Kepler-799 b', 42.8543737441173, 133.4605235).
planeta('Kepler-857 b', 41.5141416610637, 85.35129427).
planeta('Kepler-979 b', 7.16603057601775, 8.0880135).
planeta('HD 11755 b', 2081.92357334119, 433.7).
planeta('HD 102195 b', 143.906982920221, 4.113775).
planeta('Kepler-1320 b', 4.00394732082848, 0.86838653).
planeta('Kepler-432 b', 1719.38713998572, 52.501129).
planeta('Kepler-855 b', 118.272541527066, 7.8866311).
planeta('Kepler-1600 b', 9.27042059611044, 386.370548).
planeta('Kepler-324 c', 9.40838472872925, 51.805612).
planeta('Kepler-1189 b', 4.15001577360805, 3.78858982).
planeta('HD 75289 b', 146.208292029396, 3.509267).
planeta('Kepler-394 c', 3.91162163429136, 12.130686).
planeta('Kepler-1370 c', 2.12372279638203, 7.44142113).
planeta('Kepler-385 c', 8.76013446081264, 15.163161).
planeta('HD 185269 b', 303.264296048069, 6.8378503).
planeta('WASP-7 b', 292.162013060801, 4.954658).
planeta('WASP-41 b', 298.461771265754, 3.052404).
planeta('BD -10 3166 b', 136.630256865301, 3.48777).
planeta('HD 190360 b', 487.886430006447, 2915.0369).
planeta('HAT-P-13 c', 4535.11399865808, 446.27).
planeta('Kepler-304 c', 5.15895596114939, 5.315946).
planeta('Kepler-303 b', 0.611809430676176, 1.937055).
planeta('Kepler-1431 b', 3.49172250502165, 5.86601526).
planeta('Kepler-1163 b', 1.03453077026069, 6.11786898).
planeta('GJ 317 b', 400.591778298521, 692).
planeta('Kepler-526 b', 4.68264440723135, 5.45849832).
planeta('Kepler-591 b', 10.9765865706575, 81.1694299).
planeta('HD 37605 b', 890.439135967392, 55.01307).
planeta('WASP-44 b', 282.80454253167, 2.4238039).
planeta('Kepler-260 c', 4.08193948425778, 76.050178).
planeta('Kepler-602 b', 4.91941768251589, 15.28469497).
planeta('Kepler-286 c', 2.77116581044734, 3.468095).
planeta('Kepler-1023 b', 6.77962930341245, 62.1387714).
planeta('Kepler-1362 b', 6.64150626255519, 136.205626).
planeta('Kepler-708 b', 8.13893037507954, 3.16789194).
planeta('CoRoT-12 b', 292.130549229589, 2.828042).
planeta('CoRoT-1 b', 327.284229738613, 1.5089557).
planeta('HD 125612 c', 18.4545540187447, 4.15474).
planeta('Kepler-1202 b', 8.19747217012305, 28.6851324).
planeta('Kepler-753 b', 4.46023643670233, 5.74772501).
planeta('Kepler-267 b', 4.64399792364128, 3.353728).
planeta('Kepler-112 c', 5.88926644339952, 28.574263).
planeta('Kepler-1134 b', 6.82647545210634, 17.13263989).
planeta('GJ 581 b', 15.8596460482169, 5.36865).
planeta('HD 75784 b', 1779.7722705952, 5040).
planeta('Kepler-622 b', 5.04368392498066, 14.28226676).
planeta('Kepler-173 b', 2.26060317481464, 4.263742).
planeta('HD 102117 b', 53.9512538512784, 20.8133).
planeta('Kepler-446 c', 1.43955926657662, 3.036179).
planeta('Kepler-301 c', 2.63732057936904, 5.419026).
planeta('Kepler-1114 b', 2.60502724715204, 14.97435694).
planeta('Kepler-1154 b', 5.69495344942775, 5.1856142).
planeta('Kepler-1059 b', 4.05203295378224, 3.76419105).
planeta('HD 189733 b', 363.454922973691, 2.21857567).
planeta('HD 108863 b', 878.991386469742, 443.4).
planeta('Kepler-582 b', 13.3027807099731, 18.49235668).
planeta('Kepler-629 b', 2.8307754688532, 7.2385854).
planeta('HD 10442 b', 667.4146014732, 1043).
planeta('Kepler-404 b', 2.14319859008597, 11.829851).
planeta('Kepler-285 c', 1.38624873074276, 6.186676).
planeta('Kepler-174 c', 3.66413794373556, 44.000529).
planeta('Kepler-286 b', 1.974511138646, 1.796302).
planeta('Kepler-1213 b', 1.70375056932263, 5.34982412).
planeta('Kepler-867 b', 22.6002792699147, 150.242127).
planeta('Kepler-206 d', 1.71297042531727, 23.44281).
planeta('Kepler-209 c', 9.10725361687408, 41.749882).
planeta('Kepler-1438 b', 0.747431255860299, 2.31942009).
planeta('HD 1502 b', 923.956061620422, 431.8).
planeta('HD 142022 b', 1419.88324849224, 1928).
planeta('GJ 3293 c', 25.743134628252, 123.75).
planeta('Kepler-1061 b', 4.65410448760645, 2.75798267).
planeta('Kepler-134 c', 2.08600115873972, 10.105785).
planeta('Kepler-126 b', 3.91187588747287, 10.495711).
planeta('Kepler-329 c', 4.51960455458575, 18.684737).
planeta('Kepler-766 b', 10.9765865706575, 6.10027804).
planeta('Kepler-131 b', 16.7292872739365, 16.092).
planeta('WASP-72 b', 447.393432685637, 2.216726).
planeta('Kepler-887 b', 4.30190026791473, 20.42228798).
planeta('Kepler-819 b', 7.31794685197213, 33.1995648).
planeta('HD 212771 b', 858.155338244703, 373.3).
planeta('WASP-47 d', 12.8962298727328, 9.03081).
planeta('Kepler-135 b', 4.23728817816259, 6.00253).
planeta('HD 134987 b', 496.896527126335, 258.18).
planeta('Kepler-441 b', 3.87014658405695, 207.2482).
planeta('Kepler-149 b', 18.4929462491532, 29.198943).
planeta('Kepler-1228 b', 3.65949782317293, 0.57736958).
planeta('Kepler-289 c', 317.816476892, 125.866438).
planeta('Kepler-956 b', 8.55908375753076, 5.24867263).
planeta('HD 187123 c', 617.263161419643, 3805.6705).
planeta('HD 101930 b', 95.0865582718868, 70.459999).
planeta('Kepler-46 c', 119.498995311392, 57.011).
planeta('Kepler-1281 b', 3.8629321500315, 3.11602791).
planeta('Kepler-1640 b', 24.4364321835105, 7.5844126).
planeta('Kepler-174 d', 5.2174977561929, 247.35373).
planeta('Kepler-253 d', 9.5318564300018, 18.119869).
planeta('Kepler-914 b', 2.8307754688532, 4.40966548).
planeta('HD 131664 b', 5825.00395177195, 1951).
planeta('HIP 57050 b', 94.6250887474396, 41.397).
planeta('GJ 687 b', 18.433355659736, 38.14).
planeta('Kepler-9 d', 3.87014658405695, 1.592851).
planeta('Kepler-49 b', 7.13838054252815, 7.2037945).
planeta('WASP-73 b', 597.682488278327, 4.08722).
planeta('Kepler-1467 b', 10.3478820160697, 47.0569043).
planeta('Kepler-643 b', 158.285635967769, 16.33889626).
planeta('WASP-67 b', 133.263626925585, 4.61442).
planeta('HD 147018 c', 2095.53883121125, 1008).
planeta('Kepler-1055 b', 1.93640176490188, 2.29503623).
planeta('Kepler-1254 b', 3.68168141326, 9.99113313).
planeta('Kepler-1329 b', 5.1721771265881, 9.33646594).
planeta('Kepler-531 b', 7.42145967849585, 29.88485741).
planeta('Kepler-1261 b', 5.4426071667755, 48.4308991).
planeta('Kepler-32 b', 5.24803991962222, 5.90124).
planeta('Kepler-1521 b', 6.24827193569672, 47.14840805).
planeta('HD 92788 b', 1132.67249832494, 325.81).
planeta('Kepler-83 c', 5.76989457467888, 20.09).
planeta('Kepler-694 b', 7.52672049564248, 6.36584161).
planeta('CoRoT-26 b', 152.386326523699, 4.20474).
planeta('HAT-P-12 b', 66.9969845947412, 3.2130598).
planeta('Kepler-178 c', 7.90609802410846, 20.552802).
planeta('Kepler-994 b', 3.79412488278439, 1.15116651).
planeta('Kepler-603 c', 36.6563168117695, 127.9075774).
planeta('Kepler-82 d', 4.14775927662211, 2.382961).
planeta('Kepler-1417 b', 0.918772474882314, 20.3505213).
planeta('HD 114613 b', 160.827532149951, 3827).
planeta('Kepler-130 d', 3.87014658405695, 87.517905).
planeta('HD 154857 b', 714.441905558909, 408.6).
planeta('Kepler-106 e', 6.47910204286338, 43.8445).
planeta('Kepler-355 b', 3.42622052913421, 11.03189).
planeta('Kepler-220 c', 3.72782836570471, 9.034199).
planeta('Kepler-243 b', 6.06597240455147, 5.715442).
planeta('Kepler-712 b', 11.1399124581322, 21.02247699).
planeta('Kepler-297 b', 7.85604192899797, 38.871826).
planeta('Kepler-220 b', 0.43846914601451, 4.159807).
planeta('Kepler-483 b', 9.7572518754136, 30.229104).
planeta('Kepler-245 c', 5.18813151372808, 17.460812).
planeta('Kepler-25 c', 28.5727500669645, 12.7204).
planeta('Kepler-1435 b', 0.548726038177883, 4.45343281).
planeta('Kepler-1405 b', 15.9878849966428, 28.2274184).
planeta('HD 163607 b', 244.355422973752, 75.29).
planeta('Kepler-1254 c', 2.32231360013276, 3.60084276).
planeta('Kepler-1397 b', 4.02791068318614, 47.449955).
planeta('HATS-2 b', 428.782099798842, 1.354133).
planeta('HD 19994 b', 421.682079705075, 466.2).
planeta('Kepler-619 b', 9.47569825853498, 5.4042722).
planeta('WASP-29 b', 77.226543536464, 3.922727).
planeta('OGLE-TR-182 b', 325.602980575854, 3.9791).
planeta('Kepler-1289 b', 3.94928288680306, 7.99019627).
planeta('Kepler-1576 b', 1.07524941728009, 6.98471973).
planeta('HD 85512 b', 3.62161409912741, 58.43).
planeta('HD 106252 b', 2211.72617883342, 1531).
planeta('Kepler-222 d', 13.421199129263, 28.081912).
planeta('Kepler-1304 b', 5.51313064299784, 16.1288853).
planeta('Kepler-1546 b', 9.27042059611044, 19.5974971).
planeta('Kepler-394 b', 3.78827705960957, 8.005013).
planeta('Kepler-1250 b', 4.48731440053353, 2.60754383).
planeta('18 Del b', 3272.87407903382, 993.3).
planeta('Kepler-218 b', 3.58376215672957, 3.619337).
planeta('Kepler-54 c', 1.91437072672373, 12.0717249).
planeta('Kepler-33 b', 4.07857062960273, 5.66793).
planeta('Kepler-1437 b', 2.75420394507561, 10.9295461).
planeta('Kepler-391 b', 9.72051229068489, 7.416755).
planeta('Kepler-618 b', 6.64150626255519, 3.59576964).
planeta('Kepler-55 e', 3.68794239785477, 4.617534).
planeta('Kepler-34 b', 69.9208961821476, 288.822).
planeta('Kepler-255 d', 2.46108180843812, 1.04562266).
planeta('Kepler-1085 b', 49.0133392498074, 219.3217528).
planeta('Kepler-383 b', 2.44437101808314, 12.904532).
planeta('Kepler-444 f', 0.344980251171959, 9.740486).
planeta('HD 171028 b', 631.847759544216, 550).
planeta('Kepler-336 b', 0.994775107166267, 2.024823).
planeta('WASP-1 b', 291.755525786856, 2.5199449).
planeta('XO-5 b', 366.286667782799, 4.1877537).
planeta('HAT-P-3 b', 189.327089082287, 2.899703).
planeta('Kepler-1175 b', 8.49755448760447, 37.94563).
planeta('Kepler-1421 b', 0.716224855994274, 6.9131112).
planeta('Kepler-1626 b', 4.74042344273032, 4.13962966).
planeta('Kepler-252 c', 5.10130405224118, 10.848463).
planeta('Kepler-718 b', 317.816476892, 2.0523499).
planeta('Kepler-247 b', 3.87014658405695, 3.33616).
planeta('Kepler-251 e', 7.37585301406185, 99.640161).
planeta('Kepler-1583 b', 0.1586771858673, 9.32807355).
planeta('Kepler-282 b', 0.960292019423485, 9.220524).
planeta('Kepler-354 c', 2.38204720696462, 16.934402).
planeta('Kepler-1529 b', 4.95011875418366, 5.33905686).
planeta('Kepler-1446 b', 0.454433067648795, 0.68996783).
planeta('upsilon And d', 1308.07541192163, 1278.1218).
planeta('Kepler-1098 b', 2.32231360013276, 2.54307286).
planeta('Kepler-102 b', 0, 5.28696).


%%
%% orbita(A, B): A orbita alrededor de B
%%
orbita('Kepler-107 d', 'Kepler-107').
orbita('Kepler-1049 b', 'Kepler-1049').
orbita('Kepler-813 b', 'Kepler-813').
orbita('Kepler-427 b', 'Kepler-427').
orbita('Kepler-1056 b', 'Kepler-1056').
orbita('Kepler-1165 b', 'Kepler-1165').
orbita('Kepler-1104 b', 'Kepler-1104').
orbita('WASP-14 b', 'WASP-14').
orbita('Kepler-50 b', 'Kepler-50').
orbita('NN Ser d', 'NN Ser').
orbita('Kepler-1279 b', 'Kepler-1279').
orbita('Kepler-1599 b', 'Kepler-1599').
orbita('Kepler-20 b', 'Kepler-20').
orbita('HAT-P-27 b', 'HAT-P-27').
orbita('Kepler-181 b', 'Kepler-181').
orbita('HD 116029 b', 'HD 116029').
orbita('Kepler-207 b', 'Kepler-207').
orbita('Kepler-1156 b', 'Kepler-1156').
orbita('Kepler-1512 b', 'Kepler-1512').
orbita('Kepler-787 b', 'Kepler-787').
orbita('Kepler-528 b', 'Kepler-528').
orbita('HD 219828 b', 'HD 219828').
orbita('Kepler-480 b', 'Kepler-480').
orbita('Kepler-1567 b', 'Kepler-1567').
orbita('Kepler-1390 b', 'Kepler-1390').
orbita('Kepler-1642 b', 'Kepler-1642').
orbita('Kepler-11 c', 'Kepler-11').
orbita('Kepler-871 b', 'Kepler-871').
orbita('Kepler-1131 b', 'Kepler-1131').
orbita('Kepler-705 b', 'Kepler-705').
orbita('HD 1237 b', 'HD 1237').
orbita('WASP-21 b', 'WASP-21').
orbita('Kepler-284 c', 'Kepler-284').
orbita('Kepler-186 c', 'Kepler-186').
orbita('HD 4308 b', 'HD 4308').
orbita('Kepler-239 b', 'Kepler-239').
orbita('Kepler-651 b', 'Kepler-651').
orbita('Kepler-80 f', 'Kepler-80').
orbita('Kepler-1217 b', 'Kepler-1217').
orbita('Kepler-895 b', 'Kepler-895').
orbita('Kepler-628 b', 'Kepler-628').
orbita('Kepler-174 b', 'Kepler-174').
orbita('Kepler-440 b', 'Kepler-440').
orbita('Kepler-403 d', 'Kepler-403').
orbita('Kepler-224 d', 'Kepler-224').
orbita('Kepler-389 c', 'Kepler-389').
orbita('Kepler-674 b', 'Kepler-674').
orbita('Kepler-1047 c', 'Kepler-1047').
orbita('Kepler-1247 b', 'Kepler-1247').
orbita('Kepler-1210 b', 'Kepler-1210').
orbita('Kepler-254 c', 'Kepler-254').
orbita('Kepler-236 c', 'Kepler-236').
orbita('WASP-25 b', 'WASP-25').
orbita('Kepler-186 d', 'Kepler-186').
orbita('Kepler-1646 b', 'Kepler-1646').
orbita('HD 24040 b', 'HD 24040').
orbita('Kepler-359 c', 'Kepler-359').
orbita('Kepler-211 c', 'Kepler-211').
orbita('Kepler-967 b', 'Kepler-967').
orbita('Kepler-1574 b', 'Kepler-1574').
orbita('Kepler-1157 b', 'Kepler-1157').
orbita('Kepler-549 b', 'Kepler-549').
orbita('Kepler-1510 b', 'Kepler-1510').
orbita('Kepler-1002 b', 'Kepler-1002').
orbita('Kepler-294 c', 'Kepler-294').
orbita('Kepler-263 c', 'Kepler-263').
orbita('Kepler-349 b', 'Kepler-349').
orbita('Kepler-1563 b', 'Kepler-1563').
orbita('Kepler-1611 b', 'Kepler-1611').
orbita('Kepler-1284 b', 'Kepler-1284').
orbita('HD 200964 b', 'HD 200964').
orbita('Kepler-706 b', 'Kepler-706').
orbita('HD 147018 b', 'HD 147018').
orbita('HD 218566 b', 'HD 218566').
orbita('HD 45364 b', 'HD 45364').
orbita('Kepler-1177 b', 'Kepler-1177').
orbita('Kepler-1364 b', 'Kepler-1364').
orbita('Kepler-653 b', 'Kepler-653').
orbita('Kepler-553 b', 'Kepler-553').
orbita('Kepler-361 b', 'Kepler-361').
orbita('Kepler-318 c', 'Kepler-318').
orbita('Kepler-372 b', 'Kepler-372').
orbita('Kepler-197 e', 'Kepler-197').
orbita('HD 141937 b', 'HD 141937').
orbita('Kepler-405 c', 'Kepler-405').
orbita('Kepler-104 d', 'Kepler-104').
orbita('Kepler-702 b', 'Kepler-702').
orbita('Kepler-26 d', 'Kepler-26').
orbita('Kepler-159 b', 'Kepler-159').
orbita('HD 156668 b', 'HD 156668').
orbita('MOA-2009-BLG-387L b', 'MOA-2009-BLG-387L').
orbita('Kepler-1045 b', 'Kepler-1045').
orbita('Kepler-905 b', 'Kepler-905').
orbita('Kepler-763 b', 'Kepler-763').
orbita('Kepler-1376 b', 'Kepler-1376').
orbita('Kepler-32 f', 'Kepler-32').
orbita('WASP-103 b', 'WASP-103').
orbita('Kepler-990 c', 'Kepler-990').
orbita('Kepler-221 e', 'Kepler-221').
orbita('Kepler-1028 b', 'Kepler-1028').
orbita('Kepler-256 c', 'Kepler-256').
orbita('GJ 649 b', 'GJ 649').
orbita('Kepler-1333 b', 'Kepler-1333').
orbita('Kepler-276 b', 'Kepler-276').
orbita('Kepler-1042 b', 'Kepler-1042').
orbita('Kepler-264 c', 'Kepler-264').
orbita('HD 132406 b', 'HD 132406').
orbita('Kepler-143 b', 'Kepler-143').
orbita('Kepler-1225 b', 'Kepler-1225').
orbita('Kepler-189 c', 'Kepler-189').
orbita('HD 38529 c', 'HD 38529').
orbita('Kepler-62 b', 'Kepler-62').
orbita('Kepler-281 b', 'Kepler-281').
orbita('Kepler-1006 b', 'Kepler-1006').
orbita('Kepler-196 c', 'Kepler-196').
orbita('Kepler-238 c', 'Kepler-238').
orbita('Kepler-49 c', 'Kepler-49').
orbita('Kepler-55 c', 'Kepler-55').
orbita('Kepler-791 b', 'Kepler-791').
orbita('WASP-19 b', 'WASP-19').
orbita('Kepler-310 d', 'Kepler-310').
orbita('Kepler-619 c', 'Kepler-619').
orbita('Kepler-204 c', 'Kepler-204').
orbita('Kepler-26 b', 'Kepler-26').
orbita('Kepler-374 c', 'Kepler-374').
orbita('Kepler-395 b', 'Kepler-395').
orbita('HD 126614 A b', 'HD 126614 A').
orbita('Kepler-875 b', 'Kepler-875').
orbita('Kepler-1508 b', 'Kepler-1508').
orbita('Kepler-1568 b', 'Kepler-1568').
orbita('Kepler-80 e', 'Kepler-80').
orbita('Kepler-83 d', 'Kepler-83').
orbita('Kepler-519 b', 'Kepler-519').
orbita('Kepler-192 d', 'Kepler-192').
orbita('Kepler-167 b', 'Kepler-167').
orbita('Kepler-772 b', 'Kepler-772').
orbita('Kepler-295 d', 'Kepler-295').
orbita('Kepler-337 b', 'Kepler-337').
orbita('HD 177830 b', 'HD 177830').
orbita('Kepler-516 b', 'Kepler-516').
orbita('Kepler-1562 b', 'Kepler-1562').
orbita('Kepler-226 d', 'Kepler-226').
orbita('HD 38283 b', 'HD 38283').
orbita('Kepler-386 b', 'Kepler-386').
orbita('Kepler-922 b', 'Kepler-922').
orbita('HD 217786 b', 'HD 217786').
orbita('Kepler-363 c', 'Kepler-363').
orbita('Kepler-687 b', 'Kepler-687').
orbita('Kepler-1457 b', 'Kepler-1457').
orbita('Kepler-567 b', 'Kepler-567').
orbita('Kepler-1453 b', 'Kepler-1453').
orbita('Kepler-24 d', 'Kepler-24').
orbita('HD 32518 b', 'HD 32518').
orbita('Kepler-980 b', 'Kepler-980').
orbita('Kepler-472 b', 'Kepler-472').
orbita('Kepler-402 c', 'Kepler-402').
orbita('Kepler-435 b', 'Kepler-435').
orbita('WASP-18 b', 'WASP-18').
orbita('CoRoT-6 b', 'CoRoT-6').
orbita('Kepler-127 c', 'Kepler-127').
orbita('Kepler-839 b', 'Kepler-839').
orbita('Kepler-203 c', 'Kepler-203').
orbita('Kepler-1234 b', 'Kepler-1234').
orbita('Kepler-1127 b', 'Kepler-1127').
orbita('Kepler-732 c', 'Kepler-732').
orbita('HD 73267 b', 'HD 73267').
orbita('HD 147513 b', 'HD 147513').
orbita('Kepler-1528 b', 'Kepler-1528').
orbita('Kepler-893 b', 'Kepler-893').
orbita('Kepler-1387 b', 'Kepler-1387').
orbita('Kepler-1062 b', 'Kepler-1062').
orbita('HD 72659 b', 'HD 72659').
orbita('BD +14 4559 b', 'BD +14 4559').
orbita('HD 1605 b', 'HD 1605').
orbita('Kepler-79 b', 'Kepler-79').
orbita('Kepler-202 b', 'Kepler-202').
orbita('Kepler-709 b', 'Kepler-709').
orbita('HD 197037 b', 'HD 197037').
orbita('HD 70642 b', 'HD 70642').
orbita('KELT-2 A b', 'KELT-2 A').
orbita('Kepler-10 b', 'Kepler-10').
orbita('Kepler-208 e', 'Kepler-208').
orbita('Kepler-1365 b', 'Kepler-1365').
orbita('Kepler-270 c', 'Kepler-270').
orbita('Kepler-966 b', 'Kepler-966').
orbita('Kepler-1010 b', 'Kepler-1010').
orbita('Kepler-811 b', 'Kepler-811').
orbita('Kepler-225 c', 'Kepler-225').
orbita('Kepler-1305 b', 'Kepler-1305').
orbita('Kepler-150 d', 'Kepler-150').
orbita('Kepler-1322 b', 'Kepler-1322').
orbita('Kepler-405 b', 'Kepler-405').
orbita('Kepler-208 b', 'Kepler-208').
orbita('M 67 YBP 1194 b', 'M 67 YBP 1194').
orbita('Kepler-1084 b', 'Kepler-1084').
orbita('Kepler-616 b', 'Kepler-616').
orbita('Kepler-325 d', 'Kepler-325').
orbita('Kepler-1065 c', 'Kepler-1065').
orbita('Kepler-1464 c', 'Kepler-1464').
orbita('Kepler-340 c', 'Kepler-340').
orbita('Kepler-682 b', 'Kepler-682').
orbita('Kepler-507 b', 'Kepler-507').
orbita('HD 40307 c', 'HD 40307').
orbita('HD 142 b', 'HD 142').
orbita('Kepler-257 b', 'Kepler-257').
orbita('Kepler-976 b', 'Kepler-976').
orbita('WASP-10 b', 'WASP-10').
orbita('Kepler-982 b', 'Kepler-982').
orbita('GJ 328 b', 'GJ 328').
orbita('WASP-17 b', 'WASP-17').
orbita('HAT-P-17 b', 'HAT-P-17').
orbita('Kepler-162 b', 'Kepler-162').
orbita('Kepler-487 c', 'Kepler-487').
orbita('HD 67087 b', 'HD 67087').
orbita('Kepler-293 c', 'Kepler-293').
orbita('HD 102329 b', 'HD 102329').
orbita('Kepler-872 b', 'Kepler-872').
orbita('Kepler-1542 d', 'Kepler-1542').
orbita('HD 159868 b', 'HD 159868').
orbita('K2-21 b', 'K2-21').
orbita('Kepler-424 b', 'Kepler-424').
orbita('Kepler-262 c', 'Kepler-262').
orbita('WASP-117 b', 'WASP-117').
orbita('WASP-75 b', 'WASP-75').
orbita('Kepler-1293 b', 'Kepler-1293').
orbita('Kepler-222 b', 'Kepler-222').
orbita('Kepler-334 b', 'Kepler-334').
orbita('HD 114783 b', 'HD 114783').
orbita('GJ 581 e', 'GJ 581').
orbita('Kepler-1638 b', 'Kepler-1638').
orbita('Kepler-605 b', 'Kepler-605').
orbita('Kepler-327 c', 'Kepler-327').
orbita('Kepler-793 b', 'Kepler-793').
orbita('Kepler-1555 b', 'Kepler-1555').
orbita('Kepler-419 b', 'Kepler-419').
orbita('epsilon Ret b', 'epsilon Ret').
orbita('GJ 674 b', 'GJ 674').
orbita('Kepler-511 b', 'Kepler-511').
orbita('Kepler-1361 b', 'Kepler-1361').
orbita('HD 7924 c', 'HD 7924').
orbita('Kepler-57 c', 'Kepler-57').
orbita('HD 168443 c', 'HD 168443').
orbita('Kepler-172 c', 'Kepler-172').
orbita('Kepler-1350 b', 'Kepler-1350').
orbita('WASP-70 A b', 'WASP-70 A').
orbita('Kepler-933 b', 'Kepler-933').
orbita('Kepler-1406 b', 'Kepler-1406').
orbita('Kepler-1530 b', 'Kepler-1530').
orbita('Kepler-400 c', 'Kepler-400').
orbita('Kepler-220 e', 'Kepler-220').
orbita('Kepler-1111 b', 'Kepler-1111').
orbita('WASP-57 b', 'WASP-57').
orbita('HAT-P-37 b', 'HAT-P-37').
orbita('Kepler-198 c', 'Kepler-198').
orbita('Kepler-1166 b', 'Kepler-1166').
orbita('Kepler-458 c', 'Kepler-458').
orbita('Kepler-1605 b', 'Kepler-1605').
orbita('Kepler-1222 b', 'Kepler-1222').
orbita('Kepler-1635 b', 'Kepler-1635').
orbita('Kepler-615 b', 'Kepler-615').
orbita('Kepler-249 b', 'Kepler-249').
orbita('WASP-106 b', 'WASP-106').
orbita('HD 81040 b', 'HD 81040').
orbita('HD 208527 b', 'HD 208527').
orbita('Kepler-165 b', 'Kepler-165').
orbita('Kepler-28 b', 'Kepler-28').
orbita('Kepler-118 c', 'Kepler-118').
orbita('Kepler-1216 b', 'Kepler-1216').
orbita('HAT-P-32 b', 'HAT-P-32').
orbita('GJ 163 c', 'GJ 163').
orbita('HD 95089 b', 'HD 95089').
orbita('XO-3 b', 'XO-3').
orbita('Kepler-1380 b', 'Kepler-1380').
orbita('Kepler-478 b', 'Kepler-478').
orbita('HD 114729 b', 'HD 114729').
orbita('Kepler-122 e', 'Kepler-122').
orbita('Kepler-634 b', 'Kepler-634').
orbita('Kepler-881 b', 'Kepler-881').
orbita('Kepler-103 c', 'Kepler-103').
orbita('Kepler-997 b', 'Kepler-997').
orbita('Kepler-1503 b', 'Kepler-1503').
orbita('HD 100655 b', 'HD 100655').
orbita('Kepler-400 b', 'Kepler-400').
orbita('Kepler-106 c', 'Kepler-106').
orbita('Kepler-113 b', 'Kepler-113').
orbita('Kepler-1178 b', 'Kepler-1178').
orbita('Kepler-595 b', 'Kepler-595').
orbita('HD 142415 b', 'HD 142415').
orbita('Kepler-1359 b', 'Kepler-1359').
orbita('Kepler-785 b', 'Kepler-785').
orbita('CoRoT-9 b', 'CoRoT-9').
orbita('HD 114386 b', 'HD 114386').
orbita('HD 103197 b', 'HD 103197').
orbita('Kepler-698 b', 'Kepler-698').
orbita('Kepler-1022 b', 'Kepler-1022').
orbita('7 CMa b', '7 CMa').
orbita('K2-3 b', 'K2-3').
orbita('Kepler-368 b', 'Kepler-368').
orbita('Kepler-913 b', 'Kepler-913').
orbita('Kepler-1224 b', 'Kepler-1224').
orbita('Kepler-335 b', 'Kepler-335').
orbita('WASP-16 b', 'WASP-16').
orbita('Kepler-316 b', 'Kepler-316').
orbita('HD 152581 b', 'HD 152581').
orbita('KIC 11442793 h', 'KIC 11442793').
orbita('Kepler-103 b', 'Kepler-103').
orbita('Kepler-1426 b', 'Kepler-1426').
orbita('Kepler-993 b', 'Kepler-993').
orbita('Kepler-338 b', 'Kepler-338').
orbita('Kepler-1588 b', 'Kepler-1588').
orbita('Kepler-985 b', 'Kepler-985').
orbita('Kepler-974 b', 'Kepler-974').
orbita('Kepler-1248 b', 'Kepler-1248').
orbita('Kepler-129 b', 'Kepler-129').
orbita('Kepler-1331 b', 'Kepler-1331').
orbita('PH-1 b', 'PH-1').
orbita('Kepler-306 d', 'Kepler-306').
orbita('Kepler-37 d', 'Kepler-37').
orbita('Kepler-856 b', 'Kepler-856').
orbita('HD 13908 c', 'HD 13908').
orbita('HD 125595 b', 'HD 125595').
orbita('Kepler-1499 b', 'Kepler-1499').
orbita('WASP-79 b', 'WASP-79').
orbita('Kepler-1470 b', 'Kepler-1470').
orbita('Kepler-107 b', 'Kepler-107').
orbita('Kepler-1040 b', 'Kepler-1040').
orbita('Kepler-1542 c', 'Kepler-1542').
orbita('Kepler-109 c', 'Kepler-109').
orbita('HIP 57274 c', 'HIP 57274').
orbita('Kepler-30 d', 'Kepler-30').
orbita('Kepler-1349 b', 'Kepler-1349').
orbita('Kepler-877 b', 'Kepler-877').
orbita('Kepler-720 b', 'Kepler-720').
orbita('Kepler-932 b', 'Kepler-932').
orbita('Kepler-1628 b', 'Kepler-1628').
orbita('Kepler-158 c', 'Kepler-158').
orbita('Kepler-858 b', 'Kepler-858').
orbita('Kepler-777 b', 'Kepler-777').
orbita('HD 93083 b', 'HD 93083').
orbita('Kepler-970 b', 'Kepler-970').
orbita('HD 31253 b', 'HD 31253').
orbita('Kepler-1579 b', 'Kepler-1579').
orbita('Kepler-191 d', 'Kepler-191').
orbita('Kepler-357 c', 'Kepler-357').
orbita('Kepler-861 b', 'Kepler-861').
orbita('Kepler-1258 b', 'Kepler-1258').
orbita('TRAPPIST-1 c', 'TRAPPIST-1').
orbita('Kepler-552 b', 'Kepler-552').
orbita('HD 89744 b', 'HD 89744').
orbita('Kepler-1441 b', 'Kepler-1441').
orbita('Kepler-1341 b', 'Kepler-1341').
orbita('Kepler-738 b', 'Kepler-738').
orbita('HD 183263 c', 'HD 183263').
orbita('WASP-42 b', 'WASP-42').
orbita('Kepler-1612 b', 'Kepler-1612').
orbita('Kepler-885 b', 'Kepler-885').
orbita('Kepler-53 d', 'Kepler-53').
orbita('Kepler-48 b', 'Kepler-48').
orbita('Kepler-1614 b', 'Kepler-1614').
orbita('HD 192310 c', 'HD 192310').
orbita('HD 1690 b', 'HD 1690').
orbita('HAT-P-41 b', 'HAT-P-41').
orbita('Kepler-1493 b', 'Kepler-1493').
orbita('Kepler-42 c', 'Kepler-42').
orbita('Kepler-1492 b', 'Kepler-1492').
orbita('HD 28185 b', 'HD 28185').
orbita('HIP 97233 b', 'HIP 97233').
orbita('Kepler-1461 b', 'Kepler-1461').
orbita('Kepler-846 b', 'Kepler-846').
orbita('HD 23127 b', 'HD 23127').
orbita('HD 154672 b', 'HD 154672').
orbita('Kepler-275 d', 'Kepler-275').
orbita('Kepler-52 b', 'Kepler-52').
orbita('Kepler-1561 b', 'Kepler-1561').
orbita('OGLE-TR-10 b', 'OGLE-TR-10').
orbita('Kepler-370 b', 'Kepler-370').
orbita('Kepler-601 b', 'Kepler-601').
orbita('gamma Leo A b', 'gamma Leo A').
orbita('NN Ser c', 'NN Ser').
orbita('Kepler-1179 b', 'Kepler-1179').
orbita('Kepler-930 b', 'Kepler-930').
orbita('Kepler-1073 b', 'Kepler-1073').
orbita('HAT-P-2 b', 'HAT-P-2').
orbita('HAT-P-24 b', 'HAT-P-24').
orbita('HD 11506 b', 'HD 11506').
orbita('Kepler-758 c', 'Kepler-758').
orbita('tau Boo b', 'tau Boo').
orbita('Kepler-422 b', 'Kepler-422').
orbita('Kepler-124 c', 'Kepler-124').
orbita('Kepler-1081 b', 'Kepler-1081').
orbita('Kepler-1539 b', 'Kepler-1539').
orbita('Kepler-1458 b', 'Kepler-1458').
orbita('Kepler-184 c', 'Kepler-184').
orbita('XO-2S c', 'XO-2S').
orbita('HD 34445 b', 'HD 34445').
orbita('Kepler-318 b', 'Kepler-318').
orbita('OGLE-2007-BLG-368L b', 'OGLE-2007-BLG-368L').
orbita('KELT-7 b', 'KELT-7').
orbita('Kepler-1321 c', 'Kepler-1321').
orbita('Kepler-1311 c', 'Kepler-1311').
orbita('Kepler-1260 b', 'Kepler-1260').
orbita('HD 125612 b', 'HD 125612').
orbita('Kepler-20 f', 'Kepler-20').
orbita('Kepler-198 b', 'Kepler-198').
orbita('42 Dra b', '42 Dra').
orbita('Kepler-808 b', 'Kepler-808').
orbita('Kepler-216 b', 'Kepler-216').
orbita('Kepler-292 d', 'Kepler-292').
orbita('Kepler-53 b', 'Kepler-53').
orbita('Kepler-11 b', 'Kepler-11').
orbita('HD 153950 b', 'HD 153950').
orbita('Kepler-69 b', 'Kepler-69').
orbita('Kepler-27 c', 'Kepler-27').
orbita('Kepler-1434 b', 'Kepler-1434').
orbita('HD 16141 b', 'HD 16141').
orbita('Kepler-221 c', 'Kepler-221').
orbita('WASP-97 b', 'WASP-97').
orbita('Kepler-7 b', 'Kepler-7').
orbita('HIP 91258 b', 'HIP 91258').
orbita('Kepler-486 b', 'Kepler-486').
orbita('WASP-24 b', 'WASP-24').
orbita('HAT-P-29 b', 'HAT-P-29').
orbita('Kepler-38 b', 'Kepler-38').
orbita('Kepler-546 b', 'Kepler-546').
orbita('HD 204313 d', 'HD 204313').
orbita('PSR B1257+12 B', 'PSR B1257+12').
orbita('Kepler-147 b', 'Kepler-147').
orbita('HD 50554 b', 'HD 50554').
orbita('HD 11964 c', 'HD 11964').
orbita('Kepler-1044 b', 'Kepler-1044').
orbita('Kepler-79 d', 'Kepler-79').
orbita('Kepler-344 c', 'Kepler-344').
orbita('HD 13189 b', 'HD 13189').
orbita('HD 60532 b', 'HD 60532').
orbita('Kepler-1321 b', 'Kepler-1321').
orbita('Kepler-570 b', 'Kepler-570').
orbita('Kepler-1151 b', 'Kepler-1151').
orbita('HAT-P-11 b', 'HAT-P-11').
orbita('Kepler-406 b', 'Kepler-406').
orbita('Kepler-171 b', 'Kepler-171').
orbita('Kepler-627 b', 'Kepler-627').
orbita('Kepler-330 b', 'Kepler-330').
orbita('HD 104067 b', 'HD 104067').
orbita('Kepler-1452 b', 'Kepler-1452').
orbita('Kepler-229 b', 'Kepler-229').
orbita('Kepler-638 b', 'Kepler-638').
orbita('Kepler-144 c', 'Kepler-144').
orbita('Kepler-1372 b', 'Kepler-1372').
orbita('Kepler-758 e', 'Kepler-758').
orbita('HD 20794 b', 'HD 20794').
orbita('Kepler-94 b', 'Kepler-94').
orbita('Kepler-115 c', 'Kepler-115').
orbita('Kepler-320 c', 'Kepler-320').
orbita('Kepler-1478 b', 'Kepler-1478').
orbita('HD 195019 b', 'HD 195019').
orbita('Kepler-274 c', 'Kepler-274').
orbita('Kepler-1627 b', 'Kepler-1627').
orbita('GJ 832 b', 'GJ 832').
orbita('Kepler-889 b', 'Kepler-889').
orbita('Kepler-26 e', 'Kepler-26').
orbita('GJ 667 C b', 'GJ 667 C').
orbita('Kepler-254 d', 'Kepler-254').
orbita('Kepler-592 b', 'Kepler-592').
orbita('CoRoT-19 b', 'CoRoT-19').
orbita('Kepler-264 b', 'Kepler-264').
orbita('Kepler-604 b', 'Kepler-604').
orbita('Kepler-557 b', 'Kepler-557').
orbita('Kepler-1237 b', 'Kepler-1237').
orbita('Kepler-122 c', 'Kepler-122').
orbita('Kepler-142 b', 'Kepler-142').
orbita('alpha Ari b', 'alpha Ari').
orbita('Kepler-1450 b', 'Kepler-1450').
orbita('Kepler-148 d', 'Kepler-148').
orbita('Kepler-1148 b', 'Kepler-1148').
orbita('Kepler-240 c', 'Kepler-240').
orbita('Kepler-545 b', 'Kepler-545').
orbita('61 Vir b', '61 Vir').
orbita('Kepler-298 b', 'Kepler-298').
orbita('HD 210702 b', 'HD 210702').
orbita('Kepler-1299 b', 'Kepler-1299').
orbita('Kepler-1564 b', 'Kepler-1564').
orbita('Kepler-363 d', 'Kepler-363').
orbita('HAT-P-4 b', 'HAT-P-4').
orbita('Kepler-1414 b', 'Kepler-1414').
orbita('Kepler-485 b', 'Kepler-485').
orbita('HAT-P-21 b', 'HAT-P-21').
orbita('Kepler-398 d', 'Kepler-398').
orbita('Kepler-1180 b', 'Kepler-1180').
orbita('Kepler-1388 b', 'Kepler-1388').
orbita('Kepler-215 d', 'Kepler-215').
orbita('Kepler-579 b', 'Kepler-579').
orbita('Kepler-232 c', 'Kepler-232').
orbita('Kepler-1009 b', 'Kepler-1009').
orbita('Kepler-346 b', 'Kepler-346').
orbita('Kepler-330 c', 'Kepler-330').
orbita('Kepler-1233 b', 'Kepler-1233').
orbita('Kepler-1416 b', 'Kepler-1416').
orbita('alpha Cen B b', 'alpha Cen B').
orbita('Kepler-1183 b', 'Kepler-1183').
orbita('mu Ara b', 'mu Ara').
orbita('TYC 1422-614-1 c', 'TYC 1422-614-1').
orbita('Kepler-1109 b', 'Kepler-1109').
orbita('Kepler-830 b', 'Kepler-830').
orbita('WASP-45 b', 'WASP-45').
orbita('Kepler-916 b', 'Kepler-916').
orbita('Kepler-725 b', 'Kepler-725').
orbita('Kepler-428 b', 'Kepler-428').
orbita('Kepler-1171 b', 'Kepler-1171').
orbita('Kepler-1093 c', 'Kepler-1093').
orbita('HD 73526 c', 'HD 73526').
orbita('HD 108341 b', 'HD 108341').
orbita('Kepler-1330 b', 'Kepler-1330').
orbita('Kepler-382 c', 'Kepler-382').
orbita('Kepler-667 b', 'Kepler-667').
orbita('Kepler-495 b', 'Kepler-495').
orbita('Kepler-333 c', 'Kepler-333').
orbita('Kepler-17 b', 'Kepler-17').
orbita('14 Her b', '14 Her').
orbita('HAT-P-33 b', 'HAT-P-33').
orbita('Kepler-692 b', 'Kepler-692').
orbita('Kepler-1223 b', 'Kepler-1223').
orbita('Kepler-1232 b', 'Kepler-1232').
orbita('Kepler-805 b', 'Kepler-805').
orbita('Kepler-166 c', 'Kepler-166').
orbita('Kepler-1398 b', 'Kepler-1398').
orbita('Kepler-1629 b', 'Kepler-1629').
orbita('Kepler-835 b', 'Kepler-835').
orbita('Kepler-992 b', 'Kepler-992').
orbita('Kepler-1420 b', 'Kepler-1420').
orbita('OGLE-05-169L b', 'OGLE-05-169L').
orbita('HIP 79431 b', 'HIP 79431').
orbita('Kepler-562 b', 'Kepler-562').
orbita('Kepler-1476 b', 'Kepler-1476').
orbita('Kepler-870 b', 'Kepler-870').
orbita('Kepler-1155 b', 'Kepler-1155').
orbita('HD 171238 b', 'HD 171238').
orbita('Kepler-1292 b', 'Kepler-1292').
orbita('Kepler-1410 b', 'Kepler-1410').
orbita('Kepler-272 c', 'Kepler-272').
orbita('Kepler-157 c', 'Kepler-157').
orbita('HIP 5158 b', 'HIP 5158').
orbita('Kepler-661 b', 'Kepler-661').
orbita('Kepler-308 c', 'Kepler-308').
orbita('WASP-46 b', 'WASP-46').
orbita('Kepler-800 b', 'Kepler-800').
orbita('Kepler-157 b', 'Kepler-157').
orbita('Kepler-1268 b', 'Kepler-1268').
orbita('Kepler-1034 b', 'Kepler-1034').
orbita('Kepler-475 b', 'Kepler-475').
orbita('Kepler-1541 b', 'Kepler-1541').
orbita('GJ 849 b', 'GJ 849').
orbita('Kepler-587 b', 'Kepler-587').
orbita('WASP-84 b', 'WASP-84').
orbita('Kepler-52 d', 'Kepler-52').
orbita('Kepler-1190 b', 'Kepler-1190').
orbita('Kepler-197 c', 'Kepler-197').
orbita('Kepler-599 b', 'Kepler-599').
orbita('Kepler-163 b', 'Kepler-163').
orbita('Kepler-121 c', 'Kepler-121').
orbita('Kepler-191 b', 'Kepler-191').
orbita('Kepler-123 b', 'Kepler-123').
orbita('Kepler-1123 b', 'Kepler-1123').
orbita('Kepler-320 b', 'Kepler-320').
orbita('HAT-P-1 b', 'HAT-P-1').
orbita('Kepler-186 f', 'Kepler-186').
orbita('Kepler-1025 b', 'Kepler-1025').
orbita('Kepler-201 b', 'Kepler-201').
orbita('OGLE2-TR-L9 b', 'OGLE2-TR-L9').
orbita('Kepler-54 b', 'Kepler-54').
orbita('Kepler-973 b', 'Kepler-973').
orbita('Kepler-355 c', 'Kepler-355').
orbita('Kepler-1472 b', 'Kepler-1472').
orbita('Kepler-1135 b', 'Kepler-1135').
orbita('Kepler-375 c', 'Kepler-375').
orbita('Kepler-1209 b', 'Kepler-1209').
orbita('Kepler-1019 b', 'Kepler-1019').
orbita('Kepler-484 b', 'Kepler-484').
orbita('Kepler-137 b', 'Kepler-137').
orbita('Kepler-85 d', 'Kepler-85').
orbita('Kepler-1456 b', 'Kepler-1456').
orbita('Kepler-224 c', 'Kepler-224').
orbita('GJ 3341 b', 'GJ 3341').
orbita('Kepler-1290 b', 'Kepler-1290').
orbita('Kepler-962 b', 'Kepler-962').
orbita('WASP-22 b', 'WASP-22').
orbita('Kepler-468 b', 'Kepler-468').
orbita('Kepler-640 b', 'Kepler-640').
orbita('Kepler-503 b', 'Kepler-503').
orbita('WASP-2 b', 'WASP-2').
orbita('Kepler-392 b', 'Kepler-392').
orbita('Kepler-247 c', 'Kepler-247').
orbita('Kepler-1076 b', 'Kepler-1076').
orbita('HD 164922 b', 'HD 164922').
orbita('Kepler-271 b', 'Kepler-271').
orbita('Kepler-30 c', 'Kepler-30').
orbita('Kepler-190 c', 'Kepler-190').
orbita('tau Gru b', 'tau Gru').
orbita('WASP-34 b', 'WASP-34').
orbita('Kepler-397 c', 'Kepler-397').
orbita('HD 96063 b', 'HD 96063').
orbita('Kepler-490 b', 'Kepler-490').
orbita('Kepler-1466 b', 'Kepler-1466').
orbita('Kepler-630 b', 'Kepler-630').
orbita('Kepler-423 b', 'Kepler-423').
orbita('HAT-P-22 b', 'HAT-P-22').
orbita('51 Eri b', '51 Eri').
orbita('Kepler-1374 b', 'Kepler-1374').
orbita('Kepler-1041 b', 'Kepler-1041').
orbita('WASP-28 b', 'WASP-28').
orbita('Kepler-221 b', 'Kepler-221').
orbita('CoRoT-7 b', 'CoRoT-7').
orbita('Kepler-1418 b', 'Kepler-1418').
orbita('HD 5608 b', 'HD 5608').
orbita('Kepler-584 b', 'Kepler-584').
orbita('Kepler-733 b', 'Kepler-733').
orbita('Kepler-172 e', 'Kepler-172').
orbita('Kepler-1200 b', 'Kepler-1200').
orbita('Kepler-178 b', 'Kepler-178').
orbita('Kepler-1207 b', 'Kepler-1207').
orbita('Kepler-147 c', 'Kepler-147').
orbita('Kepler-1096 b', 'Kepler-1096').
orbita('Kepler-1491 b', 'Kepler-1491').
orbita('HATS-1 b', 'HATS-1').
orbita('Kepler-1559 b', 'Kepler-1559').
orbita('Kepler-378 c', 'Kepler-378').
orbita('HD 80606 b', 'HD 80606').
orbita('Kepler-471 b', 'Kepler-471').
orbita('Kepler-158 b', 'Kepler-158').
orbita('Kepler-1511 b', 'Kepler-1511').
orbita('Kepler-45 b', 'Kepler-45').
orbita('Kepler-68 b', 'Kepler-68').
orbita('Kepler-1195 b', 'Kepler-1195').
orbita('Kepler-665 b', 'Kepler-665').
orbita('Kepler-950 b', 'Kepler-950').
orbita('Kepler-308 b', 'Kepler-308').
orbita('WASP-78 b', 'WASP-78').
orbita('Kepler-108 c', 'Kepler-108').
orbita('HD 86264 b', 'HD 86264').
orbita('Kepler-942 b', 'Kepler-942').
orbita('Kepler-266 c', 'Kepler-266').
orbita('Kepler-1094 b', 'Kepler-1094').
orbita('Kepler-1194 b', 'Kepler-1194').
orbita('8 UMi b', '8 UMi').
orbita('Kepler-1291 b', 'Kepler-1291').
orbita('Kepler-239 c', 'Kepler-239').
orbita('Kepler-524 b', 'Kepler-524').
orbita('HD 82943 c', 'HD 82943').
orbita('Kepler-205 c', 'Kepler-205').
orbita('Kepler-319 b', 'Kepler-319').
orbita('Kepler-162 c', 'Kepler-162').
orbita('Kepler-126 c', 'Kepler-126').
orbita('HD 216536 b', 'HD 216536').
orbita('Kepler-728 b', 'Kepler-728').
orbita('Kepler-384 c', 'Kepler-384').
orbita('Kepler-669 b', 'Kepler-669').
orbita('Kepler-1046 b', 'Kepler-1046').
orbita('iota Hor b', 'iota Hor').
orbita('Kepler-716 b', 'Kepler-716').
orbita('HD 37124 d', 'HD 37124').
orbita('Kepler-853 b', 'Kepler-853').
orbita('Kepler-690 b', 'Kepler-690').
orbita('Kepler-1500 b', 'Kepler-1500').
orbita('Kepler-1316 b', 'Kepler-1316').
orbita('Kepler-921 b', 'Kepler-921').
orbita('HD 192263 b', 'HD 192263').
orbita('K2-3 c', 'K2-3').
orbita('HD 204313 b', 'HD 204313').
orbita('Kepler-1079 b', 'Kepler-1079').
orbita('Kepler-771 b', 'Kepler-771').
orbita('Kepler-212 c', 'Kepler-212').
orbita('Kepler-53 c', 'Kepler-53').
orbita('Kepler-707 b', 'Kepler-707').
orbita('Kepler-1211 b', 'Kepler-1211').
orbita('Kepler-321 b', 'Kepler-321').
orbita('Kepler-1442 b', 'Kepler-1442').
orbita('Kepler-402 d', 'Kepler-402').
orbita('Kepler-339 d', 'Kepler-339').
orbita('Kepler-407 b', 'Kepler-407').
orbita('Kepler-756 b', 'Kepler-756').
orbita('TrES-3 b', 'TrES-3').
orbita('Kepler-188 b', 'Kepler-188').
orbita('HIP 14810 b', 'HIP 14810').
orbita('Kepler-695 b', 'Kepler-695').
orbita('Kepler-10 c', 'Kepler-10').
orbita('HD 90156 b', 'HD 90156').
orbita('Kepler-786 b', 'Kepler-786').
orbita('Kepler-259 c', 'Kepler-259').
orbita('Kepler-444 b', 'Kepler-444').
orbita('Kepler-550 b', 'Kepler-550').
orbita('Kepler-304 d', 'Kepler-304').
orbita('Kepler-150 e', 'Kepler-150').
orbita('Kepler-218 c', 'Kepler-218').
orbita('Pr 211 b', 'Pr 211').
orbita('Kepler-203 b', 'Kepler-203').
orbita('Kepler-981 b', 'Kepler-981').
orbita('Kepler-6 b', 'Kepler-6').
orbita('Kepler-501 b', 'Kepler-501').
orbita('Kepler-244 d', 'Kepler-244').
orbita('24 Sex c', '24 Sex').
orbita('Kepler-358 b', 'Kepler-358').
orbita('Kepler-373 c', 'Kepler-373').
orbita('HATS-13 b', 'HATS-13').
orbita('Kepler-466 c', 'Kepler-466').
orbita('Kepler-1074 b', 'Kepler-1074').
orbita('Kepler-807 b', 'Kepler-807').
orbita('HD 60532 c', 'HD 60532').
orbita('Kepler-299 b', 'Kepler-299').
orbita('Kepler-939 b', 'Kepler-939').
orbita('Kepler-1389 b', 'Kepler-1389').
orbita('Kepler-140 c', 'Kepler-140').
orbita('Kepler-23 d', 'Kepler-23').
orbita('Kepler-1048 b', 'Kepler-1048').
orbita('Kepler-89 c', 'Kepler-89').
orbita('WASP-95 b', 'WASP-95').
orbita('Kepler-831 b', 'Kepler-831').
orbita('HD 68988 b', 'HD 68988').
orbita('Kepler-84 b', 'Kepler-84').
orbita('Kepler-637 b', 'Kepler-637').
orbita('HAT-P-26 b', 'HAT-P-26').
orbita('Kepler-1252 b', 'Kepler-1252').
orbita('Kepler-292 f', 'Kepler-292').
orbita('Kepler-847 b', 'Kepler-847').
orbita('Kepler-1355 b', 'Kepler-1355').
orbita('Kepler-20 e', 'Kepler-20').
orbita('Kepler-296 d', 'Kepler-296').
orbita('HD 149143 b', 'HD 149143').
orbita('Kepler-688 b', 'Kepler-688').
orbita('Kepler-62 d', 'Kepler-62').
orbita('Kepler-713 b', 'Kepler-713').
orbita('HD 79498 b', 'HD 79498').
orbita('Kepler-89 e', 'Kepler-89').
orbita('Kepler-722 b', 'Kepler-722').
orbita('Kepler-556 b', 'Kepler-556').
orbita('Kepler-883 b', 'Kepler-883').
orbita('Kepler-1181 b', 'Kepler-1181').
orbita('Kepler-1336 c', 'Kepler-1336').
orbita('Kepler-897 b', 'Kepler-897').
orbita('Kepler-298 d', 'Kepler-298').
orbita('Kepler-269 b', 'Kepler-269').
orbita('Kepler-248 b', 'Kepler-248').
orbita('HD 181433 c', 'HD 181433').
orbita('Kepler-1375 b', 'Kepler-1375').
orbita('Kepler-454 b', 'Kepler-454').
orbita('70 Vir b', '70 Vir').
orbita('HD 102365 b', 'HD 102365').
orbita('BD -08 2823 b', 'BD -08 2823').
orbita('Kepler-1276 b', 'Kepler-1276').
orbita('Kepler-797 b', 'Kepler-797').
orbita('Kepler-160 b', 'Kepler-160').
orbita('Kepler-1066 b', 'Kepler-1066').
orbita('Kepler-1318 b', 'Kepler-1318').
orbita('CoRoT-11 b', 'CoRoT-11').
orbita('Kepler-369 c', 'Kepler-369').
orbita('Kepler-142 d', 'Kepler-142').
orbita('Kepler-1415 b', 'Kepler-1415').
orbita('Kepler-398 b', 'Kepler-398').
orbita('Kepler-443 b', 'Kepler-443').
orbita('Kepler-746 b', 'Kepler-746').
orbita('Kepler-1348 b', 'Kepler-1348').
orbita('Kepler-299 d', 'Kepler-299').
orbita('GJ 436 b', 'GJ 436').
orbita('Kepler-1231 b', 'Kepler-1231').
orbita('Kepler-142 c', 'Kepler-142').
orbita('Kepler-401 d', 'Kepler-401').
orbita('Kepler-815 b', 'Kepler-815').
orbita('Kepler-578 b', 'Kepler-578').
orbita('Kepler-181 c', 'Kepler-181').
orbita('XO-2S b', 'XO-2S').
orbita('Kepler-364 b', 'Kepler-364').
orbita('Kepler-173 c', 'Kepler-173').
orbita('Kepler-609 b', 'Kepler-609').
orbita('Kepler-1606 b', 'Kepler-1606').
orbita('Kepler-290 b', 'Kepler-290').
orbita('Kepler-926 b', 'Kepler-926').
orbita('Kepler-544 b', 'Kepler-544').
orbita('WASP-37 b', 'WASP-37').
orbita('Kepler-223 c', 'Kepler-223').
orbita('HD 6718 b', 'HD 6718').
orbita('Kepler-224 e', 'Kepler-224').
orbita('Kepler-322 c', 'Kepler-322').
orbita('HD 33636 b', 'HD 33636').
orbita('Kepler-477 b', 'Kepler-477').
orbita('Kepler-1327 b', 'Kepler-1327').
orbita('Kepler-163 c', 'Kepler-163').
orbita('Kepler-1128 b', 'Kepler-1128').
orbita('HAT-P-40 b', 'HAT-P-40').
orbita('HD 240237 b', 'HD 240237').
orbita('Kepler-494 b', 'Kepler-494').
orbita('Kepler-169 f', 'Kepler-169').
orbita('Kepler-283 b', 'Kepler-283').
orbita('rho CrB b', 'rho CrB').
orbita('Kepler-214 b', 'Kepler-214').
orbita('Kepler-700 b', 'Kepler-700').
orbita('Kepler-1549 b', 'Kepler-1549').
orbita('Kepler-730 b', 'Kepler-730').
orbita('Kepler-1515 b', 'Kepler-1515').
orbita('Kepler-1424 b', 'Kepler-1424').
orbita('Kepler-314 b', 'Kepler-314').
orbita('Kepler-188 c', 'Kepler-188').
orbita('Kepler-731 b', 'Kepler-731').
orbita('Kepler-1338 b', 'Kepler-1338').
orbita('Kepler-233 b', 'Kepler-233').
orbita('Kepler-1530 c', 'Kepler-1530').
orbita('Kepler-118 b', 'Kepler-118').
orbita('Kepler-1440 b', 'Kepler-1440').
orbita('Kepler-1513 b', 'Kepler-1513').
orbita('Kepler-110 b', 'Kepler-110').
orbita('HD 11977 b', 'HD 11977').
orbita('Kepler-1192 b', 'Kepler-1192').
orbita('Kepler-1382 b', 'Kepler-1382').
orbita('HD 73534 b', 'HD 73534').
orbita('Kepler-689 b', 'Kepler-689').
orbita('Kepler-1643 b', 'Kepler-1643').
orbita('Kepler-195 b', 'Kepler-195').
orbita('Kepler-498 b', 'Kepler-498').
orbita('Kepler-50 c', 'Kepler-50').
orbita('Kepler-863 b', 'Kepler-863').
orbita('Kepler-1464 b', 'Kepler-1464').
orbita('HD 164604 b', 'HD 164604').
orbita('Kepler-1356 b', 'Kepler-1356').
orbita('Kepler-359 b', 'Kepler-359').
orbita('TRAPPIST-1 b', 'TRAPPIST-1').
orbita('Kepler-1201 b', 'Kepler-1201').
orbita('Kepler-1594 b', 'Kepler-1594').
orbita('Kepler-642 b', 'Kepler-642').
orbita('Kepler-359 d', 'Kepler-359').
orbita('Kepler-115 b', 'Kepler-115').
orbita('OGLE-05-071L b', 'OGLE-05-071L').
orbita('OGLE235-MOA53 b', 'OGLE235-MOA53').
orbita('HD 37124 c', 'HD 37124').
orbita('HD 217107 c', 'HD 217107').
orbita('Kepler-1323 b', 'Kepler-1323').
orbita('HD 74156 b', 'HD 74156').
orbita('Kepler-928 b', 'Kepler-928').
orbita('Kepler-180 b', 'Kepler-180').
orbita('HD 103774 b', 'HD 103774').
orbita('Kepler-43 b', 'Kepler-43').
orbita('Kepler-76 b', 'Kepler-76').
orbita('Kepler-310 b', 'Kepler-310').
orbita('Kepler-222 c', 'Kepler-222').
orbita('Kepler-1154 c', 'Kepler-1154').
orbita('Kepler-538 b', 'Kepler-538').
orbita('KELT-6 b', 'KELT-6').
orbita('WASP-13 b', 'WASP-13').
orbita('Kepler-683 b', 'Kepler-683').
orbita('Kepler-84 c', 'Kepler-84').
orbita('Kepler-918 b', 'Kepler-918').
orbita('Kepler-569 b', 'Kepler-569').
orbita('HD 13931 b', 'HD 13931').
orbita('Kepler-58 d', 'Kepler-58').
orbita('HAT-P-18 b', 'HAT-P-18').
orbita('Kepler-672 b', 'Kepler-672').
orbita('Kepler-357 b', 'Kepler-357').
orbita('Kepler-1518 b', 'Kepler-1518').
orbita('Kepler-971 b', 'Kepler-971').
orbita('Kepler-406 c', 'Kepler-406').
orbita('HD 155358 c', 'HD 155358').
orbita('WASP-43 b', 'WASP-43').
orbita('Kepler-1570 b', 'Kepler-1570').
orbita('Kepler-159 c', 'Kepler-159').
orbita('Kepler-39 b', 'Kepler-39').
orbita('Kepler-920 c', 'Kepler-920').
orbita('14 And b', '14 And').
orbita('Kepler-1130 b', 'Kepler-1130').
orbita('Kepler-520 b', 'Kepler-520').
orbita('Kepler-1191 b', 'Kepler-1191').
orbita('Kepler-1012 b', 'Kepler-1012').
orbita('Kepler-1145 b', 'Kepler-1145').
orbita('Kepler-891 b', 'Kepler-891').
orbita('Kepler-727 b', 'Kepler-727').
orbita('Kepler-215 b', 'Kepler-215').
orbita('Kepler-294 b', 'Kepler-294').
orbita('WASP-88 b', 'WASP-88').
orbita('Kepler-29 b', 'Kepler-29').
orbita('Kepler-792 b', 'Kepler-792').
orbita('Kepler-975 b', 'Kepler-975').
orbita('Kepler-24 b', 'Kepler-24').
orbita('Kepler-542 b', 'Kepler-542').
orbita('Kepler-306 b', 'Kepler-306').
orbita('Kepler-656 b', 'Kepler-656').
orbita('Kepler-83 b', 'Kepler-83').
orbita('Kepler-770 b', 'Kepler-770').
orbita('Kepler-489 b', 'Kepler-489').
orbita('81 Cet b', '81 Cet').
orbita('Kepler-1204 b', 'Kepler-1204').
orbita('Kepler-1218 b', 'Kepler-1218').
orbita('Kepler-1043 b', 'Kepler-1043').
orbita('Kepler-1396 b', 'Kepler-1396').
orbita('CoRoT-3 b', 'CoRoT-3').
orbita('Kepler-377 b', 'Kepler-377').
orbita('Kepler-648 b', 'Kepler-648').
orbita('Kepler-910 b', 'Kepler-910').
orbita('Kepler-126 d', 'Kepler-126').
orbita('Kepler-1506 b', 'Kepler-1506').
orbita('HAT-P-38 b', 'HAT-P-38').
orbita('Kepler-1602 b', 'Kepler-1602').
orbita('Kepler-18 d', 'Kepler-18').
orbita('Kepler-1077 b', 'Kepler-1077').
orbita('Kepler-380 b', 'Kepler-380').
orbita('Kepler-1580 b', 'Kepler-1580').
orbita('HD 32963 b', 'HD 32963').
orbita('Kepler-132 d', 'Kepler-132').
orbita('Kepler-228 b', 'Kepler-228').
orbita('mu Ara e', 'mu Ara').
orbita('Kepler-97 b', 'Kepler-97').
orbita('WASP-96 b', 'WASP-96').
orbita('Kepler-1229 b', 'Kepler-1229').
orbita('Kepler-518 b', 'Kepler-518').
orbita('Kepler-139 b', 'Kepler-139').
orbita('Kepler-952 b', 'Kepler-952').
orbita('Kepler-375 b', 'Kepler-375').
orbita('Kepler-1285 b', 'Kepler-1285').
orbita('HD 136118 b', 'HD 136118').
orbita('Kepler-182 b', 'Kepler-182').
orbita('Kepler-1313 b', 'Kepler-1313').
orbita('HD 6434 b', 'HD 6434').
orbita('HD 5319 b', 'HD 5319').
orbita('Kepler-306 e', 'Kepler-306').
orbita('Kepler-1519 b', 'Kepler-1519').
orbita('Kepler-253 b', 'Kepler-253').
orbita('Kepler-259 b', 'Kepler-259').
orbita('Kepler-1586 b', 'Kepler-1586').
orbita('Kepler-1172 b', 'Kepler-1172').
orbita('Kepler-1501 b', 'Kepler-1501').
orbita('HD 231701 b', 'HD 231701').
orbita('Kepler-666 b', 'Kepler-666').
orbita('PH-2 b', 'PH-2').
orbita('Kepler-1027 b', 'Kepler-1027').
orbita('CoRoT-18 b', 'CoRoT-18').
orbita('Kepler-703 b', 'Kepler-703').
orbita('Kepler-1505 b', 'Kepler-1505').
orbita('Kepler-203 d', 'Kepler-203').
orbita('HD 75898 b', 'HD 75898').
orbita('Kepler-776 b', 'Kepler-776').
orbita('Kepler-876 b', 'Kepler-876').
orbita('Kepler-224 b', 'Kepler-224').
orbita('Kepler-1459 b', 'Kepler-1459').
orbita('Kepler-710 b', 'Kepler-710').
orbita('Kepler-806 b', 'Kepler-806').
orbita('Kepler-205 b', 'Kepler-205').
orbita('KOI-4427 b', 'KOI-4427').
orbita('Kepler-612 b', 'Kepler-612').
orbita('MOA-2008-BLG-310L b', 'MOA-2008-BLG-310L').
orbita('KIC 11442793 g', 'KIC 11442793').
orbita('GJ 1214 b', 'GJ 1214').
orbita('Kepler-824 b', 'Kepler-824').
orbita('Kepler-1451 b', 'Kepler-1451').
orbita('Kepler-268 c', 'Kepler-268').
orbita('Kepler-135 c', 'Kepler-135').
orbita('Kepler-265 c', 'Kepler-265').
orbita('Kepler-1296 b', 'Kepler-1296').
orbita('Kepler-1480 b', 'Kepler-1480').
orbita('Kepler-620 b', 'Kepler-620').
orbita('16 Cyg B b', '16 Cyg B').
orbita('HAT-P-25 b', 'HAT-P-25').
orbita('Kepler-341 e', 'Kepler-341').
orbita('HD 213240 b', 'HD 213240').
orbita('Kepler-1577 b', 'Kepler-1577').
orbita('Kepler-1409 b', 'Kepler-1409').
orbita('Kepler-1352 b', 'Kepler-1352').
orbita('Kepler-1249 b', 'Kepler-1249').
orbita('Kepler-1269 b', 'Kepler-1269').
orbita('HAT-P-45 b', 'HAT-P-45').
orbita('Kepler-399 b', 'Kepler-399').
orbita('Kepler-341 c', 'Kepler-341').
orbita('Kepler-925 b', 'Kepler-925').
orbita('Kepler-265 d', 'Kepler-265').
orbita('Kepler-677 b', 'Kepler-677').
orbita('HD 33844 b', 'HD 33844').
orbita('Kepler-243 c', 'Kepler-243').
orbita('Kepler-561 b', 'Kepler-561').
orbita('HD 12661 b', 'HD 12661').
orbita('Kepler-467 b', 'Kepler-467').
orbita('Kepler-1107 b', 'Kepler-1107').
orbita('Kepler-9 c', 'Kepler-9').
orbita('HD 74156 c', 'HD 74156').
orbita('Kepler-165 c', 'Kepler-165').
orbita('Kepler-790 b', 'Kepler-790').
orbita('Kepler-326 d', 'Kepler-326').
orbita('HD 20794 c', 'HD 20794').
orbita('WASP-47 c', 'WASP-47').
orbita('Kepler-31 c', 'Kepler-31').
orbita('Kepler-82 b', 'Kepler-82').
orbita('Kepler-573 b', 'Kepler-573').
orbita('Kepler-1288 b', 'Kepler-1288').
orbita('Kepler-306 c', 'Kepler-306').
orbita('Kepler-1484 b', 'Kepler-1484').
orbita('Kepler-85 e', 'Kepler-85').
orbita('Kepler-583 b', 'Kepler-583').
orbita('Kepler-610 b', 'Kepler-610').
orbita('HD 38801 b', 'HD 38801').
orbita('Kepler-964 b', 'Kepler-964').
orbita('HD 132563 B b', 'HD 132563 B').
orbita('Kepler-1227 b', 'Kepler-1227').
orbita('Kepler-351 d', 'Kepler-351').
orbita('Kepler-390 c', 'Kepler-390').
orbita('Kepler-61 b', 'Kepler-61').
orbita('Kepler-1486 b', 'Kepler-1486').
orbita('Kepler-803 b', 'Kepler-803').
orbita('GJ 667 C c', 'GJ 667 C').
orbita('HD 207832 c', 'HD 207832').
orbita('Kepler-80 b', 'Kepler-80').
orbita('Kepler-1462 b', 'Kepler-1462').
orbita('Kepler-886 b', 'Kepler-886').
orbita('Kepler-1468 c', 'Kepler-1468').
orbita('Kepler-272 d', 'Kepler-272').
orbita('Kepler-1544 b', 'Kepler-1544').
orbita('Kepler-44 b', 'Kepler-44').
orbita('HD 5891 b', 'HD 5891').
orbita('Kepler-292 b', 'Kepler-292').
orbita('Kepler-228 d', 'Kepler-228').
orbita('Kepler-1000 b', 'Kepler-1000').
orbita('Kepler-140 b', 'Kepler-140').
orbita('Kepler-245 d', 'Kepler-245').
orbita('Kepler-884 b', 'Kepler-884').
orbita('Kepler-1073 c', 'Kepler-1073').
orbita('Kepler-908 b', 'Kepler-908').
orbita('HD 173416 b', 'HD 173416').
orbita('Kepler-1379 b', 'Kepler-1379').
orbita('Kepler-104 c', 'Kepler-104').
orbita('Kepler-263 b', 'Kepler-263').
orbita('Kepler-1008 b', 'Kepler-1008').
orbita('Kepler-278 c', 'Kepler-278').
orbita('Kepler-1587 b', 'Kepler-1587').
orbita('Kepler-1569 b', 'Kepler-1569').
orbita('Kepler-1273 b', 'Kepler-1273').
orbita('Kepler-1365 c', 'Kepler-1365').
orbita('HD 76700 b', 'HD 76700').
orbita('Kepler-366 b', 'Kepler-366').
orbita('HD 39091 b', 'HD 39091').
orbita('Kepler-1636 b', 'Kepler-1636').
orbita('Kepler-1068 b', 'Kepler-1068').
orbita('Kepler-596 b', 'Kepler-596').
orbita('HD 7449 b', 'HD 7449').
orbita('HD 149026 b', 'HD 149026').
orbita('Kepler-186 b', 'Kepler-186').
orbita('Kepler-219 c', 'Kepler-219').
orbita('OGLE-2006-BLG-109L c', 'OGLE-2006-BLG-109L').
orbita('Kepler-561 c', 'Kepler-561').
orbita('Kepler-1240 b', 'Kepler-1240').
orbita('Kepler-361 c', 'Kepler-361').
orbita('Kepler-265 e', 'Kepler-265').
orbita('Qatar-2 b', 'Qatar-2').
orbita('Kepler-1448 b', 'Kepler-1448').
orbita('Kepler-293 b', 'Kepler-293').
orbita('Kepler-166 b', 'Kepler-166').
orbita('Kepler-1551 b', 'Kepler-1551').
orbita('HD 216437 b', 'HD 216437').
orbita('Kepler-1052 b', 'Kepler-1052').
orbita('HAT-P-49 b', 'HAT-P-49').
orbita('Kepler-623 b', 'Kepler-623').
orbita('Kepler-1621 b', 'Kepler-1621').
orbita('Kepler-367 c', 'Kepler-367').
orbita('Kepler-313 b', 'Kepler-313').
orbita('Kepler-1439 b', 'Kepler-1439').
orbita('Kepler-150 c', 'Kepler-150').
orbita('Kepler-87 b', 'Kepler-87').
orbita('Kepler-681 b', 'Kepler-681').
orbita('Kepler-564 b', 'Kepler-564').
orbita('HAT-P-7 b', 'HAT-P-7').
orbita('Kepler-316 c', 'Kepler-316').
orbita('PSR B1257+12 C', 'PSR B1257+12').
orbita('HD 49674 b', 'HD 49674').
orbita('HD 82943 b', 'HD 82943').
orbita('Kepler-342 c', 'Kepler-342').
orbita('Kepler-783 b', 'Kepler-783').
orbita('Kepler-1378 b', 'Kepler-1378').
orbita('Kepler-828 b', 'Kepler-828').
orbita('WASP-38 b', 'WASP-38').
orbita('WASP-69 b', 'WASP-69').
orbita('Kepler-139 c', 'Kepler-139').
orbita('Kepler-1199 b', 'Kepler-1199').
orbita('Kepler-817 b', 'Kepler-817').
orbita('HD 77338 b', 'HD 77338').
orbita('Kepler-29 c', 'Kepler-29').
orbita('Kepler-605 c', 'Kepler-605').
orbita('Kepler-444 c', 'Kepler-444').
orbita('HD 220773 b', 'HD 220773').
orbita('Kepler-655 b', 'Kepler-655').
orbita('Kepler-559 b', 'Kepler-559').
orbita('WASP-6 b', 'WASP-6').
orbita('HD 7924 d', 'HD 7924').
orbita('Kepler-1337 b', 'Kepler-1337').
orbita('Kepler-1552 b', 'Kepler-1552').
orbita('Kepler-206 c', 'Kepler-206').
orbita('Kepler-169 c', 'Kepler-169').
orbita('HD 159868 c', 'HD 159868').
orbita('HD 137388 b', 'HD 137388').
orbita('HD 95086 b', 'HD 95086').
orbita('Kepler-196 b', 'Kepler-196').
orbita('Kepler-352 b', 'Kepler-352').
orbita('Kepler-329 b', 'Kepler-329').
orbita('Kepler-179 b', 'Kepler-179').
orbita('Kepler-1080 b', 'Kepler-1080').
orbita('Kepler-176 b', 'Kepler-176').
orbita('WASP-104 b', 'WASP-104').
orbita('WASP-83 b', 'WASP-83').
orbita('Kepler-1095 b', 'Kepler-1095').
orbita('Kepler-1170 b', 'Kepler-1170').
orbita('Kepler-310 c', 'Kepler-310').
orbita('Kepler-339 b', 'Kepler-339').
orbita('Kepler-124 d', 'Kepler-124').
orbita('Kepler-52 c', 'Kepler-52').
orbita('Kepler-1132 b', 'Kepler-1132').
orbita('Kepler-1265 b', 'Kepler-1265').
orbita('Kepler-1494 b', 'Kepler-1494').
orbita('WASP-99 b', 'WASP-99').
orbita('HD 100777 b', 'HD 100777').
orbita('Kepler-818 b', 'Kepler-818').
orbita('HAT-P-5 b', 'HAT-P-5').
orbita('Kepler-1381 b', 'Kepler-1381').
orbita('Kepler-125 b', 'Kepler-125').
orbita('Kepler-193 b', 'Kepler-193').
orbita('Kepler-1078 b', 'Kepler-1078').
orbita('Kepler-585 b', 'Kepler-585').
orbita('HD 222582 b', 'HD 222582').
orbita('Kepler-119 c', 'Kepler-119').
orbita('Kepler-558 b', 'Kepler-558').
orbita('Kepler-670 b', 'Kepler-670').
orbita('Kepler-770 c', 'Kepler-770').
orbita('Kepler-1188 b', 'Kepler-1188').
orbita('Kepler-434 b', 'Kepler-434').
orbita('Kepler-1398 c', 'Kepler-1398').
orbita('Kepler-16 b', 'Kepler-16').
orbita('Kepler-32 d', 'Kepler-32').
orbita('Kepler-58 c', 'Kepler-58').
orbita('Kepler-758 b', 'Kepler-758').
orbita('Kepler-1122 b', 'Kepler-1122').
orbita('Kepler-1534 b', 'Kepler-1534').
orbita('WASP-33 b', 'WASP-33').
orbita('HD 128311 b', 'HD 128311').
orbita('HD 181433 d', 'HD 181433').
orbita('TrES-1 b', 'TrES-1').
orbita('HD 4208 b', 'HD 4208').
orbita('Kepler-773 b', 'Kepler-773').
orbita('Kepler-62 e', 'Kepler-62').
orbita('Kepler-120 b', 'Kepler-120').
orbita('HD 5388 b', 'HD 5388').
orbita('Kepler-1393 b', 'Kepler-1393').
orbita('Kepler-1001 b', 'Kepler-1001').
orbita('CoRoT-10 b', 'CoRoT-10').
orbita('Kepler-1309 b', 'Kepler-1309').
orbita('11 UMi b', '11 UMi').
orbita('Kepler-286 d', 'Kepler-286').
orbita('Kepler-338 c', 'Kepler-338').
orbita('WASP-62 b', 'WASP-62').
orbita('Kepler-496 b', 'Kepler-496').
orbita('Kepler-1641 c', 'Kepler-1641').
orbita('Kepler-1616 b', 'Kepler-1616').
orbita('Kepler-300 c', 'Kepler-300').
orbita('Kepler-1582 b', 'Kepler-1582').
orbita('HD 4732 c', 'HD 4732').
orbita('Kepler-258 c', 'Kepler-258').
orbita('Kepler-555 b', 'Kepler-555').
orbita('Kepler-1270 b', 'Kepler-1270').
orbita('Kepler-632 b', 'Kepler-632').
orbita('kappa CrB b', 'kappa CrB').
orbita('Kepler-25 b', 'Kepler-25').
orbita('HD 99492 b', 'HD 99492').
orbita('Kepler-167 c', 'Kepler-167').
orbita('Kepler-291 b', 'Kepler-291').
orbita('HD 204941 b', 'HD 204941').
orbita('Kepler-664 b', 'Kepler-664').
orbita('Kepler-1051 b', 'Kepler-1051').
orbita('Kepler-603 d', 'Kepler-603').
orbita('Kepler-218 d', 'Kepler-218').
orbita('Kepler-332 d', 'Kepler-332').
orbita('HD 196050 b', 'HD 196050').
orbita('WASP-11 b', 'WASP-11').
orbita('HD 111232 b', 'HD 111232').
orbita('HD 117618 b', 'HD 117618').
orbita('Kepler-192 c', 'Kepler-192').
orbita('HD 180902 b', 'HD 180902').
orbita('Kepler-671 b', 'Kepler-671').
orbita('Kepler-1263 b', 'Kepler-1263').
orbita('HIP 12961 b', 'HIP 12961').
orbita('Kepler-1357 b', 'Kepler-1357').
orbita('HD 63454 b', 'HD 63454').
orbita('Kepler-460 c', 'Kepler-460').
orbita('BD +48 738 b', 'BD +48 738').
orbita('Kepler-560 b', 'Kepler-560').
orbita('Kepler-62 c', 'Kepler-62').
orbita('Kepler-371 c', 'Kepler-371').
orbita('Kepler-909 b', 'Kepler-909').
orbita('Kepler-732 b', 'Kepler-732').
orbita('Kepler-724 b', 'Kepler-724').
orbita('NGC 2423 3 b', 'NGC 2423 3').
orbita('Kepler-227 b', 'Kepler-227').
orbita('Kepler-33 c', 'Kepler-33').
orbita('Kepler-1280 b', 'Kepler-1280').
orbita('Kepler-1383 b', 'Kepler-1383').
orbita('Kepler-938 b', 'Kepler-938').
orbita('Kepler-275 b', 'Kepler-275').
orbita('TRAPPIST-1 d', 'TRAPPIST-1').
orbita('HD 13908 b', 'HD 13908').
orbita('HD 50499 b', 'HD 50499').
orbita('CoRoT-14 b', 'CoRoT-14').
orbita('Kepler-1542 e', 'Kepler-1542').
orbita('Kepler-820 b', 'Kepler-820').
orbita('Kepler-521 b', 'Kepler-521').
orbita('Kepler-1136 b', 'Kepler-1136').
orbita('Kepler-176 d', 'Kepler-176').
orbita('Kepler-319 d', 'Kepler-319').
orbita('Kepler-832 b', 'Kepler-832').
orbita('Kepler-80 d', 'Kepler-80').
orbita('Kepler-155 b', 'Kepler-155').
orbita('Kepler-342 d', 'Kepler-342').
orbita('Kepler-1015 b', 'Kepler-1015').
orbita('CoRoT-4 b', 'CoRoT-4').
orbita('Kepler-610 c', 'Kepler-610').
orbita('HAT-P-19 b', 'HAT-P-19').
orbita('Kepler-736 b', 'Kepler-736').
orbita('Kepler-784 b', 'Kepler-784').
orbita('Kepler-825 c', 'Kepler-825').
orbita('HD 154857 c', 'HD 154857').
orbita('Kepler-1037 b', 'Kepler-1037').
orbita('Kepler-1425 b', 'Kepler-1425').
orbita('Kepler-24 c', 'Kepler-24').
orbita('Kepler-47 c', 'Kepler-47').
orbita('GJ 163 b', 'GJ 163').
orbita('Kepler-133 c', 'Kepler-133').
orbita('Kepler-919 b', 'Kepler-919').
orbita('HIP 116454 b', 'HIP 116454').
orbita('Kepler-924 b', 'Kepler-924').
orbita('Kepler-988 b', 'Kepler-988').
orbita('Kepler-33 f', 'Kepler-33').
orbita('Kepler-116 b', 'Kepler-116').
orbita('Kepler-869 b', 'Kepler-869').
orbita('Kepler-848 b', 'Kepler-848').
orbita('Kepler-107 c', 'Kepler-107').
orbita('Kepler-84 e', 'Kepler-84').
orbita('Kepler-109 b', 'Kepler-109').
orbita('Kepler-764 b', 'Kepler-764').
orbita('Kepler-734 b', 'Kepler-734').
orbita('Kepler-315 b', 'Kepler-315').
orbita('Kepler-837 b', 'Kepler-837').
orbita('Kepler-639 b', 'Kepler-639').
orbita('KIC 11442793 f', 'KIC 11442793').
orbita('Kepler-1208 b', 'Kepler-1208').
orbita('Kepler-1238 b', 'Kepler-1238').
orbita('Kepler-586 b', 'Kepler-586').
orbita('Kepler-757 b', 'Kepler-757').
orbita('HD 2039 b', 'HD 2039').
orbita('Kepler-170 b', 'Kepler-170').
orbita('Kepler-36 c', 'Kepler-36').
orbita('Kepler-247 d', 'Kepler-247').
orbita('Kepler-136 b', 'Kepler-136').
orbita('XO-2 b', 'XO-2').
orbita('Kepler-859 b', 'Kepler-859').
orbita('Kepler-305 d', 'Kepler-305').
orbita('Kepler-120 c', 'Kepler-120').
orbita('Kepler-393 b', 'Kepler-393').
orbita('Kepler-96 b', 'Kepler-96').
orbita('Kepler-11 d', 'Kepler-11').
orbita('Kepler-1497 b', 'Kepler-1497').
orbita('Kepler-1257 b', 'Kepler-1257').
orbita('HD 187085 b', 'HD 187085').
orbita('HD 118203 b', 'HD 118203').
orbita('Kepler-833 b', 'Kepler-833').
orbita('Kepler-106 b', 'Kepler-106').
orbita('Kepler-198 d', 'Kepler-198').
orbita('Kepler-464 b', 'Kepler-464').
orbita('WASP-63 b', 'WASP-63').
orbita('Kepler-30 b', 'Kepler-30').
orbita('Kepler-836 b', 'Kepler-836').
orbita('Kepler-214 c', 'Kepler-214').
orbita('Kepler-946 b', 'Kepler-946').
orbita('HD 175167 b', 'HD 175167').
orbita('Kepler-273 b', 'Kepler-273').
orbita('Kepler-461 b', 'Kepler-461').
orbita('Kepler-1603 b', 'Kepler-1603').
orbita('Kepler-323 c', 'Kepler-323').
orbita('Kepler-84 d', 'Kepler-84').
orbita('Kepler-267 c', 'Kepler-267').
orbita('HAT-P-16 b', 'HAT-P-16').
orbita('TrES-4 b', 'TrES-4').
orbita('Kepler-231 c', 'Kepler-231').
orbita('NGC 4349 127 b', 'NGC 4349 127').
orbita('Kepler-184 b', 'Kepler-184').
orbita('GJ 676 A b', 'GJ 676 A').
orbita('Kepler-60 b', 'Kepler-60').
orbita('Kepler-1124 b', 'Kepler-1124').
orbita('Kepler-1235 b', 'Kepler-1235').
orbita('Kepler-151 b', 'Kepler-151').
orbita('Kepler-242 c', 'Kepler-242').
orbita('Kepler-230 b', 'Kepler-230').
orbita('HD 47186 c', 'HD 47186').
orbita('Kepler-463 b', 'Kepler-463').
orbita('Kepler-1553 b', 'Kepler-1553').
orbita('Kepler-1003 b', 'Kepler-1003').
orbita('Kepler-840 b', 'Kepler-840').
orbita('Kepler-351 c', 'Kepler-351').
orbita('Kepler-534 b', 'Kepler-534').
orbita('Kepler-350 b', 'Kepler-350').
orbita('Kepler-382 b', 'Kepler-382').
orbita('Kepler-900 b', 'Kepler-900').
orbita('HIP 14810 d', 'HIP 14810').
orbita('Kepler-209 b', 'Kepler-209').
orbita('Kepler-123 c', 'Kepler-123').
orbita('HD 142245 b', 'HD 142245').
orbita('Kepler-1251 b', 'Kepler-1251').
orbita('Kepler-59 c', 'Kepler-59').
orbita('Kepler-493 b', 'Kepler-493').
orbita('KIC 11442793 b', 'KIC 11442793').
orbita('Kepler-1054 b', 'Kepler-1054').
orbita('Kepler-258 b', 'Kepler-258').
orbita('Kepler-1607 b', 'Kepler-1607').
orbita('Kepler-309 c', 'Kepler-309').
orbita('Kepler-1447 b', 'Kepler-1447').
orbita('Kepler-302 c', 'Kepler-302').
orbita('Kepler-1489 b', 'Kepler-1489').
orbita('HD 30177 b', 'HD 30177').
orbita('Kepler-466 b', 'Kepler-466').
orbita('Kepler-678 b', 'Kepler-678').
orbita('Kepler-446 d', 'Kepler-446').
orbita('Kepler-4 b', 'Kepler-4').
orbita('Kepler-1370 b', 'Kepler-1370').
orbita('Kepler-882 b', 'Kepler-882').
orbita('bet Cnc b', 'bet Cnc').
orbita('HD 190647 b', 'HD 190647').
orbita('Kepler-530 b', 'Kepler-530').
orbita('Kepler-1522 b', 'Kepler-1522').
orbita('Kepler-759 b', 'Kepler-759').
orbita('Kepler-1351 b', 'Kepler-1351').
orbita('Kepler-529 c', 'Kepler-529').
orbita('Kepler-977 b', 'Kepler-977').
orbita('HD 97658 b', 'HD 97658').
orbita('Kepler-261 b', 'Kepler-261').
orbita('Kepler-658 b', 'Kepler-658').
orbita('Kepler-57 b', 'Kepler-57').
orbita('Kepler-175 b', 'Kepler-175').
orbita('Kepler-509 b', 'Kepler-509').
orbita('Kepler-577 b', 'Kepler-577').
orbita('Kepler-323 b', 'Kepler-323').
orbita('Kepler-1153 b', 'Kepler-1153').
orbita('Kepler-433 b', 'Kepler-433').
orbita('Kepler-1319 b', 'Kepler-1319').
orbita('Kepler-377 c', 'Kepler-377').
orbita('HD 106270 b', 'HD 106270').
orbita('Kepler-1287 b', 'Kepler-1287').
orbita('Kepler-426 b', 'Kepler-426').
orbita('Kepler-379 c', 'Kepler-379').
orbita('WASP-20 b', 'WASP-20').
orbita('HD 30856 b', 'HD 30856').
orbita('Kepler-315 c', 'Kepler-315').
orbita('Kepler-80 c', 'Kepler-80').
orbita('Kepler-179 c', 'Kepler-179').
orbita('HD 24064 b', 'HD 24064').
orbita('HD 48265 b', 'HD 48265').
orbita('Kepler-476 b', 'Kepler-476').
orbita('Kepler-154 e', 'Kepler-154').
orbita('HATS-4 b', 'HATS-4').
orbita('Kepler-1608 b', 'Kepler-1608').
orbita('Kepler-527 b', 'Kepler-527').
orbita('CoRoT-27 b', 'CoRoT-27').
orbita('Kepler-1115 b', 'Kepler-1115').
orbita('Kepler-1141 b', 'Kepler-1141').
orbita('Kepler-360 c', 'Kepler-360').
orbita('Kepler-154 d', 'Kepler-154').
orbita('Kepler-262 b', 'Kepler-262').
orbita('Kepler-969 c', 'Kepler-969').
orbita('Kepler-1106 b', 'Kepler-1106').
orbita('Kepler-381 b', 'Kepler-381').
orbita('Kepler-168 c', 'Kepler-168').
orbita('Kepler-84 f', 'Kepler-84').
orbita('Kepler-874 b', 'Kepler-874').
orbita('Kepler-987 b', 'Kepler-987').
orbita('Kepler-529 b', 'Kepler-529').
orbita('HD 89307 b', 'HD 89307').
orbita('Kepler-1039 b', 'Kepler-1039').
orbita('Kepler-1112 b', 'Kepler-1112').
orbita('HD 163607 c', 'HD 163607').
orbita('Kepler-960 b', 'Kepler-960').
orbita('WASP-49 b', 'WASP-49').
orbita('Kepler-288 b', 'Kepler-288').
orbita('Kepler-37 c', 'Kepler-37').
orbita('Kepler-1314 b', 'Kepler-1314').
orbita('Kepler-55 b', 'Kepler-55').
orbita('Kepler-1504 b', 'Kepler-1504').
orbita('HD 4313 b', 'HD 4313').
orbita('Kepler-1197 b', 'Kepler-1197').
orbita('HR 8799 b', 'HR 8799').
orbita('Kepler-774 b', 'Kepler-774').
orbita('Kepler-1173 b', 'Kepler-1173').
orbita('HD 2638 b', 'HD 2638').
orbita('Kepler-272 b', 'Kepler-272').
orbita('Kepler-231 b', 'Kepler-231').
orbita('Kepler-512 b', 'Kepler-512').
orbita('Kepler-747 b', 'Kepler-747').
orbita('Kepler-827 b', 'Kepler-827').
orbita('Kepler-1057 b', 'Kepler-1057').
orbita('HD 168443 b', 'HD 168443').
orbita('WASP-41 c', 'WASP-41').
orbita('Kepler-373 b', 'Kepler-373').
orbita('Kepler-1622 b', 'Kepler-1622').
orbita('Kepler-288 d', 'Kepler-288').
orbita('HD 10180 f', 'HD 10180').
orbita('Kepler-445 c', 'Kepler-445').
orbita('Kepler-1088 b', 'Kepler-1088').
orbita('HD 45350 b', 'HD 45350').
orbita('Kepler-770 d', 'Kepler-770').
orbita('HD 69830 c', 'HD 69830').
orbita('Kepler-963 b', 'Kepler-963').
orbita('TYC 1422-614-1 b', 'TYC 1422-614-1').
orbita('Kepler-21 b', 'Kepler-21').
orbita('Kepler-352 c', 'Kepler-352').
orbita('Kepler-363 b', 'Kepler-363').
orbita('Kepler-1053 b', 'Kepler-1053').
orbita('Kepler-390 b', 'Kepler-390').
orbita('CoRoT-28 b', 'CoRoT-28').
orbita('Kepler-340 b', 'Kepler-340').
orbita('Kepler-679 b', 'Kepler-679').
orbita('Kepler-335 c', 'Kepler-335').
orbita('Kepler-841 b', 'Kepler-841').
orbita('HD 47186 b', 'HD 47186').
orbita('Kepler-226 b', 'Kepler-226').
orbita('KELT-3 b', 'KELT-3').
orbita('Kepler-51 c', 'Kepler-51').
orbita('Kepler-1639 b', 'Kepler-1639').
orbita('HD 148427 b', 'HD 148427').
orbita('Kepler-810 b', 'Kepler-810').
orbita('Kepler-226 c', 'Kepler-226').
orbita('Kepler-1520 b', 'Kepler-1520').
orbita('Kepler-533 b', 'Kepler-533').
orbita('epsilon Tau b', 'epsilon Tau').
orbita('Kepler-11 e', 'Kepler-11').
orbita('Kepler-366 c', 'Kepler-366').
orbita('Kepler-1419 b', 'Kepler-1419').
orbita('HAT-P-46 b', 'HAT-P-46').
orbita('HD 208487 b', 'HD 208487').
orbita('Kepler-1033 b', 'Kepler-1033').
orbita('Kepler-616 c', 'Kepler-616').
orbita('Kepler-288 c', 'Kepler-288').
orbita('Kepler-1517 b', 'Kepler-1517').
orbita('Kepler-48 d', 'Kepler-48').
orbita('Kepler-626 b', 'Kepler-626').
orbita('Kepler-311 b', 'Kepler-311').
orbita('Kepler-117 c', 'Kepler-117').
orbita('epsilon Eri b', 'epsilon Eri').
orbita('Kepler-271 d', 'Kepler-271').
orbita('Kepler-69 c', 'Kepler-69').
orbita('Kepler-935 b', 'Kepler-935').
orbita('Kepler-1245 b', 'Kepler-1245').
orbita('Kepler-296 f', 'Kepler-296').
orbita('HD 20782 b', 'HD 20782').
orbita('Kepler-613 b', 'Kepler-613').
orbita('Kepler-1011 b', 'Kepler-1011').
orbita('Kepler-1536 b', 'Kepler-1536').
orbita('Kepler-726 b', 'Kepler-726').
orbita('Kepler-1400 b', 'Kepler-1400').
orbita('Kepler-896 b', 'Kepler-896').
orbita('Kepler-228 c', 'Kepler-228').
orbita('HD 190360 c', 'HD 190360').
orbita('Kepler-23 c', 'Kepler-23').
orbita('Kepler-823 b', 'Kepler-823').
orbita('Kepler-1490 b', 'Kepler-1490').
orbita('Kepler-378 b', 'Kepler-378').
orbita('Kepler-760 b', 'Kepler-760').
orbita('Kepler-1558 b', 'Kepler-1558').
orbita('Kepler-1618 b', 'Kepler-1618').
orbita('HD 65216 b', 'HD 65216').
orbita('Kepler-343 c', 'Kepler-343').
orbita('Kepler-42 b', 'Kepler-42').
orbita('Kepler-593 b', 'Kepler-593').
orbita('Kepler-212 b', 'Kepler-212').
orbita('Kepler-296 c', 'Kepler-296').
orbita('Kepler-1482 b', 'Kepler-1482').
orbita('Kepler-157 d', 'Kepler-157').
orbita('Kepler-1004 b', 'Kepler-1004').
orbita('Kepler-356 b', 'Kepler-356').
orbita('Kepler-968 b', 'Kepler-968').
orbita('HAT-P-13 b', 'HAT-P-13').
orbita('Kepler-244 b', 'Kepler-244').
orbita('Kepler-448 b', 'Kepler-448').
orbita('GJ 3634 b', 'GJ 3634').
orbita('Kepler-9 b', 'Kepler-9').
orbita('Kepler-1070 b', 'Kepler-1070').
orbita('Kepler-1087 b', 'Kepler-1087').
orbita('Kepler-1071 b', 'Kepler-1071').
orbita('Kepler-1432 b', 'Kepler-1432').
orbita('HD 130322 b', 'HD 130322').
orbita('Kepler-1422 b', 'Kepler-1422').
orbita('Kepler-1388 e', 'Kepler-1388').
orbita('Kepler-934 b', 'Kepler-934').
orbita('Kepler-31 d', 'Kepler-31').
orbita('Kepler-399 d', 'Kepler-399').
orbita('Kepler-215 c', 'Kepler-215').
orbita('Kepler-108 b', 'Kepler-108').
orbita('Kepler-742 b', 'Kepler-742').
orbita('Kepler-1050 c', 'Kepler-1050').
orbita('Kepler-1298 b', 'Kepler-1298').
orbita('Kepler-1297 b', 'Kepler-1297').
orbita('Kepler-1613 b', 'Kepler-1613').
orbita('Kepler-903 c', 'Kepler-903').
orbita('Kepler-348 c', 'Kepler-348').
orbita('Kepler-1543 b', 'Kepler-1543').
orbita('Kepler-124 b', 'Kepler-124').
orbita('Kepler-185 c', 'Kepler-185').
orbita('Kepler-191 c', 'Kepler-191').
orbita('omega Ser b', 'omega Ser').
orbita('Kepler-111 b', 'Kepler-111').
orbita('Kepler-673 b', 'Kepler-673').
orbita('Kepler-965 b', 'Kepler-965').
orbita('Kepler-1295 b', 'Kepler-1295').
orbita('Kepler-968 c', 'Kepler-968').
orbita('HD 16175 b', 'HD 16175').
orbita('Kepler-235 b', 'Kepler-235').
orbita('Kepler-1436 b', 'Kepler-1436').
orbita('HD 46375 b', 'HD 46375').
orbita('Kepler-48 c', 'Kepler-48').
orbita('Kepler-114 b', 'Kepler-114').
orbita('Kepler-60 d', 'Kepler-60').
orbita('Kepler-741 b', 'Kepler-741').
orbita('CoRoT-29 b', 'CoRoT-29').
orbita('Kepler-868 b', 'Kepler-868').
orbita('Kepler-14 b', 'Kepler-14').
orbita('Kepler-234 c', 'Kepler-234').
orbita('Kepler-1308 b', 'Kepler-1308').
orbita('Kepler-1302 b', 'Kepler-1302').
orbita('CoRoT-13 b', 'CoRoT-13').
orbita('HD 98219 b', 'HD 98219').
orbita('HD 12648 b', 'HD 12648').
orbita('HD 11964 b', 'HD 11964').
orbita('HAT-P-34 b', 'HAT-P-34').
orbita('Kepler-654 b', 'Kepler-654').
orbita('Kepler-421 b', 'Kepler-421').
orbita('Kepler-1241 b', 'Kepler-1241').
orbita('MOA-2010-BLG-477L b', 'MOA-2010-BLG-477L').
orbita('Kepler-31 b', 'Kepler-31').
orbita('Kepler-85 c', 'Kepler-85').
orbita('Kepler-1198 b', 'Kepler-1198').
orbita('Kepler-1139 b', 'Kepler-1139').
orbita('Kepler-219 d', 'Kepler-219').
orbita('Kepler-1206 b', 'Kepler-1206').
orbita('mu Leo b', 'mu Leo').
orbita('Kepler-431 b', 'Kepler-431').
orbita('Kepler-1531 b', 'Kepler-1531').
orbita('Kepler-248 c', 'Kepler-248').
orbita('Kepler-481 b', 'Kepler-481').
orbita('HD 139357 b', 'HD 139357').
orbita('HD 1461 b', 'HD 1461').
orbita('Kepler-1275 b', 'Kepler-1275').
orbita('Kepler-283 c', 'Kepler-283').
orbita('HAT-P-30 b', 'HAT-P-30').
orbita('Kepler-430 c', 'Kepler-430').
orbita('Kepler-1360 b', 'Kepler-1360').
orbita('Kepler-901 b', 'Kepler-901').
orbita('Kepler-251 d', 'Kepler-251').
orbita('Kepler-234 b', 'Kepler-234').
orbita('Kepler-37 b', 'Kepler-37').
orbita('Kepler-392 c', 'Kepler-392').
orbita('HD 8535 b', 'HD 8535').
orbita('Kepler-1619 b', 'Kepler-1619').
orbita('Kepler-1473 b', 'Kepler-1473').
orbita('HAT-P-28 b', 'HAT-P-28').
orbita('Kepler-474 b', 'Kepler-474').
orbita('Kepler-349 c', 'Kepler-349').
orbita('HD 4203 b', 'HD 4203').
orbita('Kepler-553 c', 'Kepler-553').
orbita('Kepler-331 d', 'Kepler-331').
orbita('HD 102956 b', 'HD 102956').
orbita('WTS-2 b', 'WTS-2').
orbita('Kepler-362 c', 'Kepler-362').
orbita('Kepler-1147 b', 'Kepler-1147').
orbita('Kepler-186 e', 'Kepler-186').
orbita('Kepler-321 c', 'Kepler-321').
orbita('Kepler-1083 b', 'Kepler-1083').
orbita('Kepler-376 c', 'Kepler-376').
orbita('Kepler-1589 b', 'Kepler-1589').
orbita('Fomalhaut b', 'Fomalhaut').
orbita('GJ 176 b', 'GJ 176').
orbita('Kepler-873 b', 'Kepler-873').
orbita('HD 23079 b', 'HD 23079').
orbita('HD 178911 B b', 'HD 178911 B').
orbita('WASP-58 b', 'WASP-58').
orbita('Kepler-506 b', 'Kepler-506').
orbita('Kepler-1571 b', 'Kepler-1571').
orbita('Kepler-543 b', 'Kepler-543').
orbita('Kepler-1535 b', 'Kepler-1535').
orbita('Kepler-1030 b', 'Kepler-1030').
orbita('Kepler-244 c', 'Kepler-244').
orbita('Kepler-245 e', 'Kepler-245').
orbita('Kepler-1067 b', 'Kepler-1067').
orbita('Kepler-354 b', 'Kepler-354').
orbita('Kepler-1203 b', 'Kepler-1203').
orbita('Kepler-278 b', 'Kepler-278').
orbita('HD 162020 b', 'HD 162020').
orbita('Kepler-809 b', 'Kepler-809').
orbita('Kepler-1468 b', 'Kepler-1468').
orbita('Kepler-1368 b', 'Kepler-1368').
orbita('Kepler-183 b', 'Kepler-183').
orbita('Kepler-1392 b', 'Kepler-1392').
orbita('MOA-bin-1L b', 'MOA-bin-1L').
orbita('Kepler-1556 b', 'Kepler-1556').
orbita('Kepler-944 b', 'Kepler-944').
orbita('Kepler-1110 b', 'Kepler-1110').
orbita('Kepler-210 c', 'Kepler-210').
orbita('Kepler-437 b', 'Kepler-437').
orbita('Kepler-184 d', 'Kepler-184').
orbita('HD 168746 b', 'HD 168746').
orbita('GJ 876 c', 'GJ 876').
orbita('Kepler-1164 b', 'Kepler-1164').
orbita('Kepler-958 b', 'Kepler-958').
orbita('Kepler-20 c', 'Kepler-20').
orbita('Kepler-712 c', 'Kepler-712').
orbita('Kepler-47 b', 'Kepler-47').
orbita('Kepler-580 b', 'Kepler-580').
orbita('Kepler-296 b', 'Kepler-296').
orbita('Kepler-755 b', 'Kepler-755').
orbita('Kepler-402 b', 'Kepler-402').
orbita('Kepler-260 b', 'Kepler-260').
orbita('Kepler-255 c', 'Kepler-255').
orbita('Kepler-750 b', 'Kepler-750').
orbita('HD 215497 b', 'HD 215497').
orbita('Kepler-1221 b', 'Kepler-1221').
orbita('Kepler-62 f', 'Kepler-62').
orbita('Kepler-1160 b', 'Kepler-1160').
orbita('HATS-5 b', 'HATS-5').
orbita('HD 154345 b', 'HD 154345').
orbita('Kepler-60 c', 'Kepler-60').
orbita('Kepler-1031 b', 'Kepler-1031').
orbita('Kepler-523 b', 'Kepler-523').
orbita('Kepler-395 c', 'Kepler-395').
orbita('HD 217107 b', 'HD 217107').
orbita('Kepler-1550 b', 'Kepler-1550').
orbita('Kepler-431 c', 'Kepler-431').
orbita('mu Ara c', 'mu Ara').
orbita('HD 7199 b', 'HD 7199').
orbita('Kepler-887 c', 'Kepler-887').
orbita('Kepler-233 c', 'Kepler-233').
orbita('GJ 433 b', 'GJ 433').
orbita('Kepler-1301 b', 'Kepler-1301').
orbita('Kepler-1350 c', 'Kepler-1350').
orbita('HD 159243 b', 'HD 159243').
orbita('Kepler-327 d', 'Kepler-327').
orbita('HAT-P-31 b', 'HAT-P-31').
orbita('Kepler-878 b', 'Kepler-878').
orbita('OGLE-TR-113 b', 'OGLE-TR-113').
orbita('Kepler-356 c', 'Kepler-356').
orbita('Kepler-41 b', 'Kepler-41').
orbita('Kepler-798 b', 'Kepler-798').
orbita('Kepler-825 b', 'Kepler-825').
orbita('Kepler-473 b', 'Kepler-473').
orbita('Kepler-270 b', 'Kepler-270').
orbita('HD 285507 b', 'HD 285507').
orbita('Kepler-1307 b', 'Kepler-1307').
orbita('Kepler-1573 b', 'Kepler-1573').
orbita('HD 40307 d', 'HD 40307').
orbita('Kepler-590 b', 'Kepler-590').
orbita('Kepler-1220 b', 'Kepler-1220').
orbita('Kepler-849 b', 'Kepler-849').
orbita('HD 290327 b', 'HD 290327').
orbita('Kepler-438 b', 'Kepler-438').
orbita('Kepler-1315 b', 'Kepler-1315').
orbita('GJ 876 e', 'GJ 876').
orbita('Kepler-1413 b', 'Kepler-1413').
orbita('Kepler-1604 b', 'Kepler-1604').
orbita('Kepler-1471 b', 'Kepler-1471').
orbita('Kepler-1445 b', 'Kepler-1445').
orbita('Kepler-1020 b', 'Kepler-1020').
orbita('Kepler-572 b', 'Kepler-572').
orbita('Kepler-1598 b', 'Kepler-1598').
orbita('Kepler-1187 b', 'Kepler-1187').
orbita('Kepler-949 b', 'Kepler-949').
orbita('HD 169830 c', 'HD 169830').
orbita('Kepler-608 b', 'Kepler-608').
orbita('47 UMa c', '47 UMa').
orbita('Kepler-85 b', 'Kepler-85').
orbita('Kepler-880 b', 'Kepler-880').
orbita('Kepler-1343 b', 'Kepler-1343').
orbita('Kepler-575 b', 'Kepler-575').
orbita('Kepler-313 c', 'Kepler-313').
orbita('Kepler-199 b', 'Kepler-199').
orbita('Kepler-172 b', 'Kepler-172').
orbita('Kepler-223 d', 'Kepler-223').
orbita('Kepler-431 d', 'Kepler-431').
orbita('Kepler-917 b', 'Kepler-917').
orbita('Kepler-1072 b', 'Kepler-1072').
orbita('Kepler-360 b', 'Kepler-360').
orbita('Kepler-1212 b', 'Kepler-1212').
orbita('Kepler-246 b', 'Kepler-246').
orbita('Kepler-347 b', 'Kepler-347').
orbita('HD 63765 b', 'HD 63765').
orbita('Kepler-217 c', 'Kepler-217').
orbita('HD 85390 b', 'HD 85390').
orbita('Kepler-1590 b', 'Kepler-1590').
orbita('Kepler-1498 b', 'Kepler-1498').
orbita('Kepler-401 c', 'Kepler-401').
orbita('Kepler-299 c', 'Kepler-299').
orbita('Kepler-1176 b', 'Kepler-1176').
orbita('HAT-P-57 b', 'HAT-P-57').
orbita('Kepler-525 b', 'Kepler-525').
orbita('Kepler-112 b', 'Kepler-112').
orbita('Kepler-1326 b', 'Kepler-1326').
orbita('Kepler-748 b', 'Kepler-748').
orbita('Kepler-155 c', 'Kepler-155').
orbita('Kepler-271 c', 'Kepler-271').
orbita('Kepler-961 b', 'Kepler-961').
orbita('Kepler-241 c', 'Kepler-241').
orbita('Kepler-492 b', 'Kepler-492').
orbita('WASP-77 A b', 'WASP-77 A').
orbita('Kepler-164 c', 'Kepler-164').
orbita('Kepler-371 b', 'Kepler-371').
orbita('Kepler-548 b', 'Kepler-548').
orbita('55 Cnc e', '55 Cnc').
orbita('HIP 57274 d', 'HIP 57274').
orbita('Kepler-1254 d', 'Kepler-1254').
orbita('HD 221287 b', 'HD 221287').
orbita('KOI-13 b', 'KOI-13').
orbita('Kepler-1017 b', 'Kepler-1017').
orbita('Kepler-1100 b', 'Kepler-1100').
orbita('Kepler-1050 b', 'Kepler-1050').
orbita('Kepler-1460 b', 'Kepler-1460').
orbita('Kepler-1310 b', 'Kepler-1310').
orbita('HD 192699 b', 'HD 192699').
orbita('Kepler-178 d', 'Kepler-178').
orbita('Kepler-1371 c', 'Kepler-1371').
orbita('Kepler-1090 b', 'Kepler-1090').
orbita('Kepler-312 b', 'Kepler-312').
orbita('Kepler-164 b', 'Kepler-164').
orbita('Kepler-1557 b', 'Kepler-1557').
orbita('Kepler-341 b', 'Kepler-341').
orbita('Kepler-311 c', 'Kepler-311').
orbita('Kepler-1509 b', 'Kepler-1509').
orbita('HD 181342 b', 'HD 181342').
orbita('WASP-8 b', 'WASP-8').
orbita('HD 131496 b', 'HD 131496').
orbita('Kepler-154 c', 'Kepler-154').
orbita('Kepler-334 c', 'Kepler-334').
orbita('Kepler-911 b', 'Kepler-911').
orbita('Kepler-372 c', 'Kepler-372').
orbita('Kepler-127 b', 'Kepler-127').
orbita('HD 44219 b', 'HD 44219').
orbita('75 Cet b', '75 Cet').
orbita('Kepler-27 b', 'Kepler-27').
orbita('Kepler-210 b', 'Kepler-210').
orbita('Kepler-40 b', 'Kepler-40').
orbita('Kepler-171 c', 'Kepler-171').
orbita('Kepler-298 c', 'Kepler-298').
orbita('Kepler-331 c', 'Kepler-331').
orbita('Kepler-1538 b', 'Kepler-1538').
orbita('Kepler-576 b', 'Kepler-576').
orbita('Kepler-479 b', 'Kepler-479').
orbita('Kepler-915 b', 'Kepler-915').
orbita('HD 220074 b', 'HD 220074').
orbita('Kepler-133 b', 'Kepler-133').
orbita('Kepler-1185 b', 'Kepler-1185').
orbita('Kepler-788 b', 'Kepler-788').
orbita('WASP-89 b', 'WASP-89').
orbita('HAT-P-39 b', 'HAT-P-39').
orbita('WASP-26 b', 'WASP-26').
orbita('Kepler-751 b', 'Kepler-751').
orbita('WASP-71 b', 'WASP-71').
orbita('HIP 2247 b', 'HIP 2247').
orbita('GJ 876 d', 'GJ 876').
orbita('Kepler-312 c', 'Kepler-312').
orbita('OGLE-TR-56 b', 'OGLE-TR-56').
orbita('Kepler-697 b', 'Kepler-697').
orbita('Kepler-826 b', 'Kepler-826').
orbita('Kepler-235 c', 'Kepler-235').
orbita('Kepler-1591 b', 'Kepler-1591').
orbita('Kepler-146 c', 'Kepler-146').
orbita('Kepler-1633 b', 'Kepler-1633').
orbita('Kepler-903 b', 'Kepler-903').
orbita('Kepler-372 d', 'Kepler-372').
orbita('Kepler-156 b', 'Kepler-156').
orbita('HD 38529 b', 'HD 38529').
orbita('Kepler-393 c', 'Kepler-393').
orbita('Kepler-136 c', 'Kepler-136').
orbita('Kepler-1353 b', 'Kepler-1353').
orbita('Kepler-436 b', 'Kepler-436').
orbita('Kepler-1595 b', 'Kepler-1595').
orbita('Kepler-1593 b', 'Kepler-1593').
orbita('WASP-82 b', 'WASP-82').
orbita('Kepler-1219 b', 'Kepler-1219').
orbita('Kepler-737 b', 'Kepler-737').
orbita('Kepler-948 b', 'Kepler-948').
orbita('Kepler-1021 b', 'Kepler-1021').
orbita('Kepler-866 b', 'Kepler-866').
orbita('BD +20 2457 c', 'BD +20 2457').
orbita('Kepler-497 b', 'Kepler-497').
orbita('Kepler-1344 b', 'Kepler-1344').
orbita('Kepler-1388 d', 'Kepler-1388').
orbita('Kepler-144 b', 'Kepler-144').
orbita('HD 22781 b', 'HD 22781').
orbita('Kepler-1253 b', 'Kepler-1253').
orbita('Kepler-208 d', 'Kepler-208').
orbita('Kepler-286 e', 'Kepler-286').
orbita('Kepler-351 b', 'Kepler-351').
orbita('HD 120084 b', 'HD 120084').
orbita('HD 95127 b', 'HD 95127').
orbita('MOA-2009-BLG-266L b', 'MOA-2009-BLG-266L').
orbita('Kepler-755 c', 'Kepler-755').
orbita('Kepler-1578 b', 'Kepler-1578').
orbita('Kepler-89 d', 'Kepler-89').
orbita('Kepler-387 b', 'Kepler-387').
orbita('HD 20868 b', 'HD 20868').
orbita('Kepler-854 b', 'Kepler-854').
orbita('HAT-P-9 b', 'HAT-P-9').
orbita('Kepler-410 A b', 'Kepler-410 A').
orbita('Kepler-33 e', 'Kepler-33').
orbita('Kepler-1527 b', 'Kepler-1527').
orbita('Kepler-1093 b', 'Kepler-1093').
orbita('Kepler-1024 b', 'Kepler-1024').
orbita('Kepler-1271 b', 'Kepler-1271').
orbita('Kepler-216 c', 'Kepler-216').
orbita('Kepler-365 c', 'Kepler-365').
orbita('Kepler-1488 b', 'Kepler-1488').
orbita('Kepler-19 b', 'Kepler-19').
orbita('Kepler-130 b', 'Kepler-130').
orbita('Kepler-160 c', 'Kepler-160').
orbita('Kepler-598 b', 'Kepler-598').
orbita('Kepler-207 c', 'Kepler-207').
orbita('Kepler-284 b', 'Kepler-284').
orbita('Kepler-326 b', 'Kepler-326').
orbita('Kepler-1391 b', 'Kepler-1391').
orbita('Kepler-1516 b', 'Kepler-1516').
orbita('Kepler-969 b', 'Kepler-969').
orbita('HD 107148 b', 'HD 107148').
orbita('HD 1666 b', 'HD 1666').
orbita('Kepler-200 c', 'Kepler-200').
orbita('Kepler-95 b', 'Kepler-95').
orbita('Kepler-1444 b', 'Kepler-1444').
orbita('Kepler-280 c', 'Kepler-280').
orbita('KIC 11442793 e', 'KIC 11442793').
orbita('Kepler-829 b', 'Kepler-829').
orbita('Kepler-249 d', 'Kepler-249').
orbita('Kepler-812 b', 'Kepler-812').
orbita('HD 95872 b', 'HD 95872').
orbita('Kepler-1242 b', 'Kepler-1242').
orbita('51 Peg b', '51 Peg').
orbita('WASP-60 b', 'WASP-60').
orbita('Kepler-904 b', 'Kepler-904').
orbita('Kepler-1113 b', 'Kepler-1113').
orbita('Kepler-99 b', 'Kepler-99').
orbita('Kepler-1394 b', 'Kepler-1394').
orbita('Kepler-752 b', 'Kepler-752').
orbita('Kepler-125 c', 'Kepler-125').
orbita('HD 5319 c', 'HD 5319').
orbita('Kepler-996 b', 'Kepler-996').
orbita('Kepler-588 b', 'Kepler-588').
orbita('Kepler-1454 b', 'Kepler-1454').
orbita('Kepler-319 c', 'Kepler-319').
orbita('Kepler-1143 c', 'Kepler-1143').
orbita('Kepler-153 b', 'Kepler-153').
orbita('Kepler-1642 c', 'Kepler-1642').
orbita('Kepler-1336 b', 'Kepler-1336').
orbita('55 Cnc f', '55 Cnc').
orbita('Kepler-539 b', 'Kepler-539').
orbita('Kepler-929 b', 'Kepler-929').
orbita('Kepler-238 d', 'Kepler-238').
orbita('HAT-P-54 b', 'HAT-P-54').
orbita('HIP 67851 b', 'HIP 67851').
orbita('Kepler-845 b', 'Kepler-845').
orbita('Kepler-1245 c', 'Kepler-1245').
orbita('Kepler-153 c', 'Kepler-153').
orbita('HD 212301 b', 'HD 212301').
orbita('Kepler-574 b', 'Kepler-574').
orbita('Kepler-865 b', 'Kepler-865').
orbita('Kepler-295 c', 'Kepler-295').
orbita('GJ 504 b', 'GJ 504').
orbita('HAT-P-15 b', 'HAT-P-15').
orbita('Kepler-24 e', 'Kepler-24').
orbita('HD 209458 b', 'HD 209458').
orbita('Kepler-729 b', 'Kepler-729').
orbita('HD 102272 b', 'HD 102272').
orbita('K2-3 d', 'K2-3').
orbita('HD 181433 b', 'HD 181433').
orbita('Kepler-898 b', 'Kepler-898').
orbita('HD 187123 b', 'HD 187123').
orbita('Kepler-1481 b', 'Kepler-1481').
orbita('HD 108147 b', 'HD 108147').
orbita('Kepler-82 c', 'Kepler-82').
orbita('Kepler-1143 b', 'Kepler-1143').
orbita('Kepler-1617 b', 'Kepler-1617').
orbita('WASP-61 b', 'WASP-61').
orbita('Kepler-58 b', 'Kepler-58').
orbita('eta Cet b', 'eta Cet').
orbita('Kepler-606 b', 'Kepler-606').
orbita('Kepler-686 b', 'Kepler-686').
orbita('Kepler-487 b', 'Kepler-487').
orbita('Kepler-957 b', 'Kepler-957').
orbita('Kepler-1099 b', 'Kepler-1099').
orbita('Kepler-379 b', 'Kepler-379').
orbita('Kepler-376 b', 'Kepler-376').
orbita('Kepler-166 d', 'Kepler-166').
orbita('HD 215497 c', 'HD 215497').
orbita('Kepler-1345 b', 'Kepler-1345').
orbita('Kepler-1325 b', 'Kepler-1325').
orbita('Kepler-1624 b', 'Kepler-1624').
orbita('Kepler-1086 c', 'Kepler-1086').
orbita('Kepler-662 b', 'Kepler-662').
orbita('Kepler-225 b', 'Kepler-225').
orbita('CoRoT-17 b', 'CoRoT-17').
orbita('HD 20794 d', 'HD 20794').
orbita('xi Aql b', 'xi Aql').
orbita('Kepler-444 d', 'Kepler-444').
orbita('Kepler-1058 b', 'Kepler-1058').
orbita('Kepler-892 b', 'Kepler-892').
orbita('Kepler-444 e', 'Kepler-444').
orbita('HD 33564 b', 'HD 33564').
orbita('Kepler-1243 b', 'Kepler-1243').
orbita('Kepler-635 b', 'Kepler-635').
orbita('Kepler-890 b', 'Kepler-890').
orbita('HD 40979 b', 'HD 40979').
orbita('Kepler-959 b', 'Kepler-959').
orbita('GJ 581 c', 'GJ 581').
orbita('Kepler-945 b', 'Kepler-945').
orbita('Kepler-1303 b', 'Kepler-1303').
orbita('HD 10180 c', 'HD 10180').
orbita('WASP-31 b', 'WASP-31').
orbita('Kepler-1496 b', 'Kepler-1496').
orbita('bet UMi b', 'bet UMi').
orbita('HD 134987 c', 'HD 134987').
orbita('Kepler-1118 b', 'Kepler-1118').
orbita('Kepler-1286 b', 'Kepler-1286').
orbita('Kepler-102 d', 'Kepler-102').
orbita('Kepler-164 d', 'Kepler-164').
orbita('HD 40307 b', 'HD 40307').
orbita('WASP-101 b', 'WASP-101').
orbita('Kepler-1395 b', 'Kepler-1395').
orbita('Kepler-199 c', 'Kepler-199').
orbita('Kepler-344 b', 'Kepler-344').
orbita('Kepler-132 b', 'Kepler-132').
orbita('iota Dra b', 'iota Dra').
orbita('HD 108874 b', 'HD 108874').
orbita('Kepler-250 d', 'Kepler-250').
orbita('Kepler-256 d', 'Kepler-256').
orbita('Kepler-187 b', 'Kepler-187').
orbita('HD 4732 b', 'HD 4732').
orbita('Kepler-991 b', 'Kepler-991').
orbita('Kepler-374 d', 'Kepler-374').
orbita('Kepler-563 b', 'Kepler-563').
orbita('Kepler-1119 b', 'Kepler-1119').
orbita('Kepler-383 c', 'Kepler-383').
orbita('HD 23596 b', 'HD 23596').
orbita('Kepler-1630 b', 'Kepler-1630').
orbita('Kepler-295 b', 'Kepler-295').
orbita('Kepler-171 d', 'Kepler-171').
orbita('HD 25171 b', 'HD 25171').
orbita('HD 83443 b', 'HD 83443').
orbita('Kepler-304 e', 'Kepler-304').
orbita('Kepler-287 b', 'Kepler-287').
orbita('Kepler-1065 b', 'Kepler-1065').
orbita('WASP-36 b', 'WASP-36').
orbita('Kepler-1358 b', 'Kepler-1358').
orbita('Kepler-213 c', 'Kepler-213').
orbita('Kepler-268 b', 'Kepler-268').
orbita('Kepler-532 b', 'Kepler-532').
orbita('Kepler-430 b', 'Kepler-430').
orbita('HD 43691 b', 'HD 43691').
orbita('Kepler-204 b', 'Kepler-204').
orbita('Kepler-149 c', 'Kepler-149').
orbita('Kepler-1371 b', 'Kepler-1371').
orbita('30 Ari B b', '30 Ari B').
orbita('Kepler-1120 b', 'Kepler-1120').
orbita('Kepler-1597 b', 'Kepler-1597').
orbita('HAT-P-6 b', 'HAT-P-6').
orbita('Kepler-35 b', 'Kepler-35').
orbita('Kepler-1581 b', 'Kepler-1581').
orbita('Kepler-397 b', 'Kepler-397').
orbita('Kepler-129 c', 'Kepler-129').
orbita('Kepler-398 c', 'Kepler-398').
orbita('Kepler-551 b', 'Kepler-551').
orbita('Kepler-850 b', 'Kepler-850').
orbita('Kepler-211 b', 'Kepler-211').
orbita('Kepler-242 b', 'Kepler-242').
orbita('Kepler-138 b', 'Kepler-138').
orbita('Kepler-389 b', 'Kepler-389').
orbita('PSR B1257+12 A', 'PSR B1257+12').
orbita('BD -08 2823 c', 'BD -08 2823').
orbita('Kepler-611 b', 'Kepler-611').
orbita('Kepler-951 b', 'Kepler-951').
orbita('4 UMa b', '4 UMa').
orbita('Qatar-1 b', 'Qatar-1').
orbita('Kepler-794 b', 'Kepler-794').
orbita('HD 10697 b', 'HD 10697').
orbita('Kepler-597 b', 'Kepler-597').
orbita('Kepler-1433 b', 'Kepler-1433').
orbita('Kepler-194 b', 'Kepler-194').
orbita('Kepler-1121 b', 'Kepler-1121').
orbita('HD 33844 c', 'HD 33844').
orbita('Kepler-221 d', 'Kepler-221').
orbita('Kepler-338 d', 'Kepler-338').
orbita('Kepler-1575 b', 'Kepler-1575').
orbita('Kepler-535 b', 'Kepler-535').
orbita('Kepler-32 e', 'Kepler-32').
orbita('HD 113337 b', 'HD 113337').
orbita('Kepler-146 b', 'Kepler-146').
orbita('Kepler-11 f', 'Kepler-11').
orbita('BD +20 2457 b', 'BD +20 2457').
orbita('Kepler-1152 b', 'Kepler-1152').
orbita('Kepler-176 c', 'Kepler-176').
orbita('mu Ara d', 'mu Ara').
orbita('HD 3651 b', 'HD 3651').
orbita('KIC 11442793 d', 'KIC 11442793').
orbita('Kepler-714 b', 'Kepler-714').
orbita('Kepler-1236 b', 'Kepler-1236').
orbita('Kepler-442 b', 'Kepler-442').
orbita('Kepler-1193 b', 'Kepler-1193').
orbita('Kepler-1262 b', 'Kepler-1262').
orbita('HD 99706 b', 'HD 99706').
orbita('Kepler-251 b', 'Kepler-251').
orbita('HD 169830 b', 'HD 169830').
orbita('Kepler-292 c', 'Kepler-292').
orbita('Kepler-1367 b', 'Kepler-1367').
orbita('Kepler-491 b', 'Kepler-491').
orbita('HD 175541 b', 'HD 175541').
orbita('Kepler-324 b', 'Kepler-324').
orbita('Kepler-250 c', 'Kepler-250').
orbita('Kepler-462 b', 'Kepler-462').
orbita('Kepler-568 b', 'Kepler-568').
orbita('Kepler-1149 b', 'Kepler-1149').
orbita('HD 202206 c', 'HD 202206').
orbita('Kepler-309 b', 'Kepler-309').
orbita('Kepler-1116 b', 'Kepler-1116').
orbita('Kepler-1146 b', 'Kepler-1146').
orbita('Kepler-940 b', 'Kepler-940').
orbita('Kepler-1103 b', 'Kepler-1103').
orbita('Kepler-1117 b', 'Kepler-1117').
orbita('Kepler-571 b', 'Kepler-571').
orbita('Kepler-843 b', 'Kepler-843').
orbita('Kepler-936 b', 'Kepler-936').
orbita('Kepler-1339 b', 'Kepler-1339').
orbita('Kepler-1005 b', 'Kepler-1005').
orbita('HD 145457 b', 'HD 145457').
orbita('Kepler-261 c', 'Kepler-261').
orbita('Kepler-465 b', 'Kepler-465').
orbita('Kepler-336 c', 'Kepler-336').
orbita('Kepler-1584 b', 'Kepler-1584').
orbita('Kepler-1475 b', 'Kepler-1475').
orbita('HD 206610 b', 'HD 206610').
orbita('M 67 SAND 364 b', 'M 67 SAND 364').
orbita('Kepler-711 b', 'Kepler-711').
orbita('Kepler-365 b', 'Kepler-365').
orbita('Kepler-1610 b', 'Kepler-1610').
orbita('Kepler-838 b', 'Kepler-838').
orbita('Kepler-802 b', 'Kepler-802').
orbita('Kepler-1412 b', 'Kepler-1412').
orbita('Kepler-864 b', 'Kepler-864').
orbita('HD 12661 c', 'HD 12661').
orbita('Kepler-12 b', 'Kepler-12').
orbita('Kepler-229 d', 'Kepler-229').
orbita('Kepler-1411 b', 'Kepler-1411').
orbita('Kepler-1545 b', 'Kepler-1545').
orbita('KIC 11442793 c', 'KIC 11442793').
orbita('HAT-P-36 b', 'HAT-P-36').
orbita('WASP-35 b', 'WASP-35').
orbita('HD 69830 d', 'HD 69830').
orbita('CoRoT-22 b', 'CoRoT-22').
orbita('HD 28254 b', 'HD 28254').
orbita('HD 81688 b', 'HD 81688').
orbita('HD 210277 b', 'HD 210277').
orbita('Kepler-1514 b', 'Kepler-1514').
orbita('Kepler-132 c', 'Kepler-132').
orbita('WTS-1 b', 'WTS-1').
orbita('Kepler-322 b', 'Kepler-322').
orbita('HR 8799 c', 'HR 8799').
orbita('Kepler-717 b', 'Kepler-717').
orbita('Kepler-51 b', 'Kepler-51').
orbita('Kepler-252 b', 'Kepler-252').
orbita('XO-1 b', 'XO-1').
orbita('Kepler-63 b', 'Kepler-63').
orbita('Kepler-1423 b', 'Kepler-1423').
orbita('Kepler-33 d', 'Kepler-33').
orbita('Kepler-287 c', 'Kepler-287').
orbita('Kepler-154 f', 'Kepler-154').
orbita('Kepler-245 b', 'Kepler-245').
orbita('Kepler-537 b', 'Kepler-537').
orbita('Kepler-989 b', 'Kepler-989').
orbita('Kepler-100 c', 'Kepler-100').
orbita('GJ 15 A b', 'GJ 15 A').
orbita('Kepler-180 c', 'Kepler-180').
orbita('Kepler-82 e', 'Kepler-82').
orbita('Kepler-20 d', 'Kepler-20').
orbita('Kepler-217 b', 'Kepler-217').
orbita('Kepler-1523 b', 'Kepler-1523').
orbita('Kepler-235 e', 'Kepler-235').
orbita('Kepler-227 c', 'Kepler-227').
orbita('Kepler-169 d', 'Kepler-169').
orbita('Kepler-1226 b', 'Kepler-1226').
orbita('Kepler-1623 b', 'Kepler-1623').
orbita('Kepler-254 b', 'Kepler-254').
orbita('Kepler-79 e', 'Kepler-79').
orbita('Kepler-241 b', 'Kepler-241').
orbita('Kepler-1525 b', 'Kepler-1525').
orbita('Kepler-749 b', 'Kepler-749').
orbita('55 Cnc b', '55 Cnc').
orbita('Kepler-176 e', 'Kepler-176').
orbita('Kepler-565 b', 'Kepler-565').
orbita('Kepler-631 b', 'Kepler-631').
orbita('Kepler-380 c', 'Kepler-380').
orbita('Kepler-384 b', 'Kepler-384').
orbita('Kepler-1592 b', 'Kepler-1592').
orbita('Kepler-193 c', 'Kepler-193').
orbita('Kepler-1097 b', 'Kepler-1097').
orbita('Kepler-368 c', 'Kepler-368').
orbita('Kepler-102 f', 'Kepler-102').
orbita('Kepler-131 c', 'Kepler-131').
orbita('Kepler-74 b', 'Kepler-74').
orbita('HD 207832 b', 'HD 207832').
orbita('M 67 YBP 1514 b', 'M 67 YBP 1514').
orbita('WASP-55 b', 'WASP-55').
orbita('Kepler-1064 b', 'Kepler-1064').
orbita('Kepler-280 b', 'Kepler-280').
orbita('HAT-P-56 b', 'HAT-P-56').
orbita('Kepler-1277 b', 'Kepler-1277').
orbita('Kepler-1144 b', 'Kepler-1144').
orbita('Kepler-325 c', 'Kepler-325').
orbita('GJ 3293 b', 'GJ 3293').
orbita('Kepler-547 b', 'Kepler-547').
orbita('HD 33283 b', 'HD 33283').
orbita('Kepler-1312 b', 'Kepler-1312').
orbita('Kepler-842 b', 'Kepler-842').
orbita('OGLE-TR-111 b', 'OGLE-TR-111').
orbita('MOA-2007-BLG-400L b', 'MOA-2007-BLG-400L').
orbita('Kepler-704 b', 'Kepler-704').
orbita('HD 10180 e', 'HD 10180').
orbita('Kepler-1532 b', 'Kepler-1532').
orbita('Kepler-647 b', 'Kepler-647').
orbita('Kepler-765 b', 'Kepler-765').
orbita('Kepler-1016 c', 'Kepler-1016').
orbita('Kepler-185 b', 'Kepler-185').
orbita('55 Cnc d', '55 Cnc').
orbita('HD 155233 b', 'HD 155233').
orbita('WASP-3 b', 'WASP-3').
orbita('HD 148156 b', 'HD 148156').
orbita('Kepler-172 d', 'Kepler-172').
orbita('Kepler-967 c', 'Kepler-967').
orbita('Kepler-182 c', 'Kepler-182').
orbita('Kepler-1016 b', 'Kepler-1016').
orbita('Kepler-1266 b', 'Kepler-1266').
orbita('TrES-5 b', 'TrES-5').
orbita('Kepler-1306 b', 'Kepler-1306').
orbita('Kepler-1483 b', 'Kepler-1483').
orbita('Kepler-1047 b', 'Kepler-1047').
orbita('Kepler-645 b', 'Kepler-645').
orbita('Kepler-49 e', 'Kepler-49').
orbita('HD 222155 b', 'HD 222155').
orbita('Kepler-399 c', 'Kepler-399').
orbita('Kepler-761 b', 'Kepler-761').
orbita('Kepler-1278 b', 'Kepler-1278').
orbita('Kepler-175 c', 'Kepler-175').
orbita('Kepler-391 c', 'Kepler-391').
orbita('HD 73526 b', 'HD 73526').
orbita('Kepler-768 b', 'Kepler-768').
orbita('Kepler-879 b', 'Kepler-879').
orbita('Kepler-1428 b', 'Kepler-1428').
orbita('Kepler-200 b', 'Kepler-200').
orbita('Kepler-1036 b', 'Kepler-1036').
orbita('Kepler-1129 c', 'Kepler-1129').
orbita('HD 117207 b', 'HD 117207').
orbita('Kepler-122 d', 'Kepler-122').
orbita('Kepler-1140 b', 'Kepler-1140').
orbita('Kepler-1565 b', 'Kepler-1565').
orbita('Kepler-1645 b', 'Kepler-1645').
orbita('Kepler-769 b', 'Kepler-769').
orbita('Kepler-1239 b', 'Kepler-1239').
orbita('HD 121504 b', 'HD 121504').
orbita('Kepler-1089 b', 'Kepler-1089').
orbita('Kepler-499 b', 'Kepler-499').
orbita('Kepler-852 b', 'Kepler-852').
orbita('Kepler-1354 b', 'Kepler-1354').
orbita('Kepler-342 e', 'Kepler-342').
orbita('Kepler-1366 b', 'Kepler-1366').
orbita('HD 156846 b', 'HD 156846').
orbita('Kepler-18 b', 'Kepler-18').
orbita('Kepler-1548 b', 'Kepler-1548').
orbita('HR 8799 d', 'HR 8799').
orbita('HAT-P-23 b', 'HAT-P-23').
orbita('HD 224693 b', 'HD 224693').
orbita('Kepler-1401 b', 'Kepler-1401').
orbita('Kepler-505 b', 'Kepler-505').
orbita('Kepler-388 c', 'Kepler-388').
orbita('Kepler-862 b', 'Kepler-862').
orbita('Kepler-246 c', 'Kepler-246').
orbita('Kepler-795 b', 'Kepler-795').
orbita('Kepler-941 b', 'Kepler-941').
orbita('HD 158038 b', 'HD 158038').
orbita('Kepler-1502 b', 'Kepler-1502').
orbita('Kepler-888 b', 'Kepler-888').
orbita('Kepler-822 b', 'Kepler-822').
orbita('Kepler-240 b', 'Kepler-240').
orbita('Kepler-26 c', 'Kepler-26').
orbita('Kepler-143 c', 'Kepler-143').
orbita('Kepler-1469 b', 'Kepler-1469').
orbita('Kepler-1334 b', 'Kepler-1334').
orbita('Kepler-508 b', 'Kepler-508').
orbita('K2-21 c', 'K2-21').
orbita('Kepler-1091 b', 'Kepler-1091').
orbita('GJ 179 b', 'GJ 179').
orbita('Kepler-206 b', 'Kepler-206').
orbita('Kepler-22 b', 'Kepler-22').
orbita('Kepler-1101 b', 'Kepler-1101').
orbita('Kepler-1369 b', 'Kepler-1369').
orbita('Kepler-68 c', 'Kepler-68').
orbita('Kepler-986 b', 'Kepler-986').
orbita('Kepler-300 b', 'Kepler-300').
orbita('Kepler-937 b', 'Kepler-937').
orbita('Kepler-110 c', 'Kepler-110').
orbita('Kepler-42 d', 'Kepler-42').
orbita('Kepler-357 d', 'Kepler-357').
orbita('HD 143361 b', 'HD 143361').
orbita('Kepler-715 b', 'Kepler-715').
orbita('HD 155358 b', 'HD 155358').
orbita('Kepler-134 b', 'Kepler-134').
orbita('Kepler-369 b', 'Kepler-369').
orbita('HD 192310 b', 'HD 192310').
orbita('Kepler-257 d', 'Kepler-257').
orbita('Kepler-342 b', 'Kepler-342').
orbita('Kepler-644 b', 'Kepler-644').
orbita('Kepler-1108 b', 'Kepler-1108').
orbita('Kepler-119 b', 'Kepler-119').
orbita('WASP-64 b', 'WASP-64').
orbita('Kepler-190 b', 'Kepler-190').
orbita('upsilon And b', 'upsilon And').
orbita('Kepler-56 c', 'Kepler-56').
orbita('Kepler-1267 b', 'Kepler-1267').
orbita('Kepler-1138 b', 'Kepler-1138').
orbita('Kepler-237 b', 'Kepler-237').
orbita('Kepler-132 e', 'Kepler-132').
orbita('Kepler-223 e', 'Kepler-223').
orbita('HD 86081 b', 'HD 86081').
orbita('WASP-74 b', 'WASP-74').
orbita('HD 109246 b', 'HD 109246').
orbita('WASP-68 b', 'WASP-68').
orbita('Kepler-81 d', 'Kepler-81').
orbita('Kepler-68 d', 'Kepler-68').
orbita('Kepler-403 c', 'Kepler-403').
orbita('Kepler-197 d', 'Kepler-197').
orbita('Kepler-1631 b', 'Kepler-1631').
orbita('Kepler-589 b', 'Kepler-589').
orbita('Kepler-701 b', 'Kepler-701').
orbita('Kepler-1300 b', 'Kepler-1300').
orbita('Kepler-1485 b', 'Kepler-1485').
orbita('Kepler-348 b', 'Kepler-348').
orbita('Kepler-341 d', 'Kepler-341').
orbita('Kepler-1632 b', 'Kepler-1632').
orbita('HD 128311 c', 'HD 128311').
orbita('Kepler-445 d', 'Kepler-445').
orbita('Kepler-603 b', 'Kepler-603').
orbita('Kepler-364 c', 'Kepler-364').
orbita('Kepler-299 e', 'Kepler-299').
orbita('Kepler-1075 b', 'Kepler-1075').
orbita('K2-25 b', 'K2-25').
orbita('Kepler-902 b', 'Kepler-902').
orbita('CoRoT-23 b', 'CoRoT-23').
orbita('Kepler-1158 b', 'Kepler-1158').
orbita('Kepler-387 c', 'Kepler-387').
orbita('Kepler-821 b', 'Kepler-821').
orbita('Kepler-684 b', 'Kepler-684').
orbita('Kepler-54 d', 'Kepler-54').
orbita('Kepler-1082 b', 'Kepler-1082').
orbita('Kepler-1474 b', 'Kepler-1474').
orbita('WASP-39 b', 'WASP-39').
orbita('Kepler-102 e', 'Kepler-102').
orbita('Kepler-1463 b', 'Kepler-1463').
orbita('Kepler-219 b', 'Kepler-219').
orbita('Kepler-1377 b', 'Kepler-1377').
orbita('Kepler-549 c', 'Kepler-549').
orbita('GJ 876 b', 'GJ 876').
orbita('Kepler-984 b', 'Kepler-984').
orbita('Kepler-385 b', 'Kepler-385').
orbita('Kepler-374 b', 'Kepler-374').
orbita('Kepler-296 e', 'Kepler-296').
orbita('HD 164509 b', 'HD 164509').
orbita('HD 9446 b', 'HD 9446').
orbita('HD 18742 b', 'HD 18742').
orbita('Kepler-255 b', 'Kepler-255').
orbita('Kepler-636 b', 'Kepler-636').
orbita('Kepler-197 b', 'Kepler-197').
orbita('Kepler-183 c', 'Kepler-183').
orbita('Kepler-745 b', 'Kepler-745').
orbita('Kepler-517 b', 'Kepler-517').
orbita('Kepler-232 b', 'Kepler-232').
orbita('Kepler-345 c', 'Kepler-345').
orbita('WASP-80 b', 'WASP-80').
orbita('HD 167042 b', 'HD 167042').
orbita('Kepler-1373 b', 'Kepler-1373').
orbita('Kepler-152 b', 'Kepler-152').
orbita('Kepler-743 b', 'Kepler-743').
orbita('HD 69830 b', 'HD 69830').
orbita('Kepler-983 b', 'Kepler-983').
orbita('Kepler-8 b', 'Kepler-8').
orbita('Kepler-1014 b', 'Kepler-1014').
orbita('Kepler-336 d', 'Kepler-336').
orbita('Kepler-646 b', 'Kepler-646').
orbita('Kepler-1272 b', 'Kepler-1272').
orbita('Kepler-353 c', 'Kepler-353').
orbita('HD 114762 b', 'HD 114762').
orbita('Kepler-154 b', 'Kepler-154').
orbita('Kepler-804 b', 'Kepler-804').
orbita('61 Vir c', '61 Vir').
orbita('HD 45652 b', 'HD 45652').
orbita('Kepler-1244 b', 'Kepler-1244').
orbita('Kepler-1386 b', 'Kepler-1386').
orbita('Kepler-978 b', 'Kepler-978').
orbita('Kepler-1404 b', 'Kepler-1404').
orbita('Kepler-735 b', 'Kepler-735').
orbita('Kepler-237 c', 'Kepler-237').
orbita('HAT-P-14 b', 'HAT-P-14').
orbita('Kepler-972 b', 'Kepler-972').
orbita('Kepler-317 c', 'Kepler-317').
orbita('Kepler-1572 b', 'Kepler-1572').
orbita('Kepler-301 d', 'Kepler-301').
orbita('Kepler-1363 b', 'Kepler-1363').
orbita('Kepler-148 c', 'Kepler-148').
orbita('Kepler-49 d', 'Kepler-49').
orbita('Kepler-668 b', 'Kepler-668').
orbita('Kepler-1013 b', 'Kepler-1013').
orbita('Kepler-796 b', 'Kepler-796').
orbita('Kepler-1634 b', 'Kepler-1634').
orbita('HIP 105854 b', 'HIP 105854').
orbita('Kepler-169 b', 'Kepler-169').
orbita('WASP-66 b', 'WASP-66').
orbita('HD 73256 b', 'HD 73256').
orbita('Kepler-1427 b', 'Kepler-1427').
orbita('Kepler-303 c', 'Kepler-303').
orbita('Kepler-1274 b', 'Kepler-1274').
orbita('Kepler-1032 b', 'Kepler-1032').
orbita('Kepler-168 b', 'Kepler-168').
orbita('Kepler-56 b', 'Kepler-56').
orbita('6 Lyn b', '6 Lyn').
orbita('Kepler-238 b', 'Kepler-238').
orbita('Kepler-151 c', 'Kepler-151').
orbita('Kepler-1487 b', 'Kepler-1487').
orbita('Kepler-150 b', 'Kepler-150').
orbita('HD 180314 b', 'HD 180314').
orbita('HD 17092 b', 'HD 17092').
orbita('Kepler-780 b', 'Kepler-780').
orbita('Kepler-353 b', 'Kepler-353').
orbita('Kepler-931 b', 'Kepler-931').
orbita('Kepler-1246 b', 'Kepler-1246').
orbita('Kepler-1169 b', 'Kepler-1169').
orbita('Kepler-1105 b', 'Kepler-1105').
orbita('HIP 57274 b', 'HIP 57274').
orbita('Kepler-93 b', 'Kepler-93').
orbita('Kepler-281 c', 'Kepler-281').
orbita('WASP-94 A b', 'WASP-94 A').
orbita('Kepler-236 b', 'Kepler-236').
orbita('HD 202206 b', 'HD 202206').
orbita('WASP-5 b', 'WASP-5').
orbita('Kepler-78 b', 'Kepler-78').
orbita('Kepler-55 f', 'Kepler-55').
orbita('Kepler-314 c', 'Kepler-314').
orbita('CoRoT-2 b', 'CoRoT-2').
orbita('Kepler-447 b', 'Kepler-447').
orbita('Kepler-187 c', 'Kepler-187').
orbita('Kepler-257 c', 'Kepler-257').
orbita('Kepler-424 c', 'Kepler-424').
orbita('Kepler-522 b', 'Kepler-522').
orbita('HD 108874 c', 'HD 108874').
orbita('Kepler-1615 b', 'Kepler-1615').
orbita('GJ 832 c', 'GJ 832').
orbita('Kepler-894 b', 'Kepler-894').
orbita('Kepler-1609 b', 'Kepler-1609').
orbita('Kepler-289 b', 'Kepler-289').
orbita('Kepler-1524 b', 'Kepler-1524').
orbita('Kepler-346 c', 'Kepler-346').
orbita('Kepler-1403 b', 'Kepler-1403').
orbita('Kepler-953 b', 'Kepler-953').
orbita('Kepler-1479 b', 'Kepler-1479').
orbita('HD 200964 c', 'HD 200964').
orbita('HD 10180 h', 'HD 10180').
orbita('HD 33142 b', 'HD 33142').
orbita('Kepler-402 e', 'Kepler-402').
orbita('HAT-P-20 b', 'HAT-P-20').
orbita('HD 7924 b', 'HD 7924').
orbita('Kepler-834 b', 'Kepler-834').
orbita('Kepler-439 b', 'Kepler-439').
orbita('Kepler-1060 b', 'Kepler-1060').
orbita('Kepler-1150 b', 'Kepler-1150').
orbita('CoRoT-5 b', 'CoRoT-5').
orbita('Kepler-1184 b', 'Kepler-1184').
orbita('WASP-47 b', 'WASP-47').
orbita('Kepler-194 d', 'Kepler-194').
orbita('OGLE-2011-BLG-0251 b', 'OGLE-2011-BLG-0251').
orbita('Kepler-1566 b', 'Kepler-1566').
orbita('Kepler-36 b', 'Kepler-36').
orbita('Kepler-161 b', 'Kepler-161').
orbita('Kepler-943 b', 'Kepler-943').
orbita('Kepler-899 b', 'Kepler-899').
orbita('HAT-P-35 b', 'HAT-P-35').
orbita('HD 99109 b', 'HD 99109').
orbita('Kepler-1347 b', 'Kepler-1347').
orbita('Kepler-649 b', 'Kepler-649').
orbita('Kepler-778 b', 'Kepler-778').
orbita('Kepler-253 c', 'Kepler-253').
orbita('Kepler-744 b', 'Kepler-744').
orbita('Kepler-5 b', 'Kepler-5').
orbita('Kepler-161 c', 'Kepler-161').
orbita('HD 10647 b', 'HD 10647').
orbita('Kepler-675 b', 'Kepler-675').
orbita('Kepler-758 d', 'Kepler-758').
orbita('Kepler-331 b', 'Kepler-331').
orbita('Kepler-28 c', 'Kepler-28').
orbita('Kepler-600 b', 'Kepler-600').
orbita('HATS-9 b', 'HATS-9').
orbita('Kepler-782 b', 'Kepler-782').
orbita('Kepler-121 b', 'Kepler-121').
orbita('Kepler-1407 b', 'Kepler-1407').
orbita('Kepler-816 b', 'Kepler-816').
orbita('Kepler-1205 b', 'Kepler-1205').
orbita('Kepler-1585 b', 'Kepler-1585').
orbita('Kepler-621 b', 'Kepler-621').
orbita('Kepler-412 b', 'Kepler-412').
orbita('upsilon And c', 'upsilon And').
orbita('Kepler-170 c', 'Kepler-170').
orbita('Kepler-122 b', 'Kepler-122').
orbita('WASP-12 b', 'WASP-12').
orbita('Kepler-148 b', 'Kepler-148').
orbita('HD 170469 b', 'HD 170469').
orbita('Kepler-285 b', 'Kepler-285').
orbita('HD 88133 b', 'HD 88133').
orbita('HD 196885 b', 'HD 196885').
orbita('24 Sex b', '24 Sex').
orbita('HD 190228 b', 'HD 190228').
orbita('Kepler-333 b', 'Kepler-333').
orbita('Kepler-510 b', 'Kepler-510').
orbita('Kepler-370 c', 'Kepler-370').
orbita('OGLE-2006-BLG-109L b', 'OGLE-2006-BLG-109L').
orbita('Kepler-762 b', 'Kepler-762').
orbita('Kepler-111 c', 'Kepler-111').
orbita('Kepler-267 d', 'Kepler-267').
orbita('HD 181720 b', 'HD 181720').
orbita('55 Cnc c', '55 Cnc').
orbita('Kepler-1125 b', 'Kepler-1125').
orbita('Kepler-995 b', 'Kepler-995').
orbita('HD 156411 b', 'HD 156411').
orbita('Kepler-1196 b', 'Kepler-1196').
orbita('HATS-3 b', 'HATS-3').
orbita('Kepler-101 b', 'Kepler-101').
orbita('Kepler-536 b', 'Kepler-536').
orbita('Kepler-680 b', 'Kepler-680').
orbita('91 Aqr b', '91 Aqr').
orbita('Kepler-362 b', 'Kepler-362').
orbita('Kepler-301 b', 'Kepler-301').
orbita('Kepler-1126 b', 'Kepler-1126').
orbita('Kepler-860 b', 'Kepler-860').
orbita('Kepler-403 b', 'Kepler-403').
orbita('Kepler-676 b', 'Kepler-676').
orbita('Kepler-1596 b', 'Kepler-1596').
orbita('Kepler-404 c', 'Kepler-404').
orbita('Kepler-279 b', 'Kepler-279').
orbita('HD 27894 b', 'HD 27894').
orbita('Kepler-1256 b', 'Kepler-1256').
orbita('HD 156279 b', 'HD 156279').
orbita('Kepler-411 c', 'Kepler-411').
orbita('Kepler-207 d', 'Kepler-207').
orbita('Kepler-502 b', 'Kepler-502').
orbita('Kepler-297 c', 'Kepler-297').
orbita('Kepler-436 c', 'Kepler-436').
orbita('Kepler-345 b', 'Kepler-345').
orbita('Kepler-1449 b', 'Kepler-1449').
orbita('61 Vir d', '61 Vir').
orbita('Kepler-141 c', 'Kepler-141').
orbita('Kepler-1399 b', 'Kepler-1399').
orbita('HD 179079 b', 'HD 179079').
orbita('Kepler-504 b', 'Kepler-504').
orbita('Kepler-220 d', 'Kepler-220').
orbita('OGLE-05-390L b', 'OGLE-05-390L').
orbita('WASP-4 b', 'WASP-4').
orbita('Kepler-432 c', 'Kepler-432').
orbita('Kepler-141 b', 'Kepler-141').
orbita('Kepler-1641 b', 'Kepler-1641').
orbita('Kepler-1026 b', 'Kepler-1026').
orbita('HD 4113 b', 'HD 4113').
orbita('Kepler-488 b', 'Kepler-488').
orbita('HD 330075 b', 'HD 330075').
orbita('Kepler-1029 b', 'Kepler-1029').
orbita('Kepler-754 b', 'Kepler-754').
orbita('Kepler-524 c', 'Kepler-524').
orbita('Kepler-256 e', 'Kepler-256').
orbita('HD 104985 b', 'HD 104985').
orbita('HATS-10 b', 'HATS-10').
orbita('Kepler-189 b', 'Kepler-189').
orbita('Kepler-691 b', 'Kepler-691').
orbita('Kepler-101 c', 'Kepler-101').
orbita('Kepler-653 c', 'Kepler-653').
orbita('Kepler-1537 b', 'Kepler-1537').
orbita('Kepler-750 c', 'Kepler-750').
orbita('HD 87883 b', 'HD 87883').
orbita('Kepler-520 c', 'Kepler-520').
orbita('WASP-135 b', 'WASP-135').
orbita('Kepler-81 c', 'Kepler-81').
orbita('Kepler-156 c', 'Kepler-156').
orbita('Kepler-127 d', 'Kepler-127').
orbita('Kepler-657 b', 'Kepler-657').
orbita('Kepler-1311 b', 'Kepler-1311').
orbita('HD 10180 g', 'HD 10180').
orbita('Kepler-1092 b', 'Kepler-1092').
orbita('Kepler-1214 b', 'Kepler-1214').
orbita('Kepler-275 c', 'Kepler-275').
orbita('Kepler-482 b', 'Kepler-482').
orbita('Kepler-1495 b', 'Kepler-1495').
orbita('Kepler-201 c', 'Kepler-201').
orbita('WASP-94 B b', 'WASP-94 B').
orbita('Kepler-208 c', 'Kepler-208').
orbita('Kepler-722 c', 'Kepler-722').
orbita('Kepler-1174 b', 'Kepler-1174').
orbita('Kepler-274 b', 'Kepler-274').
orbita('Kepler-581 b', 'Kepler-581').
orbita('Kepler-693 b', 'Kepler-693').
orbita('Kepler-1102 b', 'Kepler-1102').
orbita('Kepler-769 c', 'Kepler-769').
orbita('Kepler-652 b', 'Kepler-652').
orbita('Kepler-420 b', 'Kepler-420').
orbita('HD 66428 b', 'HD 66428').
orbita('HD 52265 b', 'HD 52265').
orbita('HATS-14 b', 'HATS-14').
orbita('Kepler-75 b', 'Kepler-75').
orbita('Kepler-326 c', 'Kepler-326').
orbita('Kepler-554 b', 'Kepler-554').
orbita('Kepler-1294 b', 'Kepler-1294').
orbita('Kepler-249 c', 'Kepler-249').
orbita('Kepler-1282 b', 'Kepler-1282').
orbita('Kepler-740 b', 'Kepler-740').
orbita('Kepler-79 c', 'Kepler-79').
orbita('HD 16417 b', 'HD 16417').
orbita('Kepler-251 c', 'Kepler-251').
orbita('Kepler-15 b', 'Kepler-15').
orbita('HD 205739 b', 'HD 205739').
orbita('Kepler-851 b', 'Kepler-851').
orbita('Kepler-1342 b', 'Kepler-1342').
orbita('Kepler-302 b', 'Kepler-302').
orbita('Kepler-781 b', 'Kepler-781').
orbita('Kepler-317 b', 'Kepler-317').
orbita('Kepler-152 c', 'Kepler-152').
orbita('Kepler-343 b', 'Kepler-343').
orbita('Kepler-1161 b', 'Kepler-1161').
orbita('CoRoT-16 b', 'CoRoT-16').
orbita('HD 216770 b', 'HD 216770').
orbita('HD 136418 b', 'HD 136418').
orbita('Kepler-907 b', 'Kepler-907').
orbita('Kepler-1402 b', 'Kepler-1402').
orbita('Kepler-59 b', 'Kepler-59').
orbita('Kepler-98 b', 'Kepler-98').
orbita('Kepler-192 b', 'Kepler-192').
orbita('beta Pic b', 'beta Pic').
orbita('Kepler-1259 b', 'Kepler-1259').
orbita('Kepler-202 c', 'Kepler-202').
orbita('Kepler-1142 b', 'Kepler-1142').
orbita('GJ 163 d', 'GJ 163').
orbita('Kepler-339 c', 'Kepler-339').
orbita('HD 188015 b', 'HD 188015').
orbita('WASP-59 b', 'WASP-59').
orbita('WASP-54 b', 'WASP-54').
orbita('Kepler-1542 b', 'Kepler-1542').
orbita('HAT-P-8 b', 'HAT-P-8').
orbita('Kepler-446 b', 'Kepler-446').
orbita('Kepler-1533 b', 'Kepler-1533').
orbita('WASP-15 b', 'WASP-15').
orbita('Kepler-425 b', 'Kepler-425').
orbita('HD 10180 d', 'HD 10180').
orbita('Kepler-767 b', 'Kepler-767').
orbita('HD 9446 c', 'HD 9446').
orbita('Kepler-445 b', 'Kepler-445').
orbita('XO-4 b', 'XO-4').
orbita('WASP-48 b', 'WASP-48').
orbita('Kepler-566 b', 'Kepler-566').
orbita('HD 37124 b', 'HD 37124').
orbita('Kepler-89 b', 'Kepler-89').
orbita('WASP-32 b', 'WASP-32').
orbita('Kepler-265 b', 'Kepler-265').
orbita('OGLE-TR-211 b', 'OGLE-TR-211').
orbita('gamma Cep b', 'gamma Cep').
orbita('Kepler-325 b', 'Kepler-325').
orbita('Kepler-11 g', 'Kepler-11').
orbita('Kepler-256 b', 'Kepler-256').
orbita('Kepler-1182 b', 'Kepler-1182').
orbita('Kepler-617 b', 'Kepler-617').
orbita('Kepler-1035 b', 'Kepler-1035').
orbita('HD 1605 c', 'HD 1605').
orbita('GJ 86 b', 'GJ 86').
orbita('Kepler-470 b', 'Kepler-470').
orbita('Kepler-1637 b', 'Kepler-1637').
orbita('Kepler-1346 b', 'Kepler-1346').
orbita('HR 8799 e', 'HR 8799').
orbita('HD 8574 b', 'HD 8574').
orbita('Kepler-269 c', 'Kepler-269').
orbita('MOA-2007-BLG-192L b', 'MOA-2007-BLG-192L').
orbita('Kepler-250 b', 'Kepler-250').
orbita('HD 82886 b', 'HD 82886').
orbita('HD 179949 b', 'HD 179949').
orbita('Kepler-1167 b', 'Kepler-1167').
orbita('HD 2952 b', 'HD 2952').
orbita('Kepler-1063 b', 'Kepler-1063').
orbita('Kepler-169 e', 'Kepler-169').
orbita('MOA-2009-BLG-319L b', 'MOA-2009-BLG-319L').
orbita('Kepler-1340 b', 'Kepler-1340').
orbita('HIP 14810 c', 'HIP 14810').
orbita('Kepler-358 c', 'Kepler-358').
orbita('HD 28678 b', 'HD 28678').
orbita('WASP-56 b', 'WASP-56').
orbita('Kepler-18 c', 'Kepler-18').
orbita('Kepler-215 e', 'Kepler-215').
orbita('Kepler-540 b', 'Kepler-540').
orbita('HATS-6 b', 'HATS-6').
orbita('Kepler-230 c', 'Kepler-230').
orbita('Kepler-739 b', 'Kepler-739').
orbita('Kepler-515 b', 'Kepler-515').
orbita('Kepler-388 b', 'Kepler-388').
orbita('Kepler-107 e', 'Kepler-107').
orbita('Kepler-947 b', 'Kepler-947').
orbita('Kepler-1560 b', 'Kepler-1560').
orbita('Kepler-1230 b', 'Kepler-1230').
orbita('Kepler-923 b', 'Kepler-923').
orbita('CoRoT-8 b', 'CoRoT-8').
orbita('Kepler-723 b', 'Kepler-723').
orbita('Kepler-844 b', 'Kepler-844').
orbita('Kepler-1283 b', 'Kepler-1283').
orbita('Kepler-1430 b', 'Kepler-1430').
orbita('Kepler-401 b', 'Kepler-401').
orbita('Kepler-760 c', 'Kepler-760').
orbita('Kepler-1069 b', 'Kepler-1069').
orbita('Kepler-291 c', 'Kepler-291').
orbita('Kepler-1324 b', 'Kepler-1324').
orbita('CoRoT-20 b', 'CoRoT-20').
orbita('Kepler-292 e', 'Kepler-292').
orbita('HD 96167 b', 'HD 96167').
orbita('HD 43197 b', 'HD 43197').
orbita('Kepler-1388 c', 'Kepler-1388').
orbita('Kepler-912 b', 'Kepler-912').
orbita('Kepler-514 b', 'Kepler-514').
orbita('Kepler-998 b', 'Kepler-998').
orbita('Kepler-1129 b', 'Kepler-1129').
orbita('Kepler-1335 b', 'Kepler-1335').
orbita('HD 37605 c', 'HD 37605').
orbita('Kepler-1601 b', 'Kepler-1601').
orbita('Kepler-659 b', 'Kepler-659').
orbita('Kepler-1332 b', 'Kepler-1332').
orbita('Kepler-81 b', 'Kepler-81').
orbita('Kepler-814 b', 'Kepler-814').
orbita('Kepler-1168 b', 'Kepler-1168').
orbita('Kepler-955 b', 'Kepler-955').
orbita('Kepler-1328 b', 'Kepler-1328').
orbita('HD 183263 b', 'HD 183263').
orbita('Kepler-663 b', 'Kepler-663').
orbita('Kepler-624 b', 'Kepler-624').
orbita('Kepler-1526 b', 'Kepler-1526').
orbita('Kepler-347 c', 'Kepler-347').
orbita('Kepler-699 b', 'Kepler-699').
orbita('Kepler-32 c', 'Kepler-32').
orbita('Kepler-23 b', 'Kepler-23').
orbita('WASP-23 b', 'WASP-23').
orbita('Kepler-594 b', 'Kepler-594').
orbita('11 Com b', '11 Com').
orbita('HD 145377 b', 'HD 145377').
orbita('Kepler-1554 b', 'Kepler-1554').
orbita('Kepler-650 b', 'Kepler-650').
orbita('Kepler-289 d', 'Kepler-289').
orbita('Kepler-1429 b', 'Kepler-1429').
orbita('Kepler-194 c', 'Kepler-194').
orbita('CoRoT-25 b', 'CoRoT-25').
orbita('Kepler-419 c', 'Kepler-419').
orbita('Kepler-332 b', 'Kepler-332').
orbita('omicron CrB b', 'omicron CrB').
orbita('Kepler-229 c', 'Kepler-229').
orbita('Kepler-954 b', 'Kepler-954').
orbita('Kepler-1408 b', 'Kepler-1408').
orbita('Kepler-779 b', 'Kepler-779').
orbita('OGLE-TR-132 b', 'OGLE-TR-132').
orbita('beta Gem b', 'beta Gem').
orbita('Kepler-633 b', 'Kepler-633').
orbita('Kepler-1159 b', 'Kepler-1159').
orbita('Kepler-1443 b', 'Kepler-1443').
orbita('Pr 201 b', 'Pr 201').
orbita('Kepler-541 b', 'Kepler-541').
orbita('Kepler-937 c', 'Kepler-937').
orbita('Kepler-625 c', 'Kepler-625').
orbita('WASP-52 b', 'WASP-52').
orbita('Kepler-953 c', 'Kepler-953').
orbita('Kepler-337 c', 'Kepler-337').
orbita('Kepler-213 b', 'Kepler-213').
orbita('Kepler-386 c', 'Kepler-386').
orbita('Kepler-1186 b', 'Kepler-1186').
orbita('Kepler-927 b', 'Kepler-927').
orbita('Kepler-660 b', 'Kepler-660').
orbita('Kepler-1385 b', 'Kepler-1385').
orbita('47 UMa b', '47 UMa').
orbita('HD 240210 b', 'HD 240210').
orbita('Kepler-1255 b', 'Kepler-1255').
orbita('Kepler-804 c', 'Kepler-804').
orbita('Kepler-906 b', 'Kepler-906').
orbita('Kepler-304 b', 'Kepler-304').
orbita('Kepler-149 d', 'Kepler-149').
orbita('Kepler-1625 b', 'Kepler-1625').
orbita('Kepler-77 b', 'Kepler-77').
orbita('Kepler-719 b', 'Kepler-719').
orbita('HD 109749 b', 'HD 109749').
orbita('Kepler-1455 b', 'Kepler-1455').
orbita('Kepler-775 b', 'Kepler-775').
orbita('HD 45364 c', 'HD 45364').
orbita('Kepler-55 d', 'Kepler-55').
orbita('Kepler-685 b', 'Kepler-685').
orbita('Kepler-500 b', 'Kepler-500').
orbita('Kepler-327 b', 'Kepler-327').
orbita('Kepler-1162 b', 'Kepler-1162').
orbita('Kepler-721 b', 'Kepler-721').
orbita('WASP-50 b', 'WASP-50').
orbita('Kepler-1540 b', 'Kepler-1540').
orbita('HD 11506 c', 'HD 11506').
orbita('Kepler-607 b', 'Kepler-607').
orbita('Kepler-1317 b', 'Kepler-1317').
orbita('Kepler-1507 b', 'Kepler-1507').
orbita('Kepler-1384 b', 'Kepler-1384').
orbita('Kepler-217 d', 'Kepler-217').
orbita('Kepler-1007 b', 'Kepler-1007').
orbita('HD 159243 c', 'HD 159243').
orbita('Kepler-1477 b', 'Kepler-1477').
orbita('Kepler-87 c', 'Kepler-87').
orbita('Kepler-105 c', 'Kepler-105').
orbita('WASP-98 b', 'WASP-98').
orbita('Kepler-1547 b', 'Kepler-1547').
orbita('Kepler-195 c', 'Kepler-195').
orbita('GJ 3470 b', 'GJ 3470').
orbita('K2-22 b', 'K2-22').
orbita('Kepler-696 b', 'Kepler-696').
orbita('Kepler-1133 b', 'Kepler-1133').
orbita('Kepler-290 c', 'Kepler-290').
orbita('Kepler-801 b', 'Kepler-801').
orbita('Kepler-334 d', 'Kepler-334').
orbita('Kepler-1620 b', 'Kepler-1620').
orbita('Kepler-1644 b', 'Kepler-1644').
orbita('Kepler-273 c', 'Kepler-273').
orbita('Kepler-789 b', 'Kepler-789').
orbita('Kepler-625 b', 'Kepler-625').
orbita('eta Cet c', 'eta Cet').
orbita('Kepler-266 b', 'Kepler-266').
orbita('Kepler-641 b', 'Kepler-641').
orbita('HD 96127 b', 'HD 96127').
orbita('Kepler-223 b', 'Kepler-223').
orbita('HD 17156 b', 'HD 17156').
orbita('Kepler-1038 b', 'Kepler-1038').
orbita('Kepler-137 c', 'Kepler-137').
orbita('Kepler-990 b', 'Kepler-990').
orbita('Kepler-116 c', 'Kepler-116').
orbita('Kepler-1137 b', 'Kepler-1137').
orbita('Kepler-117 b', 'Kepler-117').
orbita('Kepler-1264 b', 'Kepler-1264').
orbita('Kepler-513 b', 'Kepler-513').
orbita('HAT-P-44 b', 'HAT-P-44').
orbita('Kepler-381 c', 'Kepler-381').
orbita('HD 16760 b', 'HD 16760').
orbita('HD 30562 b', 'HD 30562').
orbita('Kepler-354 d', 'Kepler-354').
orbita('Kepler-332 c', 'Kepler-332').
orbita('Kepler-46 b', 'Kepler-46').
orbita('Kepler-1215 b', 'Kepler-1215').
orbita('Kepler-920 b', 'Kepler-920').
orbita('WASP-100 b', 'WASP-100').
orbita('Kepler-1086 b', 'Kepler-1086').
orbita('Kepler-1465 b', 'Kepler-1465').
orbita('epsilon CrB b', 'epsilon CrB').
orbita('omicron UMa b', 'omicron UMa').
orbita('Kepler-367 b', 'Kepler-367').
orbita('TrES-2 b', 'TrES-2').
orbita('Kepler-235 d', 'Kepler-235').
orbita('Kepler-282 c', 'Kepler-282').
orbita('Kepler-614 b', 'Kepler-614').
orbita('Kepler-1018 b', 'Kepler-1018').
orbita('Kepler-799 b', 'Kepler-799').
orbita('Kepler-857 b', 'Kepler-857').
orbita('Kepler-979 b', 'Kepler-979').
orbita('HD 11755 b', 'HD 11755').
orbita('HD 102195 b', 'HD 102195').
orbita('Kepler-1320 b', 'Kepler-1320').
orbita('Kepler-432 b', 'Kepler-432').
orbita('Kepler-855 b', 'Kepler-855').
orbita('Kepler-1600 b', 'Kepler-1600').
orbita('Kepler-324 c', 'Kepler-324').
orbita('Kepler-1189 b', 'Kepler-1189').
orbita('HD 75289 b', 'HD 75289').
orbita('Kepler-394 c', 'Kepler-394').
orbita('Kepler-1370 c', 'Kepler-1370').
orbita('Kepler-385 c', 'Kepler-385').
orbita('HD 185269 b', 'HD 185269').
orbita('WASP-7 b', 'WASP-7').
orbita('WASP-41 b', 'WASP-41').
orbita('BD -10 3166 b', 'BD -10 3166').
orbita('HD 190360 b', 'HD 190360').
orbita('HAT-P-13 c', 'HAT-P-13').
orbita('Kepler-304 c', 'Kepler-304').
orbita('Kepler-303 b', 'Kepler-303').
orbita('Kepler-1431 b', 'Kepler-1431').
orbita('Kepler-1163 b', 'Kepler-1163').
orbita('GJ 317 b', 'GJ 317').
orbita('Kepler-526 b', 'Kepler-526').
orbita('Kepler-591 b', 'Kepler-591').
orbita('HD 37605 b', 'HD 37605').
orbita('WASP-44 b', 'WASP-44').
orbita('Kepler-260 c', 'Kepler-260').
orbita('Kepler-602 b', 'Kepler-602').
orbita('Kepler-286 c', 'Kepler-286').
orbita('Kepler-1023 b', 'Kepler-1023').
orbita('Kepler-1362 b', 'Kepler-1362').
orbita('Kepler-708 b', 'Kepler-708').
orbita('CoRoT-12 b', 'CoRoT-12').
orbita('CoRoT-1 b', 'CoRoT-1').
orbita('HD 125612 c', 'HD 125612').
orbita('Kepler-1202 b', 'Kepler-1202').
orbita('Kepler-753 b', 'Kepler-753').
orbita('Kepler-267 b', 'Kepler-267').
orbita('Kepler-112 c', 'Kepler-112').
orbita('Kepler-1134 b', 'Kepler-1134').
orbita('GJ 581 b', 'GJ 581').
orbita('HD 75784 b', 'HD 75784').
orbita('Kepler-622 b', 'Kepler-622').
orbita('Kepler-173 b', 'Kepler-173').
orbita('HD 102117 b', 'HD 102117').
orbita('Kepler-446 c', 'Kepler-446').
orbita('Kepler-301 c', 'Kepler-301').
orbita('Kepler-1114 b', 'Kepler-1114').
orbita('Kepler-1154 b', 'Kepler-1154').
orbita('Kepler-1059 b', 'Kepler-1059').
orbita('HD 189733 b', 'HD 189733').
orbita('HD 108863 b', 'HD 108863').
orbita('Kepler-582 b', 'Kepler-582').
orbita('Kepler-629 b', 'Kepler-629').
orbita('HD 10442 b', 'HD 10442').
orbita('Kepler-404 b', 'Kepler-404').
orbita('Kepler-285 c', 'Kepler-285').
orbita('Kepler-174 c', 'Kepler-174').
orbita('Kepler-286 b', 'Kepler-286').
orbita('Kepler-1213 b', 'Kepler-1213').
orbita('Kepler-867 b', 'Kepler-867').
orbita('Kepler-206 d', 'Kepler-206').
orbita('Kepler-209 c', 'Kepler-209').
orbita('Kepler-1438 b', 'Kepler-1438').
orbita('HD 1502 b', 'HD 1502').
orbita('HD 142022 b', 'HD 142022').
orbita('GJ 3293 c', 'GJ 3293').
orbita('Kepler-1061 b', 'Kepler-1061').
orbita('Kepler-134 c', 'Kepler-134').
orbita('Kepler-126 b', 'Kepler-126').
orbita('Kepler-329 c', 'Kepler-329').
orbita('Kepler-766 b', 'Kepler-766').
orbita('Kepler-131 b', 'Kepler-131').
orbita('WASP-72 b', 'WASP-72').
orbita('Kepler-887 b', 'Kepler-887').
orbita('Kepler-819 b', 'Kepler-819').
orbita('HD 212771 b', 'HD 212771').
orbita('WASP-47 d', 'WASP-47').
orbita('Kepler-135 b', 'Kepler-135').
orbita('HD 134987 b', 'HD 134987').
orbita('Kepler-441 b', 'Kepler-441').
orbita('Kepler-149 b', 'Kepler-149').
orbita('Kepler-1228 b', 'Kepler-1228').
orbita('Kepler-289 c', 'Kepler-289').
orbita('Kepler-956 b', 'Kepler-956').
orbita('HD 187123 c', 'HD 187123').
orbita('HD 101930 b', 'HD 101930').
orbita('Kepler-46 c', 'Kepler-46').
orbita('Kepler-1281 b', 'Kepler-1281').
orbita('Kepler-1640 b', 'Kepler-1640').
orbita('Kepler-174 d', 'Kepler-174').
orbita('Kepler-253 d', 'Kepler-253').
orbita('Kepler-914 b', 'Kepler-914').
orbita('HD 131664 b', 'HD 131664').
orbita('HIP 57050 b', 'HIP 57050').
orbita('GJ 687 b', 'GJ 687').
orbita('Kepler-9 d', 'Kepler-9').
orbita('Kepler-49 b', 'Kepler-49').
orbita('WASP-73 b', 'WASP-73').
orbita('Kepler-1467 b', 'Kepler-1467').
orbita('Kepler-643 b', 'Kepler-643').
orbita('WASP-67 b', 'WASP-67').
orbita('HD 147018 c', 'HD 147018').
orbita('Kepler-1055 b', 'Kepler-1055').
orbita('Kepler-1254 b', 'Kepler-1254').
orbita('Kepler-1329 b', 'Kepler-1329').
orbita('Kepler-531 b', 'Kepler-531').
orbita('Kepler-1261 b', 'Kepler-1261').
orbita('Kepler-32 b', 'Kepler-32').
orbita('Kepler-1521 b', 'Kepler-1521').
orbita('HD 92788 b', 'HD 92788').
orbita('Kepler-83 c', 'Kepler-83').
orbita('Kepler-694 b', 'Kepler-694').
orbita('CoRoT-26 b', 'CoRoT-26').
orbita('HAT-P-12 b', 'HAT-P-12').
orbita('Kepler-178 c', 'Kepler-178').
orbita('Kepler-994 b', 'Kepler-994').
orbita('Kepler-603 c', 'Kepler-603').
orbita('Kepler-82 d', 'Kepler-82').
orbita('Kepler-1417 b', 'Kepler-1417').
orbita('HD 114613 b', 'HD 114613').
orbita('Kepler-130 d', 'Kepler-130').
orbita('HD 154857 b', 'HD 154857').
orbita('Kepler-106 e', 'Kepler-106').
orbita('Kepler-355 b', 'Kepler-355').
orbita('Kepler-220 c', 'Kepler-220').
orbita('Kepler-243 b', 'Kepler-243').
orbita('Kepler-712 b', 'Kepler-712').
orbita('Kepler-297 b', 'Kepler-297').
orbita('Kepler-220 b', 'Kepler-220').
orbita('Kepler-483 b', 'Kepler-483').
orbita('Kepler-245 c', 'Kepler-245').
orbita('Kepler-25 c', 'Kepler-25').
orbita('Kepler-1435 b', 'Kepler-1435').
orbita('Kepler-1405 b', 'Kepler-1405').
orbita('HD 163607 b', 'HD 163607').
orbita('Kepler-1254 c', 'Kepler-1254').
orbita('Kepler-1397 b', 'Kepler-1397').
orbita('HATS-2 b', 'HATS-2').
orbita('HD 19994 b', 'HD 19994').
orbita('Kepler-619 b', 'Kepler-619').
orbita('WASP-29 b', 'WASP-29').
orbita('OGLE-TR-182 b', 'OGLE-TR-182').
orbita('Kepler-1289 b', 'Kepler-1289').
orbita('Kepler-1576 b', 'Kepler-1576').
orbita('HD 85512 b', 'HD 85512').
orbita('HD 106252 b', 'HD 106252').
orbita('Kepler-222 d', 'Kepler-222').
orbita('Kepler-1304 b', 'Kepler-1304').
orbita('Kepler-1546 b', 'Kepler-1546').
orbita('Kepler-394 b', 'Kepler-394').
orbita('Kepler-1250 b', 'Kepler-1250').
orbita('18 Del b', '18 Del').
orbita('Kepler-218 b', 'Kepler-218').
orbita('Kepler-54 c', 'Kepler-54').
orbita('Kepler-33 b', 'Kepler-33').
orbita('Kepler-1437 b', 'Kepler-1437').
orbita('Kepler-391 b', 'Kepler-391').
orbita('Kepler-618 b', 'Kepler-618').
orbita('Kepler-55 e', 'Kepler-55').
orbita('Kepler-34 b', 'Kepler-34').
orbita('Kepler-255 d', 'Kepler-255').
orbita('Kepler-1085 b', 'Kepler-1085').
orbita('Kepler-383 b', 'Kepler-383').
orbita('Kepler-444 f', 'Kepler-444').
orbita('HD 171028 b', 'HD 171028').
orbita('Kepler-336 b', 'Kepler-336').
orbita('WASP-1 b', 'WASP-1').
orbita('XO-5 b', 'XO-5').
orbita('HAT-P-3 b', 'HAT-P-3').
orbita('Kepler-1175 b', 'Kepler-1175').
orbita('Kepler-1421 b', 'Kepler-1421').
orbita('Kepler-1626 b', 'Kepler-1626').
orbita('Kepler-252 c', 'Kepler-252').
orbita('Kepler-718 b', 'Kepler-718').
orbita('Kepler-247 b', 'Kepler-247').
orbita('Kepler-251 e', 'Kepler-251').
orbita('Kepler-1583 b', 'Kepler-1583').
orbita('Kepler-282 b', 'Kepler-282').
orbita('Kepler-354 c', 'Kepler-354').
orbita('Kepler-1529 b', 'Kepler-1529').
orbita('Kepler-1446 b', 'Kepler-1446').
orbita('upsilon And d', 'upsilon And').
orbita('Kepler-1098 b', 'Kepler-1098').
orbita('Kepler-102 b', 'Kepler-102').

%%
%% entidad(T, N, P): Existe una entidad de tipo T,
%%       llamada N, que se encuentra en el planeta P
%% Tipos: humano, alien, animal, bacteria
%%
entidad(animal, 'Tea', 'Kepler-1057 b').
entidad(humano, 'We', 'Kepler-1057 b').
entidad(alien, 'Ae', 'Kepler-1057 b').
entidad(alien, 'Usa', 'Kepler-213 b').
entidad(humano, 'Gionfar', 'Kepler-213 b').
entidad(alien, 'Bi', 'Kepler-213 b').
entidad(bacteria, 'Eagli', 'Kepler-213 b').
entidad(bacteria, 'Agnus', 'Kepler-1259 b').
entidad(humano, 'Ke', 'Kepler-1259 b').
entidad(humano, 'Cabeti', 'Kepler-1259 b').
entidad(animal, 'Sov', 'Kepler-1259 b').
entidad(animal, 'Uve', 'Kepler-1249 b').
entidad(alien, 'Udilm', 'Kepler-1249 b').
entidad(humano, 'Ture', 'Kepler-927 b').
entidad(humano, 'One', 'Kepler-927 b').
entidad(alien, 'De', 'Kepler-927 b').
entidad(animal, 'Ai', 'Kepler-927 b').
entidad(humano, 'Tri', 'Kepler-927 b').
entidad(alien, 'Oe', 'Kepler-927 b').
entidad(alien, 'Jos', 'Kepler-927 b').
entidad(alien, 'Bap', 'HD 142245 b').
entidad(bacteria, 'Ioupio', 'HD 142245 b').
entidad(alien, 'Ark', 'HD 142245 b').
entidad(bacteria, 'Sre', 'HD 142245 b').
entidad(bacteria, 'Ar', 'HD 142245 b').
entidad(humano, 'Eco', 'HD 142245 b').
entidad(humano, 'Ne', 'HD 142245 b').
entidad(bacteria, 'Railo', 'HD 240210 b').
entidad(animal, 'At', 'HD 240210 b').
entidad(humano, 'Cag', 'HD 240210 b').
entidad(animal, 'Onbevo', 'HD 240210 b').
entidad(humano, 'Ido', 'Kepler-425 b').
entidad(alien, 'Vispow', 'Kepler-425 b').
entidad(alien, 'Iogi', 'Kepler-425 b').
entidad(animal, 'Alounopi', 'Kepler-425 b').
entidad(bacteria, 'Oe', 'Kepler-425 b').
entidad(bacteria, 'Sio', 'Kepler-28 b').
entidad(bacteria, 'Sape', 'Kepler-28 b').
entidad(alien, 'Quoy', 'Kepler-28 b').
entidad(alien, 'Ry', 'Kepler-28 b').
entidad(humano, 'Ge', 'Kepler-28 b').
entidad(alien, 'Ow', 'Kepler-28 b').
entidad(animal, 'Ro', 'Kepler-779 b').
entidad(bacteria, 'Eha', 'Kepler-779 b').
entidad(bacteria, 'Gat', 'Kepler-779 b').
entidad(bacteria, 'Oa', 'Kepler-779 b').
entidad(animal, 'By', 'Kepler-779 b').
entidad(animal, 'Fo', 'Kepler-779 b').
entidad(alien, 'Os', 'Kepler-1021 b').
entidad(humano, 'Gy', 'Kepler-1021 b').
entidad(alien, 'Feu', 'Kepler-1021 b').
entidad(animal, 'Squear', 'Kepler-1021 b').
entidad(alien, 'Ai', 'Kepler-1021 b').
entidad(alien, 'Hm', 'Kepler-835 b').
entidad(bacteria, 'Veig', 'Kepler-835 b').
entidad(alien, 'Vin', 'Kepler-835 b').
entidad(animal, 'Oha', 'Kepler-835 b').
entidad(alien, 'Eho', 'Kepler-835 b').
entidad(humano, 'Oupdou', 'Kepler-835 b').
entidad(animal, 'Oeato', 'Kepler-835 b').
entidad(alien, 'Hijau', 'Kepler-676 b').
entidad(animal, 'Cail', 'Kepler-676 b').
entidad(humano, 'Nodorbuirimi', 'Kepler-676 b').
entidad(alien, 'Eodadir', 'Kepler-676 b').
entidad(bacteria, 'Ut', 'Kepler-676 b').
entidad(bacteria, 'Osau', 'Kepler-676 b').
entidad(animal, 'Oweasuno', 'Kepler-291 b').
entidad(humano, 'Ob', 'Kepler-291 b').
entidad(humano, 'Denege', 'Kepler-291 b').
entidad(bacteria, 'Ibow', 'Kepler-725 b').
entidad(animal, 'Duna', 'Kepler-725 b').
entidad(bacteria, 'Unieno', 'Kepler-725 b').
entidad(bacteria, 'Ciorig', 'Kepler-725 b').
entidad(bacteria, 'You', 'Kepler-1251 b').
entidad(animal, 'One', 'Kepler-1251 b').
entidad(alien, 'Amid', 'Kepler-1251 b').
entidad(alien, 'Auxt', 'Kepler-1251 b').
entidad(alien, 'Tio', 'Kepler-1251 b').
entidad(animal, 'Lio', 'Kepler-1251 b').
entidad(animal, 'Ohex', 'Kepler-226 c').
entidad(humano, 'Etay', 'Kepler-226 c').
entidad(bacteria, 'Meki', 'Kepler-226 c').
entidad(alien, 'Leo', 'Kepler-226 c').
entidad(alien, 'Sar', 'Kepler-226 c').
entidad(alien, 'Atusynieu', 'HD 10697 b').
entidad(alien, 'Gue', 'HD 10697 b').
entidad(bacteria, 'Ala', 'HD 10697 b').
entidad(bacteria, 'Inelds', 'HD 10697 b').
entidad(bacteria, 'Oaky', 'HD 10697 b').
entidad(alien, 'Elol', 'HD 10697 b').
entidad(bacteria, 'Heo', 'HD 10697 b').
entidad(alien, 'Kenu', 'Kepler-578 b').
entidad(alien, 'Di', 'Kepler-578 b').
entidad(bacteria, 'Pupri', 'Kepler-578 b').
entidad(bacteria, 'Be', 'Kepler-578 b').
entidad(humano, 'Gheo', 'Kepler-578 b').
entidad(alien, 'Oyo', 'Kepler-578 b').
entidad(bacteria, 'Oge', 'Kepler-443 b').
entidad(animal, 'Ecue', 'Kepler-443 b').
entidad(humano, 'Epocag', 'Kepler-443 b').
entidad(bacteria, 'Not', 'Kepler-443 b').
entidad(humano, 'Sai', 'Kepler-443 b').
entidad(animal, 'Uh', 'Kepler-443 b').
entidad(animal, 'Itanuca', 'Kepler-443 b').
entidad(animal, 'Oea', 'Kepler-443 b').
entidad(animal, 'Mane', 'Kepler-443 b').
entidad(animal, 'Usie', 'Kepler-23 c').
entidad(bacteria, 'Eo', 'Kepler-23 c').
entidad(humano, 'Eu', 'Kepler-23 c').
entidad(bacteria, 'Eas', 'Kepler-23 c').
entidad(humano, 'Nui', 'Kepler-23 c').
entidad(humano, 'Rido', 'Kepler-23 c').
entidad(animal, 'Il', 'Kepler-23 c').
entidad(bacteria, 'Li', 'Kepler-23 c').
entidad(alien, 'Yine', 'Kepler-23 c').
entidad(bacteria, 'Tan', 'HD 142415 b').
entidad(alien, 'Yinia', 'HD 142415 b').
entidad(animal, 'Obaphim', 'HD 142415 b').
entidad(alien, 'Egoi', 'HD 142415 b').
entidad(alien, 'Obut', 'HD 142415 b').
entidad(alien, 'Aem', 'Kepler-54 c').
entidad(alien, 'Ag', 'Kepler-54 c').
entidad(alien, 'Edaf', 'Kepler-54 c').
entidad(bacteria, 'Oc', 'Kepler-54 c').
entidad(alien, 'Isic', 'Kepler-54 c').
entidad(alien, 'El', 'Kepler-54 c').
entidad(bacteria, 'Iruglu', 'Kepler-54 c').
entidad(bacteria, 'In', 'Kepler-54 c').
entidad(animal, 'Egei', 'Kepler-54 c').
entidad(alien, 'Pauge', 'Kepler-54 c').
entidad(alien, 'Eonaw', 'Kepler-54 c').
entidad(humano, 'Ogiedeo', 'Kepler-205 c').
entidad(bacteria, 'Ay', 'Kepler-205 c').
entidad(alien, 'Wei', 'Kepler-205 c').
entidad(bacteria, 'Egimau', 'Kepler-205 c').
entidad(alien, 'Opo', 'Kepler-144 b').
entidad(alien, 'Hip', 'Kepler-144 b').
entidad(alien, 'Poe', 'Kepler-144 b').
entidad(animal, 'Guar', 'Kepler-144 b').
entidad(animal, 'An', 'Kepler-144 b').
entidad(bacteria, 'Gam', 'Kepler-386 c').
entidad(alien, 'Ps', 'Kepler-386 c').
entidad(humano, 'Eguipai', 'Kepler-386 c').
entidad(alien, 'Za', 'Kepler-386 c').
entidad(bacteria, 'Ogue', 'Kepler-386 c').
entidad(alien, 'Soa', 'Kepler-386 c').
entidad(bacteria, 'En', 'Kepler-386 c').
entidad(humano, 'Egie', 'Kepler-386 c').
entidad(humano, 'Ul', 'Kepler-386 c').
entidad(alien, 'Etomob', 'Kepler-386 c').
entidad(humano, 'Us', 'Kepler-386 c').
entidad(bacteria, 'Wha', 'Kepler-386 c').
entidad(bacteria, 'Owe', 'HD 221287 b').
entidad(animal, 'Os', 'HD 221287 b').
entidad(animal, 'Ew', 'HD 221287 b').
entidad(bacteria, 'Eor', 'HD 221287 b').
entidad(alien, 'Gli', 'HD 221287 b').
entidad(humano, 'Pas', 'HD 221287 b').
entidad(humano, 'Ek', 'HD 221287 b').
entidad(alien, 'Agoa', 'HD 221287 b').
entidad(bacteria, 'Te', 'HD 221287 b').
entidad(alien, 'Maxi', 'HD 221287 b').
entidad(bacteria, 'Usa', 'HD 221287 b').
entidad(humano, 'Gotsil', 'HD 102117 b').
entidad(animal, 'Cuda', 'HD 102117 b').
entidad(animal, 'Tedi', 'HD 102117 b').
entidad(bacteria, 'Una', 'HD 102117 b').
entidad(alien, 'Oga', 'HD 102117 b').
entidad(animal, 'Eci', 'HD 66428 b').
entidad(alien, 'Spoedo', 'HD 66428 b').
entidad(humano, 'Spoe', 'HD 66428 b').
entidad(alien, 'Pows', 'HD 66428 b').
entidad(alien, 'Iai', 'HD 66428 b').
entidad(humano, 'Fe', 'HD 66428 b').
entidad(animal, 'Ebox', 'HD 66428 b').
entidad(animal, 'Of', 'Kepler-1371 c').
entidad(humano, 'Po', 'Kepler-1371 c').
entidad(bacteria, 'Siximie', 'Kepler-1371 c').
entidad(bacteria, 'Ulotpo', 'HAT-P-6 b').
entidad(alien, 'Bibergoa', 'HAT-P-6 b').
entidad(animal, 'No', 'HAT-P-6 b').
entidad(bacteria, 'Iap', 'HAT-P-6 b').
entidad(animal, 'As', 'HAT-P-6 b').
entidad(bacteria, 'Nemoet', 'Kepler-1120 b').
entidad(humano, 'Fege', 'Kepler-326 b').
entidad(bacteria, 'Zo', 'Kepler-326 b').
entidad(bacteria, 'Code', 'Kepler-326 b').
entidad(bacteria, 'Ifs', 'Kepler-326 b').
entidad(bacteria, 'Do', 'Kepler-326 b').
entidad(alien, 'Ni', 'Kepler-326 b').
entidad(bacteria, 'Oubau', 'Kepler-326 b').
entidad(alien, 'Ib', 'Kepler-326 b').
entidad(bacteria, 'Ebia', 'Kepler-326 b').
entidad(bacteria, 'Ofetahopio', 'Kepler-326 b').
entidad(bacteria, 'Nubei', 'Kepler-326 b').
entidad(humano, 'Wa', 'Kepler-326 b').
entidad(animal, 'Ach', 'HD 209458 b').
entidad(animal, 'Oes', 'HD 209458 b').
entidad(animal, 'Alou', 'HD 209458 b').
entidad(animal, 'Mb', 'HD 209458 b').
entidad(alien, 'La', 'HD 209458 b').
entidad(alien, 'Na', 'HD 209458 b').
entidad(alien, 'Aemakien', 'HD 224693 b').
entidad(animal, 'Aeoced', 'HD 224693 b').
entidad(animal, 'Racau', 'HD 224693 b').
entidad(bacteria, 'Aya', 'HD 224693 b').
entidad(bacteria, 'Bas', 'HD 224693 b').
entidad(bacteria, 'Poci', 'HD 222582 b').
entidad(animal, 'Etwi', 'Kepler-156 b').
entidad(alien, 'Ad', 'Kepler-156 b').
entidad(animal, 'Pa', 'Kepler-156 b').
entidad(humano, 'Sumbia', 'Kepler-1569 b').
entidad(animal, 'Ken', 'Kepler-1569 b').
entidad(animal, 'Eusoi', 'Kepler-1569 b').
entidad(bacteria, 'Ivou', 'Kepler-1569 b').
entidad(alien, 'Vic', 'Kepler-1569 b').
entidad(animal, 'Ord', 'Kepler-1569 b').
entidad(animal, 'Ekiscoed', 'Kepler-1569 b').
entidad(humano, 'Tesuiraug', 'Kepler-1569 b').
entidad(bacteria, 'Otik', 'Kepler-1569 b').
entidad(humano, 'Yr', 'Kepler-1569 b').
entidad(animal, 'Asici', 'Kepler-1569 b').
entidad(alien, 'Imi', 'Kepler-1569 b').
entidad(humano, 'Eus', 'Kepler-651 b').
entidad(humano, 'Lunimie', 'Kepler-651 b').
entidad(humano, 'Dyn', 'Kepler-651 b').
entidad(animal, 'Vano', 'Kepler-651 b').
entidad(animal, 'Adotu', 'Kepler-651 b').
entidad(bacteria, 'Eh', 'Kepler-1304 b').
entidad(animal, 'Eog', 'Kepler-1304 b').
entidad(humano, 'Blag', 'Kepler-1304 b').
entidad(animal, 'Lel', 'Kepler-1304 b').
entidad(alien, 'Tiorsa', 'Kepler-1304 b').
entidad(animal, 'Eag', 'Kepler-1304 b').
entidad(bacteria, 'Olio', 'Kepler-1304 b').
entidad(bacteria, 'Enaup', 'Kepler-1304 b').
entidad(bacteria, 'Oado', 'Kepler-1304 b').
entidad(animal, 'Deo', 'Kepler-1304 b').
entidad(bacteria, 'Epa', 'Kepler-1304 b').
entidad(alien, 'Ir', 'Kepler-1304 b').
entidad(alien, 'Oha', 'Kepler-1210 b').
entidad(alien, 'Fiaid', 'Kepler-1210 b').
entidad(bacteria, 'Alu', 'Kepler-1210 b').
entidad(alien, 'Ya', 'Kepler-1210 b').
entidad(bacteria, 'Octu', 'Kepler-1210 b').
entidad(bacteria, 'Pefu', 'Kepler-1210 b').
entidad(bacteria, 'Noev', 'Kepler-1210 b').
entidad(alien, 'Aule', 'Kepler-1210 b').
entidad(humano, 'Vaum', 'Kepler-1210 b').
entidad(bacteria, 'Ofeur', 'Kepler-250 d').
entidad(alien, 'Cuinoi', 'Kepler-250 d').
entidad(bacteria, 'Is', 'Kepler-250 d').
entidad(alien, 'Ilimi', 'Kepler-250 d').
entidad(alien, 'Re', 'Kepler-250 d').
entidad(bacteria, 'Sag', 'Kepler-250 d').
entidad(bacteria, 'Adwa', 'Kepler-1085 b').
entidad(bacteria, 'Enetea', 'Kepler-1085 b').
entidad(bacteria, 'Lim', 'Kepler-1085 b').
entidad(animal, 'Oat', 'Kepler-1085 b').
entidad(alien, 'Ewana', 'Kepler-1085 b').
entidad(alien, 'Cei', 'Kepler-1085 b').
entidad(humano, 'Bap', 'Kepler-1085 b').
entidad(alien, 'Ed', 'Kepler-801 b').
entidad(animal, 'Ratui', 'Kepler-801 b').
entidad(bacteria, 'Lel', 'Kepler-801 b').
entidad(animal, 'Tiorsa', 'Kepler-801 b').
entidad(animal, 'Eag', 'Kepler-801 b').
entidad(animal, 'Olio', 'Kepler-801 b').
entidad(alien, 'Enaup', 'Kepler-653 b').
entidad(animal, 'Oado', 'Kepler-653 b').
entidad(animal, 'Deo', 'Kepler-653 b').
entidad(alien, 'Epa', 'Kepler-653 b').
entidad(humano, 'Ir', 'Kepler-653 b').
entidad(bacteria, 'Oha', 'Kepler-653 b').
entidad(alien, 'Fiaid', 'Kepler-653 b').
entidad(alien, 'Alu', 'Kepler-653 b').
entidad(animal, 'Ya', 'Kepler-653 b').
entidad(animal, 'Octu', 'Kepler-653 b').
entidad(animal, 'Pefu', 'Kepler-653 b').
entidad(alien, 'Noev', 'Kepler-653 b').
entidad(alien, 'Aule', 'Kepler-385 c').
entidad(alien, 'Vaum', 'Kepler-385 c').
entidad(bacteria, 'Ofeur', 'Kepler-385 c').
entidad(bacteria, 'Cuinoi', 'Kepler-385 c').
entidad(animal, 'Is', 'Kepler-385 c').
entidad(alien, 'Ilimi', 'Kepler-385 c').
entidad(bacteria, 'Re', 'Kepler-385 c').
entidad(bacteria, 'Sag', 'Kepler-1047 c').
entidad(bacteria, 'Adwa', 'Kepler-1047 c').
entidad(bacteria, 'Enetea', 'Kepler-1047 c').
entidad(alien, 'Lim', 'Kepler-1047 c').
entidad(humano, 'Oat', 'Kepler-1047 c').
entidad(alien, 'Ewana', 'Kepler-1047 c').
entidad(bacteria, 'Cei', 'HD 12661 b').
entidad(bacteria, 'Bap', 'HD 12661 b').
entidad(bacteria, 'Ed', 'HD 12661 b').
entidad(bacteria, 'Ratui', 'HD 12661 b').
entidad(animal, 'Ino', 'HD 12661 b').
entidad(bacteria, 'Erb', 'Kepler-770 d').
entidad(humano, 'Igo', 'Kepler-770 d').
entidad(animal, 'Noct', 'Kepler-770 d').
entidad(alien, 'Dadou', 'Kepler-770 d').
entidad(alien, 'Debole', 'Kepler-50 c').
entidad(alien, 'Nipe', 'Kepler-1516 b').
entidad(humano, 'Oze', 'Kepler-1516 b').
entidad(bacteria, 'Er', 'Kepler-1516 b').
entidad(animal, 'Gn', 'Kepler-1516 b').
entidad(bacteria, 'Met', 'Kepler-1516 b').
entidad(alien, 'Zea', 'Kepler-1516 b').
entidad(bacteria, 'Dodegei', 'Kepler-1516 b').
entidad(animal, 'Or', 'Kepler-1516 b').
entidad(bacteria, 'Efou', 'Kepler-1516 b').
entidad(bacteria, 'Nic', 'Kepler-545 b').
entidad(bacteria, 'Idazi', 'Kepler-545 b').
entidad(bacteria, 'Vala', 'Kepler-545 b').
entidad(alien, 'Nadu', 'Kepler-545 b').
entidad(animal, 'Owri', 'Kepler-545 b').
entidad(alien, 'Emai', 'Kepler-545 b').
entidad(alien, 'Oan', 'Kepler-545 b').
entidad(bacteria, 'Dwou', 'Kepler-109 c').
entidad(alien, 'Ocur', 'Kepler-109 c').
entidad(bacteria, 'Enoc', 'Kepler-109 c').
entidad(bacteria, 'Jug', 'Kepler-109 c').
entidad(bacteria, 'Rep', 'Kepler-109 c').
entidad(humano, 'Akicielbiv', 'Kepler-109 c').
entidad(humano, 'Wi', 'Kepler-109 c').
entidad(bacteria, 'Aluxua', 'Kepler-109 c').
entidad(alien, 'Oyo', 'Kepler-109 c').
entidad(animal, 'Ghoe', 'Kepler-109 c').
entidad(animal, 'Zedeo', 'Kepler-250 b').
entidad(humano, 'Oul', 'Kepler-250 b').
entidad(bacteria, 'Up', 'Kepler-250 b').
entidad(alien, 'Eoso', 'Kepler-250 b').
entidad(bacteria, 'Pecat', 'Kepler-714 b').
entidad(bacteria, 'Lule', 'Kepler-714 b').
entidad(alien, 'Auma', 'Kepler-714 b').
entidad(animal, 'Ewitoinoelo', 'Kepler-714 b').
entidad(alien, 'Saut', 'K2-22 b').
entidad(animal, 'Seto', 'K2-22 b').
entidad(animal, 'Doed', 'K2-22 b').
entidad(bacteria, 'Odu', 'K2-22 b').
entidad(bacteria, 'Otoude', 'K2-22 b').
entidad(alien, 'Isove', 'Kepler-84 d').
entidad(bacteria, 'Edu', 'Kepler-84 d').
entidad(animal, 'Hy', 'KIC 11442793 e').
entidad(alien, 'Tram', 'KIC 11442793 e').
entidad(alien, 'Ecaurfug', 'KIC 11442793 e').
entidad(alien, 'Enu', 'KIC 11442793 e').
entidad(animal, 'Ghaw', 'KIC 11442793 e').
entidad(bacteria, 'Otaca', 'WASP-39 b').
entidad(bacteria, 'Mbisa', 'Kepler-81 d').
entidad(alien, 'Decy', 'Kepler-81 d').
entidad(animal, 'Obum', 'Kepler-81 d').
entidad(alien, 'Gremb', 'Kepler-81 d').
entidad(humano, 'Poenid', 'Kepler-81 d').
entidad(alien, 'Uma', 'Kepler-81 d').
entidad(animal, 'Wie', 'Kepler-81 d').
entidad(animal, 'Expe', 'Kepler-81 d').
entidad(bacteria, 'Iards', 'Kepler-81 d').
entidad(animal, 'Foi', 'Kepler-81 d').
entidad(bacteria, 'Onoea', 'Kepler-1030 b').
entidad(alien, 'Dog', 'Kepler-1030 b').
entidad(bacteria, 'Opopma', 'Kepler-462 b').
entidad(alien, 'Jur', 'Kepler-462 b').
entidad(animal, 'Oiciosoeu', 'Kepler-462 b').
entidad(alien, 'Rai', 'Kepler-462 b').
entidad(alien, 'Ofabi', 'Kepler-462 b').
entidad(bacteria, 'Beit', 'Kepler-462 b').
entidad(alien, 'Oise', 'Kepler-462 b').
entidad(alien, 'Otanc', 'Kepler-462 b').
entidad(humano, 'Nueung', 'Kepler-462 b').
entidad(bacteria, 'Jayelp', 'Kepler-462 b').
entidad(bacteria, 'Kwasop', 'Kepler-462 b').
entidad(bacteria, 'Emo', 'HD 156411 b').
entidad(animal, 'Ch', 'HD 156411 b').
entidad(alien, 'Yed', 'HD 156411 b').
entidad(alien, 'Piz', 'HD 156411 b').
entidad(humano, 'Vaci', 'HD 156411 b').
entidad(bacteria, 'Halbalans', 'HD 156411 b').
entidad(alien, 'Neoca', 'HD 156411 b').
entidad(alien, 'Tugeigute', 'HD 156411 b').
entidad(bacteria, 'Lug', 'Kepler-1530 c').
entidad(animal, 'Ica', 'Kepler-1530 c').
entidad(alien, 'Amau', 'Kepler-1530 c').
entidad(humano, 'Ioldu', 'Kepler-1530 c').
entidad(animal, 'Pep', 'Kepler-1530 c').
entidad(animal, 'Otut', 'Kepler-1530 c').
entidad(bacteria, 'Aeont', 'Kepler-1530 c').
entidad(bacteria, 'Efoe', 'Kepler-897 b').
entidad(animal, 'Ogo', 'Kepler-897 b').
entidad(animal, 'Uvenlira', 'Kepler-897 b').
entidad(alien, 'Ori', 'Kepler-897 b').
entidad(alien, 'Fumiage', 'Kepler-897 b').
entidad(alien, 'Aso', 'KOI-4427 b').
entidad(alien, 'Ton', 'Kepler-754 b').
entidad(humano, 'Oal', 'Kepler-754 b').
entidad(alien, 'Mumb', 'Kepler-754 b').
entidad(bacteria, 'Oac', 'Kepler-754 b').
entidad(alien, 'Aner', 'Kepler-754 b').
entidad(bacteria, 'Ceds', '61 Vir b').
entidad(animal, 'Ita', '61 Vir b').
entidad(humano, 'Iri', '61 Vir b').
entidad(humano, 'Jogia', '61 Vir b').
entidad(alien, 'Nualgisuba', '61 Vir b').
entidad(alien, 'Plofib', 'Kepler-239 b').
entidad(bacteria, 'Bes', 'Kepler-239 b').
entidad(bacteria, 'Gigeareos', 'Kepler-239 b').
entidad(humano, 'Pim', 'Kepler-239 b').
entidad(animal, 'Unif', 'Kepler-239 b').
entidad(bacteria, 'Olibsidou', 'Kepler-239 b').
entidad(animal, 'Cio', 'Kepler-239 b').
entidad(animal, 'Sisa', 'Kepler-239 b').
entidad(alien, 'Noi', 'Kepler-239 b').
entidad(bacteria, 'Eigob', 'Kepler-239 b').
entidad(animal, 'Cla', 'Kepler-239 b').
entidad(alien, 'Lake', 'Kepler-239 b').
entidad(animal, 'Tsive', 'MOA-2009-BLG-266L b').
entidad(humano, 'Ril', 'MOA-2009-BLG-266L b').
entidad(alien, 'Udiclui', 'MOA-2009-BLG-266L b').
entidad(bacteria, 'Ple', 'MOA-2009-BLG-266L b').
entidad(humano, 'Egouti', 'MOA-2009-BLG-266L b').
entidad(alien, 'Ninef', 'MOA-2009-BLG-266L b').
entidad(bacteria, 'Iari', 'Kepler-1192 b').
entidad(bacteria, 'Omer', 'Kepler-1192 b').
entidad(humano, 'Drodag', 'Kepler-1192 b').
entidad(humano, 'Awel', 'Kepler-1192 b').
entidad(bacteria, 'Ozo', 'Kepler-1192 b').
entidad(humano, 'Douco', 'Kepler-1192 b').
entidad(alien, 'Unerwedoe', 'Kepler-1192 b').
entidad(animal, 'View', 'Kepler-1192 b').
entidad(animal, 'Ais', 'Kepler-1192 b').
entidad(animal, 'Naly', 'Kepler-1192 b').
entidad(alien, 'Coe', 'Kepler-1192 b').
entidad(bacteria, 'Aqueule', 'Kepler-1496 b').
entidad(bacteria, 'Riso', 'Kepler-1496 b').
entidad(bacteria, 'Acak', 'Kepler-1496 b').
entidad(alien, 'Dis', 'Kepler-1496 b').
entidad(humano, 'Oar', 'Kepler-1496 b').
entidad(bacteria, 'Etok', 'Kepler-1496 b').
entidad(animal, 'Fer', 'Kepler-186 b').
entidad(bacteria, 'Spol', 'Kepler-186 b').
entidad(bacteria, 'Ereo', 'Kepler-186 b').
entidad(animal, 'Apa', 'Kepler-186 b').
entidad(bacteria, 'Aigutic', 'Kepler-186 b').
entidad(animal, 'Ito', 'Kepler-186 b').
entidad(animal, 'Sele', 'Kepler-186 b').
entidad(humano, 'Oen', 'Kepler-186 b').
entidad(alien, 'Goi', 'Kepler-186 b').
entidad(bacteria, 'Hucalia', 'Kepler-186 b').
entidad(bacteria, 'Qua', 'Kepler-877 b').
entidad(bacteria, 'Baiv', 'Kepler-877 b').
entidad(animal, 'Irkila', 'Kepler-877 b').
entidad(bacteria, 'Amu', 'Kepler-877 b').
entidad(bacteria, 'Hiter', 'Kepler-877 b').
entidad(bacteria, 'Oirog', 'Kepler-877 b').
entidad(humano, 'Gich', 'Kepler-1282 b').
entidad(alien, 'Onta', 'Kepler-1282 b').
entidad(bacteria, 'Iat', 'Kepler-1282 b').
entidad(bacteria, 'Cab', 'Kepler-1282 b').
entidad(humano, 'Egesex', 'Kepler-1282 b').
entidad(humano, 'Eak', 'Kepler-880 b').
entidad(animal, 'Eiva', 'Kepler-880 b').
entidad(bacteria, 'Obt', 'Kepler-880 b').
entidad(alien, 'Saco', 'Kepler-880 b').
entidad(bacteria, 'Irfa', 'Kepler-880 b').
entidad(alien, 'Sala', 'Kepler-880 b').
entidad(humano, 'Raph', 'Kepler-880 b').
entidad(alien, 'Moir', 'Kepler-880 b').
entidad(alien, 'Ene', 'Kepler-880 b').
entidad(animal, 'Iven', 'Kepler-880 b').
entidad(bacteria, 'Poeurbi', 'Kepler-880 b').
entidad(alien, 'Ziel', 'Kepler-880 b').
entidad(bacteria, 'Oenraza', 'Kepler-234 c').
entidad(bacteria, 'Fla', 'Kepler-234 c').
entidad(humano, 'Dio', 'Kepler-234 c').
entidad(alien, 'Osug', 'Kepler-234 c').
entidad(humano, 'Ero', 'Kepler-485 b').
entidad(alien, 'Eoseurouro', 'Kepler-485 b').
entidad(bacteria, 'Ify', 'Kepler-485 b').
entidad(animal, 'Upo', 'Kepler-485 b').
entidad(alien, 'Steo', 'Kepler-485 b').
entidad(bacteria, 'Amo', 'Kepler-485 b').
entidad(bacteria, 'Ogei', 'PSR B1257+12 C').
entidad(bacteria, 'Ogus', 'PSR B1257+12 C').
entidad(bacteria, 'Ayenip', 'PSR B1257+12 C').
entidad(bacteria, 'Eha', 'PSR B1257+12 C').
entidad(alien, 'Ube', 'PSR B1257+12 C').
entidad(bacteria, 'Exe', 'PSR B1257+12 C').
entidad(alien, 'Adrituane', 'PSR B1257+12 C').
entidad(alien, 'Usaicupoa', 'WASP-59 b').
entidad(alien, 'Hafec', 'WASP-59 b').
entidad(alien, 'Awle', 'WASP-59 b').
entidad(bacteria, 'Eisovoya', 'WASP-59 b').
entidad(alien, 'Fambi', 'WASP-59 b').
entidad(animal, 'Doea', 'Kepler-117 b').
entidad(humano, 'Sog', 'Kepler-117 b').
entidad(alien, 'Kabs', 'Kepler-117 b').
entidad(animal, 'Whau', 'Kepler-117 b').
entidad(alien, 'Vas', 'Kepler-117 b').
entidad(bacteria, 'Toe', 'Kepler-117 b').
entidad(alien, 'Fin', 'Kepler-117 b').
entidad(bacteria, 'Fiaigeh', 'Kepler-1391 b').
entidad(bacteria, 'Eimea', 'Kepler-1391 b').
entidad(humano, 'Sh', 'Kepler-1391 b').
entidad(bacteria, 'Ugil', 'Kepler-1391 b').
entidad(bacteria, 'Azeab', 'Kepler-1391 b').
entidad(bacteria, 'Nu', 'Kepler-1369 b').
entidad(bacteria, 'Olo', 'Kepler-1369 b').
entidad(animal, 'Use', 'Kepler-1369 b').
entidad(bacteria, 'Belain', 'Kepler-1369 b').
entidad(animal, 'Etom', 'Kepler-1369 b').
entidad(bacteria, 'Itiec', 'Kepler-1369 b').
entidad(bacteria, 'Afeim', 'Kepler-142 d').
entidad(alien, 'Afea', 'Kepler-142 d').
entidad(bacteria, 'Ibew', 'Kepler-142 d').
entidad(bacteria, 'Ake', 'Kepler-142 d').
entidad(alien, 'Diz', 'Kepler-142 d').
entidad(bacteria, 'Veli', 'Kepler-142 d').
entidad(bacteria, 'Och', 'Kepler-626 b').
entidad(bacteria, 'Viro', 'Kepler-626 b').
entidad(alien, 'Pulu', 'Kepler-626 b').
entidad(animal, 'Porlam', 'HD 108147 b').
entidad(alien, 'Fus', 'Kepler-864 b').
entidad(alien, 'Nob', 'Kepler-864 b').
entidad(humano, 'Oic', 'Kepler-864 b').
entidad(humano, 'Joralol', 'Kepler-864 b').
entidad(humano, 'Unbi', 'Kepler-864 b').
entidad(humano, 'Cem', 'Kepler-864 b').
entidad(bacteria, 'Ouseat', 'Kepler-864 b').
entidad(bacteria, 'Apren', 'Kepler-864 b').
entidad(bacteria, 'Tigeimanu', 'Kepler-864 b').
entidad(humano, 'Popum', 'Kepler-864 b').
entidad(animal, 'Ocio', 'Kepler-864 b').
entidad(alien, 'Anth', 'Kepler-123 b').
entidad(bacteria, 'Didumurgatic', 'Kepler-123 b').
entidad(animal, 'Eis', 'Kepler-123 b').
entidad(humano, 'Osiarhe', 'Kepler-47 c').
entidad(bacteria, 'Prana', 'Kepler-47 c').
entidad(alien, 'Ehoi', 'Kepler-47 c').
entidad(alien, 'Cua', 'Kepler-47 c').
entidad(bacteria, 'Halurs', 'Kepler-897 b').
entidad(bacteria, 'Tuefaribs', 'Kepler-897 b').
entidad(alien, 'Obs', 'Kepler-897 b').
entidad(humano, 'Aul', 'Kepler-897 b').
entidad(humano, 'Ifeape', 'Kepler-897 b').
entidad(animal, 'Oce', 'Kepler-897 b').
entidad(bacteria, 'Arice', 'Kepler-37 c').
entidad(humano, 'Srum', 'Kepler-37 c').
entidad(animal, 'Nus', 'Kepler-37 c').
entidad(bacteria, 'Ami', 'Kepler-37 c').
entidad(humano, 'Cefetog', 'Kepler-37 c').
entidad(humano, 'Ayo', 'Kepler-37 c').
entidad(alien, 'Upiadiva', 'Kepler-37 c').
entidad(bacteria, 'Rio', 'Kepler-37 c').
entidad(humano, 'Opirwe', 'Kepler-37 c').
entidad(bacteria, 'Nda', 'Kepler-37 c').
entidad(alien, 'Nuceilo', 'Kepler-37 c').
entidad(humano, 'Wourot', 'HAT-P-37 b').
entidad(humano, 'Rworeron', 'HAT-P-37 b').
entidad(animal, 'Ainciv', 'HAT-P-37 b').
entidad(animal, 'Uro', 'HAT-P-37 b').
entidad(humano, 'Tampos', 'HAT-P-37 b').
entidad(alien, 'Ate', 'HAT-P-37 b').
entidad(bacteria, 'Nd', 'HAT-P-37 b').
entidad(alien, 'Mirusa', 'HAT-P-37 b').
entidad(bacteria, 'Hoei', 'HAT-P-37 b').
entidad(bacteria, 'Clobs', 'HAT-P-37 b').
entidad(bacteria, 'Pri', 'Kepler-583 b').
entidad(humano, 'Nie', 'Kepler-583 b').
entidad(animal, 'Pat', 'Kepler-583 b').
entidad(animal, 'Finudiusa', 'Kepler-583 b').
entidad(humano, 'Stau', 'Kepler-583 b').
entidad(bacteria, 'Dibido', 'Kepler-583 b').
entidad(alien, 'Oke', 'Kepler-583 b').
entidad(bacteria, 'Irou', 'HD 108863 b').
entidad(humano, 'Badi', 'HD 108863 b').
entidad(alien, 'Ern', 'HD 108863 b').
entidad(alien, 'Oiroa', 'HD 108863 b').
entidad(bacteria, 'Oteu', 'HD 108863 b').
entidad(alien, 'Eud', 'HD 108863 b').
entidad(bacteria, 'Auld', 'Kepler-49 e').
entidad(alien, 'Asen', 'Kepler-49 e').
entidad(alien, 'Upro', 'Kepler-49 e').
entidad(bacteria, 'Agamit', 'Kepler-49 e').
entidad(bacteria, 'Umea', 'Kepler-49 e').
entidad(animal, 'Iaboyalt', 'Kepler-49 e').
entidad(alien, 'Eunbunietak', 'Kepler-1489 b').
entidad(humano, 'Umob', 'Kepler-1489 b').
entidad(animal, 'Hies', 'Kepler-1489 b').
entidad(humano, 'Hes', 'Kepler-1489 b').
entidad(humano, 'Eng', 'Kepler-1489 b').
entidad(humano, 'Jereou', 'Kepler-974 b').
entidad(animal, 'Onkit', 'Kepler-974 b').
entidad(alien, 'Omoct', 'Kepler-974 b').
entidad(humano, 'Derolu', 'Kepler-974 b').
entidad(alien, 'Lamo', 'Kepler-974 b').
entidad(animal, 'Roms', 'Kepler-246 c').
entidad(alien, 'Psia', 'Kepler-246 c').
entidad(alien, 'Emi', 'Kepler-246 c').
entidad(bacteria, 'Ream', 'Kepler-246 c').
entidad(animal, 'Apenec', 'Kepler-246 c').
entidad(animal, 'Pae', 'Kepler-793 b').
entidad(alien, 'Obo', 'Kepler-793 b').
entidad(bacteria, 'Ulce', 'Kepler-793 b').
entidad(animal, 'Gosoad', 'Kepler-793 b').
entidad(alien, 'Uscef', 'WASP-6 b').
entidad(bacteria, 'Ido', 'WASP-6 b').
entidad(humano, 'Yra', 'Kepler-391 c').
entidad(alien, 'Eringog', 'Kepler-391 c').
entidad(bacteria, 'Toi', 'Kepler-391 c').
entidad(humano, 'Pogo', 'Kepler-391 c').
entidad(animal, 'Fueralicim', 'Kepler-391 c').
entidad(bacteria, 'Ibe', 'Kepler-391 c').
entidad(bacteria, 'Ugei', 'Kepler-391 c').
entidad(humano, 'Gau', 'Kepler-374 b').
entidad(animal, 'Elel', 'Kepler-374 b').
entidad(alien, 'Hapoa', 'Kepler-374 b').
entidad(animal, 'Mol', 'Kepler-374 b').
entidad(animal, 'Gla', 'Kepler-374 b').
entidad(humano, 'Irk', 'Kepler-374 b').
entidad(bacteria, 'Sunarahe', 'Kepler-374 b').
entidad(bacteria, 'Jun', 'Kepler-374 b').
entidad(bacteria, 'Raymoi', 'Kepler-882 b').
entidad(bacteria, 'Rocau', 'Kepler-882 b').
entidad(bacteria, 'Otu', 'Kepler-882 b').
entidad(bacteria, 'Oex', 'Kepler-882 b').
entidad(alien, 'Coc', 'Kepler-882 b').
entidad(bacteria, 'Rua', 'WASP-61 b').
entidad(alien, 'Toalu', 'WASP-61 b').
entidad(bacteria, 'Esareau', 'WASP-61 b').
entidad(alien, 'Fognoid', 'WASP-61 b').
entidad(alien, 'Aud', 'WASP-61 b').
entidad(bacteria, 'Nau', 'WASP-61 b').
entidad(animal, 'Tebi', 'WASP-61 b').
entidad(bacteria, 'Meod', 'BD +20 2457 b').
entidad(animal, 'Punc', 'BD +20 2457 b').
entidad(bacteria, 'Set', 'BD +20 2457 b').
entidad(alien, 'Ker', 'BD +20 2457 b').
entidad(bacteria, 'Tul', 'BD +20 2457 b').
entidad(bacteria, 'Odeil', 'BD +20 2457 b').
entidad(bacteria, 'Sk', 'BD +20 2457 b').
entidad(alien, 'Ote', 'Kepler-172 b').
entidad(bacteria, 'Klo', 'Kepler-172 b').
entidad(humano, 'Cim', 'Kepler-172 b').
entidad(bacteria, 'Yri', 'Kepler-172 b').
entidad(bacteria, 'Sec', 'Kepler-172 b').
entidad(alien, 'Equea', 'Kepler-172 b').
entidad(bacteria, 'Mern', 'Kepler-923 b').
entidad(animal, 'Edsudo', 'Kepler-923 b').
entidad(animal, 'Guroin', 'Kepler-923 b').
entidad(bacteria, 'Eili', 'Kepler-923 b').
entidad(bacteria, 'Cate', 'Kepler-923 b').
entidad(animal, 'Vie', 'Kepler-923 b').
entidad(alien, 'Kea', 'Kepler-923 b').
entidad(animal, 'Eday', 'Kepler-923 b').
entidad(alien, 'Obic', 'Kepler-1125 b').
entidad(bacteria, 'Ailunophi', 'Kepler-1125 b').
entidad(animal, 'Eos', 'Kepler-1125 b').
entidad(humano, 'Unlit', 'Kepler-1125 b').
entidad(bacteria, 'Porm', 'Kepler-1125 b').
entidad(humano, 'Pisul', 'Kepler-1125 b').
entidad(bacteria, 'Idad', 'Kepler-1125 b').
entidad(bacteria, 'Lerareou', 'Kepler-1125 b').
entidad(animal, 'Aprady', 'Kepler-1125 b').
entidad(animal, 'Ila', 'HD 46375 b').
entidad(bacteria, 'Eulo', 'HD 46375 b').
entidad(bacteria, 'Kerm', 'HD 46375 b').
entidad(alien, 'Foani', 'HD 46375 b').
entidad(bacteria, 'Akaneo', 'HD 46375 b').
entidad(bacteria, 'Cro', 'Kepler-1043 b').
entidad(humano, 'Ne', 'Kepler-1043 b').
entidad(humano, 'Veroev', 'Kepler-1043 b').
entidad(bacteria, 'Oso', 'Kepler-1043 b').
entidad(bacteria, 'Sueac', 'Kepler-363 b').
entidad(humano, 'Ovadu', 'Kepler-363 b').
entidad(alien, 'Oxec', 'Kepler-363 b').
entidad(bacteria, 'Bleu', 'Kepler-363 b').
entidad(animal, 'Touna', 'Kepler-363 b').
entidad(animal, 'Icoeau', 'Kepler-363 b').
entidad(alien, 'Aln', 'HD 38529 b').
entidad(humano, 'Itau', 'HD 82943 c').
entidad(animal, 'Blod', 'HD 82943 c').
entidad(animal, 'Kied', 'HD 82943 c').
entidad(bacteria, 'Ars', 'HD 82943 c').
entidad(humano, 'Ugia', 'HD 82943 c').
entidad(bacteria, 'Areteu', 'HD 82943 c').
entidad(alien, 'Tanu', 'HD 82943 c').
entidad(animal, 'Eti', 'HD 82943 c').
entidad(bacteria, 'Kal', 'HD 82943 c').
entidad(alien, 'Erk', 'Kepler-83 b').
entidad(alien, 'Aft', 'Kepler-83 b').
entidad(animal, 'Poelewi', 'Kepler-83 b').
entidad(alien, 'Eadog', 'Kepler-83 b').
entidad(humano, 'Ulit', 'Kepler-83 b').
entidad(animal, 'Igey', 'Kepler-1055 b').
entidad(alien, 'Ou', 'Kepler-1055 b').
entidad(animal, 'Ei', 'Kepler-1055 b').
entidad(bacteria, 'Elen', 'Kepler-1055 b').
entidad(alien, 'Ias', 'Kepler-1055 b').
entidad(alien, 'We', 'Kepler-1055 b').
entidad(humano, 'Oshm', 'Kepler-1055 b').
entidad(bacteria, 'Oue', 'Kepler-1055 b').
entidad(animal, 'Acieus', 'Kepler-1055 b').
entidad(bacteria, 'Hi', 'Kepler-1055 b').
entidad(alien, 'Ensea', 'Kepler-1055 b').
entidad(alien, 'Ayea', 'Kepler-634 b').
entidad(bacteria, 'Oi', 'Kepler-634 b').
entidad(humano, 'Rap', 'Kepler-634 b').
entidad(humano, 'Inli', 'Kepler-634 b').
entidad(bacteria, 'Eudom', 'Kepler-634 b').
entidad(humano, 'Io', 'Kepler-341 d').
entidad(animal, 'Inur', 'Kepler-341 d').
entidad(bacteria, 'Ulm', 'Kepler-341 d').
entidad(bacteria, 'Gau', 'Kepler-341 d').
entidad(bacteria, 'Fliag', 'Kepler-341 d').
entidad(humano, 'Zo', 'Kepler-341 d').
entidad(humano, 'Ae', 'HD 43691 b').
entidad(bacteria, 'Sp', 'HD 43691 b').
entidad(bacteria, 'Ox', 'HD 43691 b').
entidad(bacteria, 'Eiva', 'HD 43691 b').
entidad(humano, 'Xhut', 'HD 43691 b').
entidad(animal, 'Asi', 'WASP-13 b').
entidad(animal, 'Ow', 'WASP-13 b').
entidad(alien, 'Eru', 'WASP-13 b').
entidad(alien, 'Esim', 'WASP-13 b').
entidad(bacteria, 'Odoma', 'WASP-13 b').
entidad(humano, 'El', 'HAT-P-20 b').
entidad(animal, 'Ai', 'HAT-P-20 b').
entidad(bacteria, 'Gisp', 'HAT-P-20 b').
entidad(bacteria, 'Ub', 'HAT-P-20 b').
entidad(animal, 'Osic', 'HAT-P-20 b').
entidad(bacteria, 'Otua', 'HAT-P-20 b').
entidad(alien, 'Api', 'Kepler-52 b').
entidad(alien, 'Aisize', 'Kepler-52 b').
entidad(humano, 'Edu', 'Kepler-52 b').
entidad(alien, 'Man', 'Kepler-52 b').
entidad(alien, 'Scra', 'Kepler-1452 b').
entidad(humano, 'Joir', 'Kepler-1452 b').
entidad(bacteria, 'Biail', 'Kepler-1452 b').
entidad(bacteria, 'Ey', 'Kepler-1277 b').
entidad(bacteria, 'Sa', 'Kepler-1277 b').
entidad(bacteria, 'Ema', 'Kepler-1277 b').
entidad(bacteria, 'Afa', 'Kepler-1277 b').
entidad(humano, 'Ariane', 'Kepler-1277 b').
entidad(alien, 'Alani', 'Kepler-1277 b').
entidad(alien, 'Aud', 'Kepler-1277 b').
entidad(alien, 'Taf', 'Kepler-215 c').
entidad(alien, 'Opok', 'Kepler-215 c').
entidad(alien, 'Nef', 'Kepler-215 c').
entidad(alien, 'Hy', 'Kepler-215 c').
entidad(bacteria, 'Kieve', 'HD 189733 b').
entidad(humano, 'Eloir', 'HD 189733 b').
entidad(humano, 'Vousyr', 'HD 189733 b').
entidad(humano, 'Eh', 'HD 189733 b').
entidad(animal, 'Eour', 'HD 189733 b').
entidad(humano, 'As', 'HD 189733 b').
entidad(alien, 'Iluie', 'HD 189733 b').
entidad(animal, 'Ed', 'HD 189733 b').
entidad(alien, 'Jau', 'Kepler-882 b').
entidad(animal, 'Tea', 'Kepler-372 d').
entidad(humano, 'We', 'Kepler-372 d').
entidad(bacteria, 'Ae', 'Kepler-372 d').
entidad(alien, 'Usa', 'Kepler-372 d').
entidad(bacteria, 'Gionfar', 'Kepler-1026 b').
entidad(humano, 'Bi', 'Kepler-1026 b').
entidad(alien, 'Eagli', 'Kepler-1026 b').
entidad(alien, 'Agnus', 'Kepler-1026 b').
entidad(animal, 'Ke', 'Kepler-1026 b').
entidad(bacteria, 'Cabeti', 'Kepler-1026 b').
entidad(animal, 'Sov', 'Kepler-1026 b').
entidad(animal, 'Uve', 'Kepler-1026 b').
entidad(bacteria, 'Udilm', 'Kepler-1026 b').
entidad(animal, 'Ture', 'Kepler-170 b').
entidad(bacteria, 'One', 'Kepler-170 b').
entidad(alien, 'De', 'Kepler-170 b').
entidad(bacteria, 'Ai', 'Kepler-170 b').
entidad(alien, 'Tri', 'HD 30177 b').
entidad(alien, 'Oe', 'HD 30177 b').
entidad(bacteria, 'Jos', 'HD 30177 b').
entidad(bacteria, 'Bap', 'HD 30177 b').
entidad(humano, 'Ioupio', 'HD 30177 b').
entidad(bacteria, 'Ark', 'HD 30177 b').
entidad(alien, 'Sre', 'HD 212301 b').
entidad(bacteria, 'Ar', 'HD 212301 b').
entidad(animal, 'Eco', 'HD 212301 b').
entidad(bacteria, 'Ne', 'HD 212301 b').
entidad(alien, 'Railo', 'HD 212301 b').
entidad(bacteria, 'At', 'HD 212301 b').
entidad(alien, 'Cag', 'Kepler-383 c').
entidad(bacteria, 'Onbevo', 'Kepler-383 c').
entidad(bacteria, 'Ido', 'Kepler-383 c').
entidad(alien, 'Vispow', 'Kepler-383 c').
entidad(alien, 'Iogi', 'Kepler-383 c').
entidad(alien, 'Alounopi', 'Kepler-168 b').
entidad(bacteria, 'Oe', 'Kepler-168 b').
entidad(alien, 'Sio', 'Kepler-168 b').
entidad(humano, 'Sape', 'Kepler-168 b').
entidad(alien, 'Quoy', 'Kepler-168 b').
entidad(alien, 'Ry', 'Kepler-168 b').
entidad(alien, 'Ge', 'Kepler-168 b').
entidad(bacteria, 'Ow', 'Kepler-943 b').
entidad(alien, 'Ro', 'Kepler-943 b').
entidad(humano, 'Eha', 'Kepler-943 b').
entidad(bacteria, 'Gat', 'Kepler-943 b').
entidad(humano, 'Oa', 'Kepler-943 b').
entidad(alien, 'By', 'Kepler-1490 b').
entidad(animal, 'Fo', 'Kepler-1490 b').
entidad(animal, 'Os', 'Kepler-1490 b').
entidad(bacteria, 'Gy', 'Kepler-1490 b').
entidad(bacteria, 'Feu', 'Kepler-1490 b').
entidad(bacteria, 'Squear', 'Kepler-892 b').
entidad(bacteria, 'Ai', 'Kepler-892 b').
entidad(alien, 'Hm', 'Kepler-892 b').
entidad(animal, 'Veig', 'Kepler-892 b').
entidad(bacteria, 'Vin', 'Kepler-892 b').
entidad(animal, 'Oha', 'Kepler-892 b').
entidad(bacteria, 'Eho', 'Kepler-892 b').
entidad(alien, 'Oupdou', 'HD 181342 b').
entidad(alien, 'Oeato', 'HD 181342 b').
entidad(bacteria, 'Hijau', 'HD 181342 b').
entidad(animal, 'Cail', 'HD 181342 b').
entidad(animal, 'Nodorbuirimi', 'HD 181342 b').
entidad(bacteria, 'Eodadir', 'Kepler-556 b').
entidad(bacteria, 'Ut', 'Kepler-556 b').
entidad(alien, 'Osau', 'Kepler-556 b').
entidad(bacteria, 'Oweasuno', 'Kepler-556 b').
entidad(alien, 'Ob', 'Kepler-556 b').
entidad(alien, 'Denege', 'Kepler-556 b').
entidad(alien, 'Ibow', 'Kepler-556 b').
entidad(animal, 'Duna', 'Kepler-556 b').
entidad(animal, 'Unieno', 'Kepler-556 b').
entidad(bacteria, 'Ciorig', 'Kepler-556 b').
entidad(humano, 'You', 'Kepler-556 b').
entidad(animal, 'One', 'Kepler-215 e').
entidad(bacteria, 'Amid', 'Kepler-215 e').
entidad(alien, 'Auxt', 'Kepler-215 e').
entidad(alien, 'Tio', 'Kepler-215 e').
entidad(bacteria, 'Lio', 'Kepler-215 e').
entidad(bacteria, 'Ohex', 'Kepler-215 e').
entidad(humano, 'Etay', 'Kepler-215 e').
entidad(alien, 'Meki', 'Kepler-215 e').
entidad(alien, 'Leo', 'Kepler-215 e').
entidad(bacteria, 'Sar', 'Kepler-215 e').
entidad(bacteria, 'Atusynieu', 'Kepler-215 e').
entidad(bacteria, 'Gue', 'Kepler-215 e').
entidad(alien, 'Ala', 'Kepler-271 c').
entidad(animal, 'Inelds', 'Kepler-271 c').
entidad(bacteria, 'Oaky', 'Kepler-271 c').
entidad(humano, 'Elol', 'Kepler-271 c').
entidad(alien, 'Heo', 'Kepler-271 c').
entidad(animal, 'Kenu', 'Kepler-271 c').
entidad(alien, 'Di', 'Kepler-271 c').
entidad(alien, 'Pupri', 'GJ 581 b').
entidad(alien, 'Be', 'GJ 581 b').
entidad(humano, 'Gheo', 'GJ 581 b').
entidad(bacteria, 'Oyo', 'GJ 581 b').
entidad(bacteria, 'Oge', 'GJ 581 b').
entidad(humano, 'Ecue', 'GJ 581 b').
entidad(alien, 'Epocag', 'GJ 581 b').
entidad(bacteria, 'Not', 'Kepler-1259 b').
entidad(alien, 'Sai', 'Kepler-1259 b').
entidad(bacteria, 'Uh', 'Kepler-1259 b').
entidad(animal, 'Itanuca', 'Kepler-1259 b').
entidad(alien, 'Oea', 'Kepler-1259 b').
entidad(animal, 'Mane', 'Kepler-94 b').
entidad(animal, 'Usie', 'Kepler-94 b').
entidad(animal, 'Eo', 'Kepler-94 b').
entidad(humano, 'Eu', 'Kepler-94 b').
entidad(bacteria, 'Eas', 'Kepler-94 b').
entidad(humano, 'Nui', 'Kepler-94 b').
entidad(alien, 'Rido', 'Kepler-94 b').
entidad(alien, 'Il', 'Kepler-94 b').
entidad(bacteria, 'Li', 'Kepler-94 b').
entidad(alien, 'Yine', 'Kepler-94 b').
entidad(alien, 'Tan', 'Kepler-94 b').
entidad(alien, 'Yinia', 'Kepler-993 b').
entidad(alien, 'Obaphim', 'HD 132406 b').
entidad(bacteria, 'Egoi', 'HD 132406 b').
entidad(bacteria, 'Obut', 'HD 132406 b').
entidad(alien, 'Aem', 'HD 132406 b').
entidad(bacteria, 'Ag', 'HD 132406 b').
entidad(bacteria, 'Edaf', 'HD 132406 b').
entidad(alien, 'Oc', 'HD 132406 b').
entidad(bacteria, 'Isic', 'Kepler-172 c').
entidad(bacteria, 'El', 'Kepler-172 c').
entidad(humano, 'Iruglu', 'Kepler-172 c').
entidad(bacteria, 'In', 'Kepler-172 c').
entidad(bacteria, 'Egei', 'Kepler-172 c').
entidad(bacteria, 'Pauge', 'Kepler-172 c').
entidad(alien, 'Eonaw', 'Kepler-172 c').
entidad(alien, 'Ogiedeo', 'Kepler-880 b').
entidad(bacteria, 'Ay', 'Kepler-880 b').
entidad(humano, 'Wei', 'Kepler-880 b').
entidad(animal, 'Egimau', 'Kepler-880 b').
entidad(humano, 'Opo', 'Kepler-880 b').
entidad(bacteria, 'Hip', 'Kepler-880 b').
entidad(bacteria, 'Poe', 'WASP-94 B b').
entidad(alien, 'Guar', 'WASP-94 B b').
entidad(animal, 'An', 'WASP-94 B b').
entidad(animal, 'Gam', 'WASP-94 B b').
entidad(alien, 'Ps', 'WASP-94 B b').
entidad(bacteria, 'Eguipai', 'WASP-94 B b').
entidad(bacteria, 'Za', 'HD 2952 b').
entidad(alien, 'Ogue', 'HD 2952 b').
entidad(bacteria, 'Soa', 'HD 2952 b').
entidad(humano, 'En', 'HD 2952 b').
entidad(alien, 'Egie', 'HD 2952 b').
entidad(alien, 'Ul', 'Kepler-1430 b').
entidad(animal, 'Etomob', 'Kepler-1430 b').
entidad(bacteria, 'Us', 'Kepler-1430 b').
entidad(bacteria, 'Wha', 'Kepler-1430 b').
entidad(alien, 'Owe', 'Kepler-1430 b').
entidad(bacteria, 'Os', 'Kepler-1430 b').
entidad(alien, 'Ew', 'Kepler-185 c').
entidad(bacteria, 'Eor', 'Kepler-185 c').
entidad(alien, 'Gli', 'Kepler-185 c').
entidad(bacteria, 'Pas', 'Kepler-185 c').
entidad(bacteria, 'Ek', 'Kepler-185 c').
entidad(humano, 'Agoa', 'Kepler-185 c').
entidad(bacteria, 'Te', 'Kepler-554 b').
entidad(bacteria, 'Maxi', 'Kepler-554 b').
entidad(animal, 'Usa', 'Kepler-554 b').
entidad(alien, 'Gotsil', 'Kepler-554 b').
entidad(alien, 'Cuda', 'Kepler-554 b').
entidad(alien, 'Tedi', 'HD 206610 b').
entidad(humano, 'Una', 'HD 206610 b').
entidad(alien, 'Oga', 'Kepler-1535 b').
entidad(bacteria, 'Eci', 'Kepler-1535 b').
entidad(animal, 'Spoedo', 'Kepler-1535 b').
entidad(bacteria, 'Spoe', 'Kepler-1535 b').
entidad(alien, 'Pows', 'Kepler-1535 b').
entidad(bacteria, 'Iai', 'Kepler-1535 b').
entidad(animal, 'Fe', 'Kepler-1535 b').
entidad(humano, 'Ebox', 'Kepler-1535 b').
entidad(bacteria, 'Of', 'Kepler-1535 b').
entidad(animal, 'Po', 'Kepler-1535 b').
entidad(humano, 'Siximie', 'Kepler-1535 b').
entidad(bacteria, 'Ulotpo', 'Kepler-1121 b').
entidad(alien, 'Bibergoa', 'Kepler-1121 b').
entidad(alien, 'No', 'Kepler-1121 b').
entidad(bacteria, 'Iap', 'Kepler-1121 b').
entidad(alien, 'As', 'Kepler-1121 b').
entidad(bacteria, 'Nemoet', 'Kepler-1121 b').
entidad(bacteria, 'Fege', 'Kepler-1121 b').
entidad(alien, 'Zo', 'Kepler-23 d').
entidad(alien, 'Code', 'Kepler-23 d').
entidad(bacteria, 'Ifs', 'Kepler-23 d').
entidad(animal, 'Do', 'Kepler-23 d').
entidad(bacteria, 'Ni', 'Kepler-23 d').
entidad(bacteria, 'Oubau', 'Kepler-23 d').
entidad(bacteria, 'Ib', 'Kepler-23 d').
entidad(animal, 'Ebia', 'Kepler-23 d').
entidad(bacteria, 'Ofetahopio', 'Kepler-23 d').
entidad(bacteria, 'Nubei', 'Kepler-23 d').
entidad(alien, 'Wa', 'Kepler-23 d').
entidad(animal, 'Ach', 'Kepler-117 c').
entidad(alien, 'Oes', 'Kepler-117 c').
entidad(alien, 'Alou', 'Kepler-117 c').
entidad(animal, 'Mb', 'Kepler-117 c').
entidad(humano, 'La', 'Kepler-117 c').
entidad(humano, 'Na', 'HD 28678 b').
entidad(humano, 'Aemakien', 'HD 28678 b').
entidad(alien, 'Aeoced', 'HD 28678 b').
entidad(alien, 'Racau', 'HD 28678 b').
entidad(alien, 'Aya', 'HD 28678 b').
entidad(bacteria, 'Bas', 'HD 28678 b').
entidad(animal, 'Poci', 'HD 28678 b').
entidad(bacteria, 'Etwi', 'HD 28678 b').
entidad(bacteria, 'Ad', 'HD 28678 b').
entidad(animal, 'Pa', 'HD 28678 b').
entidad(bacteria, 'Sumbia', 'Kepler-1103 b').
entidad(humano, 'Ken', 'Kepler-1103 b').
entidad(animal, 'Eusoi', 'Kepler-1103 b').
entidad(animal, 'Ivou', 'Kepler-1103 b').
entidad(humano, 'Vic', 'Kepler-1103 b').
entidad(humano, 'Ord', 'Kepler-424 c').
entidad(bacteria, 'Ekiscoed', 'Kepler-424 c').
entidad(alien, 'Tesuiraug', 'Kepler-424 c').
entidad(alien, 'Otik', 'Kepler-424 c').
entidad(animal, 'Yr', 'Kepler-424 c').
entidad(animal, 'Asici', 'HD 126614 A b').
entidad(bacteria, 'Imi', 'HD 126614 A b').
entidad(alien, 'Eus', 'Kepler-60 c').
entidad(animal, 'Lunimie', 'Kepler-60 c').
entidad(bacteria, 'Dyn', 'GJ 687 b').
entidad(alien, 'Vano', 'GJ 687 b').
entidad(humano, 'Adotu', 'Kepler-1311 b').
entidad(alien, 'Eh', 'Kepler-1311 b').
entidad(bacteria, 'Eog', 'Kepler-1311 b').
entidad(alien, 'Blag', 'Kepler-1311 b').
entidad(alien, 'Lel', 'Kepler-1311 b').
entidad(bacteria, 'Tiorsa', 'Kepler-1311 b').
entidad(animal, 'Eag', 'Kepler-1311 b').
entidad(animal, 'Olio', 'Kepler-117 b').
entidad(bacteria, 'Enaup', 'Kepler-117 b').
entidad(humano, 'Oado', 'Kepler-117 b').
entidad(animal, 'Deo', 'Kepler-117 b').
entidad(bacteria, 'Epa', 'Kepler-342 e').
entidad(bacteria, 'Ir', 'Kepler-342 e').
entidad(bacteria, 'Oha', 'Kepler-342 e').
entidad(alien, 'Fiaid', 'Kepler-342 e').
entidad(animal, 'Alu', 'Kepler-342 e').
entidad(bacteria, 'Ya', 'Kepler-342 e').
entidad(bacteria, 'Octu', 'Kepler-342 e').
entidad(animal, 'Pefu', 'Kepler-342 e').
entidad(animal, 'Noev', 'HD 83443 b').
entidad(animal, 'Aule', 'HD 83443 b').
entidad(humano, 'Vaum', 'HD 83443 b').
entidad(bacteria, 'Ofeur', 'HD 83443 b').
entidad(humano, 'Cuinoi', 'HD 83443 b').
entidad(humano, 'Is', 'Kepler-154 d').
entidad(alien, 'Ilimi', 'Kepler-154 d').
entidad(alien, 'Re', 'Kepler-154 d').
entidad(alien, 'Sag', 'Kepler-154 d').
entidad(bacteria, 'Adwa', 'Kepler-154 d').
entidad(bacteria, 'Enetea', 'Kepler-154 d').
entidad(bacteria, 'Lim', 'Kepler-154 d').
entidad(alien, 'Oat', 'Kepler-154 d').
entidad(alien, 'Ewana', 'Kepler-154 d').
entidad(bacteria, 'Cei', 'Kepler-154 d').
entidad(alien, 'Bap', 'Kepler-154 d').
entidad(alien, 'Ed', 'Kepler-863 b').
entidad(alien, 'Ratui', 'Kepler-863 b').
entidad(humano, 'Lel', 'Kepler-863 b').
entidad(alien, 'Tiorsa', 'Kepler-863 b').
entidad(animal, 'Eag', 'Kepler-863 b').
entidad(humano, 'Olio', 'Kepler-460 c').
entidad(humano, 'Enaup', 'Kepler-460 c').
entidad(bacteria, 'Oado', 'Kepler-460 c').
entidad(alien, 'Deo', 'Kepler-460 c').
entidad(animal, 'Epa', 'Kepler-460 c').
entidad(alien, 'Ir', 'Kepler-918 b').
entidad(alien, 'Oha', 'Kepler-918 b').
entidad(animal, 'Fiaid', 'Kepler-918 b').
entidad(alien, 'Alu', 'Kepler-918 b').
entidad(alien, 'Ya', 'Kepler-918 b').
entidad(bacteria, 'Octu', 'Kepler-918 b').
entidad(alien, 'Pefu', 'Kepler-918 b').
entidad(bacteria, 'Noev', 'Kepler-235 e').
entidad(alien, 'Aule', 'Kepler-235 e').
entidad(bacteria, 'Vaum', 'Kepler-235 e').
entidad(humano, 'Ofeur', 'Kepler-235 e').
entidad(humano, 'Cuinoi', 'Kepler-235 e').
entidad(humano, 'Is', 'Kepler-235 e').
entidad(bacteria, 'Ilimi', 'Kepler-235 e').
entidad(bacteria, 'Re', 'Kepler-941 b').
entidad(humano, 'Sag', 'Kepler-941 b').
entidad(animal, 'Adwa', 'Kepler-941 b').
entidad(alien, 'Enetea', 'Kepler-941 b').
entidad(animal, 'Lim', 'Kepler-941 b').
entidad(alien, 'Oat', 'Kepler-941 b').
entidad(humano, 'Ewana', 'Kepler-1532 b').
entidad(alien, 'Cei', 'Kepler-1532 b').
entidad(humano, 'Bap', 'Kepler-1532 b').
entidad(alien, 'Ed', 'Kepler-1532 b').
entidad(animal, 'Ratui', 'Kepler-1532 b').
entidad(bacteria, 'Ino', 'Kepler-1195 b').
entidad(alien, 'Erb', 'Kepler-1195 b').
entidad(humano, 'Igo', 'Kepler-1195 b').
entidad(bacteria, 'Noct', 'Kepler-1195 b').
entidad(bacteria, 'Dadou', 'Kepler-1195 b').
entidad(animal, 'Debole', 'Kepler-149 d').
entidad(bacteria, 'Nipe', 'Kepler-149 d').
entidad(alien, 'Oze', 'Kepler-149 d').
entidad(bacteria, 'Er', 'Kepler-149 d').
entidad(bacteria, 'Gn', 'Kepler-149 d').
entidad(alien, 'Met', 'Kepler-149 d').
entidad(alien, 'Zea', 'Kepler-149 d').
entidad(bacteria, 'Dodegei', 'Kepler-149 d').
entidad(animal, 'Or', 'Kepler-149 d').
entidad(humano, 'Efou', 'Kepler-840 b').
entidad(alien, 'Nic', 'Kepler-840 b').
entidad(animal, 'Idazi', 'Kepler-840 b').
entidad(alien, 'Vala', 'Kepler-840 b').
entidad(alien, 'Nadu', 'Kepler-840 b').
entidad(bacteria, 'Owri', 'Kepler-840 b').
entidad(bacteria, 'Emai', 'Kepler-510 b').
entidad(bacteria, 'Oan', 'Kepler-510 b').
entidad(humano, 'Dwou', 'Kepler-510 b').
entidad(humano, 'Ocur', 'Kepler-510 b').
entidad(alien, 'Enoc', 'Kepler-510 b').
entidad(humano, 'Jug', 'Kepler-510 b').
entidad(bacteria, 'Rep', 'HD 285507 b').
entidad(bacteria, 'Akicielbiv', 'HD 285507 b').
entidad(bacteria, 'Wi', 'HD 285507 b').
entidad(alien, 'Aluxua', 'HD 285507 b').
entidad(animal, 'Oyo', 'HD 125612 c').
entidad(humano, 'Ghoe', 'HD 125612 c').
entidad(animal, 'Zedeo', 'HD 125612 c').
entidad(bacteria, 'Oul', 'HD 125612 c').
entidad(alien, 'Up', 'HD 125612 c').
entidad(alien, 'Eoso', 'HD 125612 c').
entidad(alien, 'Pecat', 'HD 125612 c').
entidad(alien, 'Lule', 'CoRoT-22 b').
entidad(alien, 'Auma', 'CoRoT-22 b').
entidad(bacteria, 'Ewitoinoelo', 'CoRoT-22 b').
entidad(animal, 'Saut', 'CoRoT-22 b').
entidad(animal, 'Seto', 'CoRoT-22 b').
entidad(humano, 'Doed', 'Kepler-948 b').
entidad(alien, 'Odu', 'Kepler-948 b').
entidad(animal, 'Otoude', 'Kepler-948 b').
entidad(humano, 'Isove', 'Kepler-948 b').
entidad(alien, 'Edu', 'Kepler-948 b').
entidad(animal, 'Hy', 'Kepler-1606 b').
entidad(humano, 'Tram', 'Kepler-1606 b').
entidad(bacteria, 'Ecaurfug', 'Kepler-1606 b').
entidad(animal, 'Enu', 'Kepler-1606 b').
entidad(bacteria, 'Ghaw', 'Kepler-1606 b').
entidad(animal, 'Otaca', 'Kepler-281 c').
entidad(alien, 'Mbisa', 'Kepler-281 c').
entidad(bacteria, 'Decy', 'Kepler-281 c').
entidad(humano, 'Obum', 'Kepler-281 c').
entidad(bacteria, 'Gremb', 'Kepler-281 c').
entidad(bacteria, 'Poenid', 'Kepler-281 c').
entidad(humano, 'Uma', 'Kepler-1152 b').
entidad(animal, 'Wie', 'Kepler-1152 b').
entidad(alien, 'Expe', 'Kepler-1152 b').
entidad(alien, 'Iards', 'Kepler-1152 b').
entidad(humano, 'Foi', 'Kepler-1152 b').
entidad(animal, 'Onoea', 'Kepler-1152 b').
entidad(bacteria, 'Dog', 'Kepler-1152 b').
entidad(animal, 'Opopma', 'Kepler-1152 b').
entidad(alien, 'Jur', 'Kepler-1152 b').
entidad(bacteria, 'Oiciosoeu', 'Kepler-1152 b').
entidad(bacteria, 'Rai', 'Kepler-1152 b').
entidad(humano, 'Ofabi', 'Kepler-1505 b').
entidad(alien, 'Beit', 'Kepler-1505 b').
entidad(bacteria, 'Oise', 'Kepler-1505 b').
entidad(animal, 'Otanc', 'Kepler-1505 b').
entidad(alien, 'Nueung', 'Kepler-1505 b').
entidad(animal, 'Jayelp', 'Kepler-1505 b').
entidad(alien, 'Kwasop', 'OGLE-05-071L b').
entidad(bacteria, 'Emo', 'OGLE-05-071L b').
entidad(animal, 'Ch', 'OGLE-05-071L b').
entidad(animal, 'Yed', 'Kepler-1104 b').
entidad(alien, 'Piz', 'Kepler-1104 b').
entidad(alien, 'Vaci', 'Kepler-1104 b').
entidad(bacteria, 'Halbalans', 'Kepler-1104 b').
entidad(alien, 'Neoca', 'WASP-18 b').
entidad(animal, 'Tugeigute', 'WASP-18 b').
entidad(bacteria, 'Lug', 'WASP-18 b').
entidad(alien, 'Ica', 'WASP-18 b').
entidad(bacteria, 'Amau', 'Kepler-591 b').
entidad(alien, 'Ioldu', 'Kepler-591 b').
entidad(alien, 'Pep', 'Kepler-591 b').
entidad(animal, 'Otut', 'Kepler-591 b').
entidad(bacteria, 'Aeont', 'Kepler-591 b').
entidad(humano, 'Efoe', 'Kepler-195 c').
entidad(humano, 'Ogo', 'Kepler-195 c').
entidad(humano, 'Uvenlira', 'Kepler-195 c').
entidad(alien, 'Ori', 'Kepler-195 c').
entidad(animal, 'Fumiage', 'Kepler-195 c').
entidad(bacteria, 'Aso', 'Kepler-195 c').
entidad(animal, 'Ton', 'Kepler-195 c').
entidad(bacteria, 'Oal', 'Kepler-195 c').
entidad(animal, 'Mumb', 'Kepler-195 c').
entidad(humano, 'Oac', 'Kepler-195 c').
entidad(alien, 'Aner', 'Kepler-195 c').
entidad(bacteria, 'Ceds', 'Kepler-195 c').
entidad(alien, 'Ita', 'Kepler-271 c').
entidad(alien, 'Iri', 'Kepler-271 c').
entidad(bacteria, 'Jogia', 'Kepler-271 c').
entidad(animal, 'Nualgisuba', 'Kepler-271 c').
entidad(humano, 'Plofib', 'Kepler-514 b').
entidad(bacteria, 'Bes', 'Kepler-514 b').
entidad(animal, 'Gigeareos', 'Kepler-514 b').
entidad(animal, 'Pim', 'Kepler-514 b').
entidad(alien, 'Unif', 'Kepler-514 b').
entidad(animal, 'Olibsidou', 'Kepler-514 b').
entidad(alien, 'Cio', 'Kepler-344 c').
entidad(bacteria, 'Sisa', 'Kepler-344 c').
entidad(animal, 'Noi', 'Kepler-344 c').
entidad(alien, 'Eigob', 'Kepler-344 c').
entidad(bacteria, 'Cla', 'Kepler-344 c').
entidad(bacteria, 'Lake', 'Kepler-344 c').
entidad(bacteria, 'Tsive', 'Kepler-344 c').
entidad(alien, 'Ril', 'HAT-P-20 b').
entidad(alien, 'Udiclui', 'HAT-P-20 b').
entidad(humano, 'Ple', 'HAT-P-20 b').
entidad(alien, 'Egouti', 'HAT-P-20 b').
entidad(bacteria, 'Ninef', 'HAT-P-20 b').
entidad(alien, 'Iari', 'Kepler-111 b').
entidad(alien, 'Omer', 'Kepler-11 e').
entidad(animal, 'Drodag', 'Kepler-11 e').
entidad(alien, 'Awel', 'Kepler-11 e').
entidad(bacteria, 'Ozo', 'Kepler-11 e').
entidad(animal, 'Douco', 'Kepler-11 e').
entidad(bacteria, 'Unerwedoe', 'Kepler-11 e').
entidad(humano, 'View', 'Kepler-1223 b').
entidad(animal, 'Ais', 'Kepler-1223 b').
entidad(animal, 'Naly', 'Kepler-1223 b').
entidad(bacteria, 'Coe', 'Kepler-1223 b').
entidad(bacteria, 'Aqueule', 'Kepler-1223 b').
entidad(alien, 'Riso', 'Kepler-197 c').
entidad(humano, 'Acak', 'Kepler-197 c').
entidad(bacteria, 'Dis', 'Kepler-197 c').
entidad(bacteria, 'Oar', 'Kepler-197 c').
entidad(alien, 'Etok', 'Kepler-197 c').
entidad(animal, 'Fer', 'Kepler-197 c').
entidad(humano, 'Spol', 'Kepler-197 c').
entidad(bacteria, 'Ereo', 'Kepler-197 c').
entidad(alien, 'Apa', 'Kepler-866 b').
entidad(alien, 'Aigutic', 'Kepler-866 b').
entidad(bacteria, 'Ito', 'Kepler-866 b').
entidad(alien, 'Sele', 'Kepler-866 b').
entidad(animal, 'Oen', 'Kepler-866 b').
entidad(animal, 'Goi', 'Kepler-866 b').
entidad(animal, 'Hucalia', 'WASP-74 b').
entidad(alien, 'Qua', 'WASP-74 b').
entidad(animal, 'Baiv', 'WASP-74 b').
entidad(alien, 'Irkila', 'WASP-74 b').
entidad(alien, 'Amu', 'Kepler-1154 c').
entidad(bacteria, 'Hiter', 'Kepler-1154 c').
entidad(bacteria, 'Oirog', 'Kepler-1154 c').
entidad(humano, 'Gich', 'Kepler-1154 c').
entidad(animal, 'Onta', 'Kepler-1154 c').
entidad(bacteria, 'Iat', 'Kepler-1154 c').
entidad(animal, 'Cab', 'Kepler-1154 c').
entidad(bacteria, 'Egesex', 'Kepler-1154 c').
entidad(bacteria, 'Eak', 'Kepler-1154 c').
entidad(alien, 'Eiva', 'Kepler-1154 c').
entidad(animal, 'Obt', 'Kepler-1154 c').
entidad(alien, 'Saco', 'Kepler-1154 c').
entidad(bacteria, 'Irfa', 'Kepler-251 d').
entidad(alien, 'Sala', 'Kepler-251 d').
entidad(bacteria, 'Raph', 'Kepler-251 d').
entidad(bacteria, 'Moir', 'Kepler-251 d').
entidad(animal, 'Ene', 'Kepler-251 d').
entidad(bacteria, 'Iven', 'MOA-bin-1L b').
entidad(bacteria, 'Poeurbi', 'MOA-bin-1L b').
entidad(bacteria, 'Ziel', 'MOA-bin-1L b').
entidad(bacteria, 'Oenraza', 'MOA-bin-1L b').
entidad(alien, 'Fla', 'MOA-bin-1L b').
entidad(animal, 'Dio', 'Kepler-947 b').
entidad(alien, 'Osug', 'Kepler-947 b').
entidad(animal, 'Ero', 'Kepler-947 b').
entidad(bacteria, 'Eoseurouro', 'Kepler-947 b').
entidad(bacteria, 'Ify', 'Kepler-947 b').
entidad(humano, 'Upo', 'Kepler-947 b').
entidad(bacteria, 'Steo', 'Kepler-947 b').
entidad(animal, 'Amo', 'Kepler-947 b').
entidad(humano, 'Ogei', 'Kepler-947 b').
entidad(alien, 'Ogus', 'Kepler-947 b').
entidad(humano, 'Ayenip', 'Kepler-947 b').
entidad(animal, 'Eha', 'omega Ser b').
entidad(humano, 'Ube', 'omega Ser b').
entidad(alien, 'Exe', 'omega Ser b').
entidad(alien, 'Adrituane', 'omega Ser b').
entidad(bacteria, 'Usaicupoa', 'omega Ser b').
entidad(bacteria, 'Hafec', 'HD 217107 c').
entidad(bacteria, 'Awle', 'HD 217107 c').
entidad(alien, 'Eisovoya', 'HD 217107 c').
entidad(bacteria, 'Fambi', 'HD 217107 c').
entidad(bacteria, 'Doea', 'HD 217107 c').
entidad(alien, 'Sog', 'HD 217107 c').
entidad(animal, 'Kabs', 'Kepler-135 b').
entidad(bacteria, 'Whau', 'Kepler-135 b').
entidad(bacteria, 'Vas', 'Kepler-135 b').
entidad(humano, 'Toe', 'Kepler-135 b').
entidad(alien, 'Fin', 'Kepler-135 b').
entidad(humano, 'Fiaigeh', 'Kepler-1349 b').
entidad(humano, 'Eimea', 'Kepler-1349 b').
entidad(animal, 'Sh', 'Kepler-1349 b').
entidad(alien, 'Ugil', 'Kepler-1349 b').
entidad(humano, 'Azeab', 'Kepler-1349 b').
entidad(bacteria, 'Nu', 'HD 153950 b').
entidad(alien, 'Olo', 'HD 153950 b').
entidad(bacteria, 'Use', 'HD 153950 b').
entidad(bacteria, 'Belain', 'HD 153950 b').
entidad(alien, 'Etom', 'HD 153950 b').
entidad(bacteria, 'Itiec', 'HD 153950 b').
entidad(animal, 'Afeim', 'HD 153950 b').
entidad(humano, 'Afea', 'Kepler-265 c').
entidad(alien, 'Ibew', 'Kepler-265 c').
entidad(humano, 'Ake', 'Kepler-265 c').
entidad(humano, 'Diz', 'Kepler-265 c').
entidad(bacteria, 'Veli', 'Kepler-127 d').
entidad(alien, 'Och', 'Kepler-127 d').
entidad(bacteria, 'Viro', 'Kepler-127 d').
entidad(animal, 'Pulu', 'Kepler-127 d').
entidad(bacteria, 'Porlam', 'Kepler-127 d').
entidad(bacteria, 'Fus', 'Kepler-127 d').
entidad(animal, 'Nob', 'Kepler-151 c').
entidad(bacteria, 'Oic', 'Kepler-151 c').
entidad(bacteria, 'Joralol', 'Kepler-151 c').
entidad(humano, 'Unbi', 'Kepler-151 c').
entidad(humano, 'Cem', 'Kepler-151 c').
entidad(alien, 'Ouseat', 'Kepler-490 b').
entidad(animal, 'Apren', 'Kepler-490 b').
entidad(bacteria, 'Tigeimanu', 'Kepler-490 b').
entidad(alien, 'Popum', 'Kepler-490 b').
entidad(alien, 'Ocio', 'Kepler-490 b').
entidad(alien, 'Anth', 'Kepler-490 b').
entidad(alien, 'Didumurgatic', 'Kepler-490 b').
entidad(bacteria, 'Eis', 'Kepler-490 b').
entidad(bacteria, 'Osiarhe', 'Kepler-490 b').
entidad(alien, 'Prana', 'Kepler-6 b').
entidad(humano, 'Ehoi', 'Kepler-6 b').
entidad(bacteria, 'Cua', 'Kepler-6 b').
entidad(alien, 'Halurs', 'Kepler-6 b').
entidad(alien, 'Tuefaribs', 'Kepler-6 b').
entidad(bacteria, 'Obs', 'Kepler-102 b').
entidad(alien, 'Aul', 'Kepler-102 b').
entidad(alien, 'Ifeape', 'Kepler-102 b').
entidad(animal, 'Oce', 'Kepler-102 b').
entidad(bacteria, 'Arice', 'Kepler-102 b').
entidad(humano, 'Srum', 'Kepler-102 b').
entidad(bacteria, 'Nus', 'HD 290327 b').
entidad(bacteria, 'Ami', 'HD 290327 b').
entidad(animal, 'Cefetog', 'HD 290327 b').
entidad(bacteria, 'Ayo', 'HD 290327 b').
entidad(animal, 'Upiadiva', 'HD 290327 b').
entidad(bacteria, 'Rio', 'HD 290327 b').
entidad(humano, 'Opirwe', 'HD 290327 b').
entidad(alien, 'Nda', 'WASP-75 b').
entidad(animal, 'Nuceilo', 'WASP-75 b').
entidad(alien, 'Wourot', 'WASP-75 b').
entidad(alien, 'Rworeron', 'WASP-75 b').
entidad(alien, 'Ainciv', 'WASP-75 b').
entidad(alien, 'Uro', 'WASP-75 b').
entidad(humano, 'Tampos', 'WASP-75 b').
entidad(animal, 'Ate', 'WASP-75 b').
entidad(alien, 'Nd', 'WASP-75 b').
entidad(bacteria, 'Mirusa', 'WASP-75 b').
entidad(bacteria, 'Hoei', 'WASP-75 b').
entidad(alien, 'Clobs', 'WASP-75 b').
entidad(humano, 'Pri', 'Kepler-26 c').
entidad(bacteria, 'Nie', 'Kepler-26 c').
entidad(animal, 'Pat', 'Kepler-26 c').
entidad(animal, 'Finudiusa', 'Kepler-26 c').
entidad(animal, 'Stau', 'Kepler-26 c').
entidad(humano, 'Dibido', 'CoRoT-22 b').
entidad(alien, 'Oke', 'CoRoT-22 b').
entidad(humano, 'Irou', 'CoRoT-22 b').
entidad(animal, 'Badi', 'CoRoT-22 b').
entidad(bacteria, 'Ern', 'CoRoT-22 b').
entidad(bacteria, 'Oiroa', 'Kepler-342 d').
entidad(bacteria, 'Oteu', 'Kepler-342 d').
entidad(alien, 'Eud', 'Kepler-342 d').
entidad(alien, 'Auld', 'Kepler-342 d').
entidad(animal, 'Asen', 'Kepler-342 d').
entidad(bacteria, 'Upro', 'Kepler-342 d').
entidad(animal, 'Agamit', 'Kepler-342 d').
entidad(bacteria, 'Umea', 'Kepler-342 d').
entidad(bacteria, 'Iaboyalt', 'Kepler-342 d').
entidad(animal, 'Eunbunietak', 'Kepler-342 d').
entidad(alien, 'Umob', 'WASP-42 b').
entidad(bacteria, 'Hies', 'WASP-42 b').
entidad(alien, 'Hes', 'WASP-42 b').
entidad(bacteria, 'Eng', 'WASP-42 b').
entidad(humano, 'Jereou', 'WASP-42 b').
entidad(alien, 'Onkit', 'WASP-42 b').
entidad(alien, 'Omoct', 'WASP-42 b').
entidad(animal, 'Derolu', 'WASP-42 b').
entidad(bacteria, 'Lamo', 'WASP-42 b').
entidad(bacteria, 'Roms', 'Kepler-1092 b').
entidad(bacteria, 'Psia', 'Kepler-1092 b').
entidad(alien, 'Emi', 'Kepler-1092 b').
entidad(humano, 'Ream', 'Kepler-1092 b').
entidad(humano, 'Apenec', 'Kepler-1092 b').
entidad(alien, 'Pae', 'Kepler-1092 b').
entidad(animal, 'Obo', 'Kepler-1092 b').
entidad(alien, 'Ulce', 'Kepler-954 b').
entidad(bacteria, 'Gosoad', 'Kepler-954 b').
entidad(animal, 'Uscef', 'Kepler-954 b').
entidad(bacteria, 'Ido', 'Kepler-954 b').
entidad(alien, 'Yra', 'Kepler-954 b').
entidad(humano, 'Eringog', 'omega Ser b').
entidad(alien, 'Toi', 'omega Ser b').
entidad(bacteria, 'Pogo', 'omega Ser b').
entidad(bacteria, 'Fueralicim', 'omega Ser b').
entidad(animal, 'Ibe', 'omega Ser b').
entidad(humano, 'Ugei', 'Kepler-539 b').
entidad(bacteria, 'Gau', 'Kepler-539 b').
entidad(alien, 'Elel', 'Kepler-539 b').
entidad(alien, 'Hapoa', 'Kepler-539 b').
entidad(alien, 'Mol', 'Kepler-539 b').
entidad(alien, 'Gla', 'iota Dra b').
entidad(bacteria, 'Irk', 'iota Dra b').
entidad(bacteria, 'Sunarahe', 'iota Dra b').
entidad(animal, 'Jun', 'iota Dra b').
entidad(bacteria, 'Raymoi', 'Kepler-1576 b').
entidad(alien, 'Rocau', 'Kepler-1576 b').
entidad(animal, 'Otu', 'Kepler-31 c').
entidad(bacteria, 'Oex', 'Kepler-31 c').
entidad(alien, 'Coc', 'Kepler-31 c').
entidad(humano, 'Rua', 'Kepler-31 c').
entidad(humano, 'Toalu', 'Kepler-31 c').
entidad(humano, 'Esareau', 'Kepler-31 c').
entidad(alien, 'Fognoid', 'Kepler-31 c').
entidad(bacteria, 'Aud', 'Kepler-898 b').
entidad(bacteria, 'Nau', 'Kepler-898 b').
entidad(animal, 'Tebi', 'Kepler-898 b').
entidad(animal, 'Meod', 'Kepler-898 b').
entidad(bacteria, 'Punc', 'Kepler-898 b').
entidad(bacteria, 'Set', 'Kepler-898 b').
entidad(bacteria, 'Ker', 'Kepler-1365 c').
entidad(alien, 'Tul', 'Kepler-1365 c').
entidad(bacteria, 'Odeil', 'Kepler-1365 c').
entidad(humano, 'Sk', 'Kepler-1365 c').
entidad(alien, 'Ote', 'Kepler-1365 c').
entidad(animal, 'Klo', 'Kepler-1365 c').
entidad(bacteria, 'Cim', 'Kepler-1365 c').
entidad(bacteria, 'Yri', 'Kepler-1365 c').
entidad(alien, 'Sec', 'Kepler-1365 c').
entidad(alien, 'Equea', 'Kepler-1643 b').
entidad(animal, 'Mern', 'Kepler-1643 b').
entidad(alien, 'Edsudo', 'Kepler-1643 b').
entidad(bacteria, 'Guroin', 'Kepler-1643 b').
entidad(alien, 'Eili', 'Kepler-1643 b').
entidad(alien, 'Cate', 'Kepler-1643 b').
entidad(bacteria, 'Vie', 'Kepler-1643 b').
entidad(alien, 'Kea', 'Kepler-1643 b').
entidad(alien, 'Eday', 'Kepler-1643 b').
entidad(animal, 'Obic', 'Kepler-300 b').
entidad(bacteria, 'Ailunophi', 'Kepler-300 b').
entidad(bacteria, 'Eos', 'Kepler-300 b').
entidad(humano, 'Unlit', 'Kepler-300 b').
entidad(alien, 'Porm', 'Kepler-300 b').
entidad(bacteria, 'Pisul', 'Kepler-300 b').
entidad(bacteria, 'Idad', 'Kepler-300 b').
entidad(animal, 'Lerareou', 'Kepler-224 d').
entidad(bacteria, 'Aprady', 'HAT-P-40 b').
entidad(bacteria, 'Ila', 'HAT-P-40 b').
entidad(bacteria, 'Eulo', 'HAT-P-40 b').
entidad(alien, 'Kerm', 'HAT-P-40 b').
entidad(bacteria, 'Foani', 'Kepler-1614 b').
entidad(bacteria, 'Akaneo', 'Kepler-1614 b').
entidad(humano, 'Cro', 'Kepler-1614 b').
entidad(alien, 'Ne', 'Kepler-1614 b').
entidad(bacteria, 'Veroev', 'Kepler-1614 b').
entidad(bacteria, 'Oso', 'Kepler-1614 b').
entidad(alien, 'Sueac', 'Kepler-1202 b').
entidad(bacteria, 'Ovadu', 'Kepler-1202 b').
entidad(animal, 'Oxec', 'Kepler-1202 b').
entidad(alien, 'Bleu', 'Kepler-1202 b').
entidad(bacteria, 'Touna', 'Kepler-1202 b').
entidad(humano, 'Icoeau', 'Kepler-1202 b').
entidad(humano, 'Aln', 'HD 28678 b').
entidad(alien, 'Itau', 'HD 28678 b').
entidad(animal, 'Blod', 'HD 28678 b').
entidad(bacteria, 'Kied', 'HD 28678 b').
entidad(alien, 'Ars', 'HD 28678 b').
entidad(bacteria, 'Ugia', 'HD 28678 b').
entidad(humano, 'Areteu', 'HD 98219 b').
entidad(bacteria, 'Tanu', 'HD 98219 b').
entidad(animal, 'Eti', 'HD 98219 b').
entidad(bacteria, 'Kal', 'HD 98219 b').
entidad(humano, 'Erk', 'HD 98219 b').
entidad(bacteria, 'Aft', 'Kepler-382 b').
entidad(bacteria, 'Poelewi', 'Kepler-382 b').
entidad(bacteria, 'Eadog', 'Kepler-382 b').
entidad(humano, 'Ulit', 'Kepler-382 b').
entidad(animal, 'Igey', 'Kepler-382 b').
entidad(bacteria, 'Ou', 'Kepler-1208 b').
entidad(bacteria, 'Ei', 'Kepler-1208 b').
entidad(animal, 'Elen', 'Kepler-1208 b').
entidad(humano, 'Ias', 'Kepler-1208 b').
entidad(bacteria, 'We', 'Kepler-1208 b').
entidad(alien, 'Oshm', 'Kepler-1208 b').
entidad(humano, 'Oue', 'HD 12648 b').
entidad(bacteria, 'Acieus', 'HD 12648 b').
entidad(bacteria, 'Hi', 'HD 12648 b').
entidad(animal, 'Ensea', 'HD 12648 b').
entidad(animal, 'Ayea', 'HD 12648 b').
entidad(alien, 'Oi', 'HD 12648 b').
entidad(alien, 'Rap', 'HD 12648 b').
entidad(bacteria, 'Inli', 'HD 12648 b').
entidad(humano, 'Eudom', 'HD 12648 b').
entidad(animal, 'Io', 'Kepler-173 b').
entidad(alien, 'Inur', 'Kepler-173 b').
entidad(animal, 'Ulm', 'Kepler-173 b').
entidad(animal, 'Gau', 'Kepler-173 b').
entidad(bacteria, 'Fliag', 'Kepler-173 b').
entidad(alien, 'Zo', 'Kepler-173 b').
entidad(humano, 'Ae', 'Kepler-173 b').
entidad(animal, 'Sp', 'Kepler-1448 b').
entidad(bacteria, 'Ox', 'Kepler-1448 b').
entidad(humano, 'Eiva', 'Kepler-1448 b').
entidad(humano, 'Xhut', 'Kepler-1448 b').
entidad(bacteria, 'Asi', 'Kepler-1448 b').
entidad(animal, 'Ow', 'Kepler-167 c').
entidad(bacteria, 'Eru', 'Kepler-167 c').
entidad(humano, 'Esim', 'Kepler-167 c').
entidad(alien, 'Odoma', 'Kepler-167 c').
entidad(bacteria, 'El', 'Kepler-167 c').
entidad(bacteria, 'Ai', 'Kepler-167 c').
entidad(animal, 'Gisp', 'Kepler-286 e').
entidad(alien, 'Ub', 'Kepler-286 e').
entidad(animal, 'Osic', 'Kepler-286 e').
entidad(humano, 'Otua', 'Kepler-286 e').
entidad(alien, 'Api', 'Kepler-286 e').
entidad(bacteria, 'Aisize', 'Kepler-512 b').
entidad(alien, 'Edu', 'HD 92788 b').
entidad(bacteria, 'Man', 'HD 92788 b').
entidad(humano, 'Scra', 'HD 92788 b').
entidad(alien, 'Joir', 'HD 92788 b').
entidad(humano, 'Biail', 'HD 92788 b').
entidad(bacteria, 'Ey', 'Kepler-224 e').
entidad(alien, 'Sa', 'Kepler-224 e').
entidad(bacteria, 'Ema', 'Kepler-224 e').
entidad(animal, 'Afa', 'Kepler-224 e').
entidad(humano, 'Ariane', 'Kepler-335 c').
entidad(alien, 'Alani', 'Kepler-335 c').
entidad(humano, 'Aud', 'Kepler-464 b').
entidad(bacteria, 'Taf', 'Kepler-464 b').
entidad(alien, 'Opok', 'Kepler-464 b').
entidad(alien, 'Nef', 'Kepler-464 b').
entidad(alien, 'Hy', 'Kepler-464 b').
entidad(bacteria, 'Kieve', 'Kepler-464 b').
entidad(bacteria, 'Eloir', 'Kepler-464 b').
entidad(alien, 'Vousyr', 'Kepler-464 b').
entidad(bacteria, 'Eh', 'Kepler-1327 b').
entidad(bacteria, 'Eour', 'Kepler-1327 b').
entidad(alien, 'As', 'Kepler-1327 b').
entidad(animal, 'Iluie', 'Kepler-1327 b').
entidad(humano, 'Ed', 'Kepler-1327 b').
entidad(alien, 'Jau', 'Kepler-326 c').



